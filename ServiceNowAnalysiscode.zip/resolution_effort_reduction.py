"""
RESOLUTION EFFORT REDUCTION ANALYSIS
Detailed resolution analysis + Short description correlation + Application clustering
Focus: Identify effort reduction opportunities by analyzing resolution patterns
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class ResolutionEffortAnalyzer:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        print("=" * 100)
        print("RESOLUTION EFFORT REDUCTION ANALYSIS".center(100))
        print("=" * 100)
        print("\nAnalyzing resolutions to identify effort reduction opportunities...\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load application mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
            print("⚠ No application mapping file found, using service_offering")
        
        os.makedirs('output_effort_reduction', exist_ok=True)
        os.makedirs('output_effort_reduction/by_application', exist_ok=True)
        os.makedirs('output_effort_reduction/resolution_patterns', exist_ok=True)
        os.makedirs('output_effort_reduction/effort_savings', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing resolution effort analysis dataset...")
        
        # Map to applications
        if self.mapping_dict:
            self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        else:
            self.df['application'] = self.df.get('service_offering', 'Unknown')
        
        self.df['application'] = self.df['application'].fillna('Unknown')
        
        # Clean text fields
        self.df['short_description_clean'] = self.df['short_description'].fillna('').astype(str)
        self.df['close_notes_clean'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['assigned_to_clean'] = self.df.get('assigned_to', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        
        # Resolution time
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        self.df['resolution_hours'] = (self.df['resolved_at'] - self.df['opened_at']).dt.total_seconds() / 3600
        
        # Filter to incidents with resolution
        self.df_resolved = self.df[
            (self.df['close_notes_clean'].str.len() > 20) & 
            (self.df['resolution_hours'].notna()) &
            (self.df['resolution_hours'] > 0)
        ].copy()
        
        print(f"  - Total incidents: {len(self.df):,}")
        print(f"  - With resolution notes: {len(self.df_resolved):,}")
        print(f"  - Resolution rate: {len(self.df_resolved)/len(self.df)*100:.1f}%\n")
        
        print("✓ Dataset prepared\n")
    
    def extract_resolution_actions(self):
        """Extract specific resolution actions from close notes"""
        print("Extracting resolution actions...")
        
        # Define action patterns
        action_patterns = {
            'Restart/Reboot': r'\b(restart|restarted|reboot|rebooted|bounced)\b',
            'Clear/Delete': r'\b(clear|cleared|delete|deleted|purge|purged|clean|cleaned)\b',
            'Reset': r'\b(reset|resetted)\b',
            'Fix/Correct': r'\b(fix|fixed|correct|corrected|repair|repaired)\b',
            'Update/Modify': r'\b(update|updated|modify|modified|change|changed)\b',
            'Grant/Add': r'\b(grant|granted|add|added|enable|enabled)\b',
            'Run/Execute': r'\b(run|ran|execute|executed|rerun|reran)\b',
            'Kill/Stop': r'\b(kill|killed|stop|stopped|terminate|terminated)\b',
            'Configure': r'\b(configure|configured|config|setup)\b',
            'Investigate': r'\b(investigate|investigated|research|researched|check|checked)\b',
            'Escalate': r'\b(escalate|escalated|forward|forwarded)\b',
            'Monitor': r'\b(monitor|monitored|watch|watched|observe|observed)\b',
            'Index/Optimize': r'\b(index|indexed|optimize|optimized|rebuild|rebuilt)\b',
            'Archive': r'\b(archive|archived|backup|backed)\b',
            'Install/Deploy': r'\b(install|installed|deploy|deployed)\b'
        }
        
        for action_name, pattern in action_patterns.items():
            self.df_resolved[f'action_{action_name}'] = self.df_resolved['close_notes_clean'].str.lower().str.contains(pattern, regex=True, na=False)
        
        # Identify primary action
        action_cols = [f'action_{name}' for name in action_patterns.keys()]
        self.df_resolved['primary_action'] = self.df_resolved[action_cols].idxmax(axis=1).str.replace('action_', '')
        self.df_resolved.loc[~self.df_resolved[action_cols].any(axis=1), 'primary_action'] = 'Other/Manual'
        
        print(f"✓ Extracted resolution actions\n")
    
    def cluster_resolutions(self):
        """Cluster similar resolutions"""
        print("Clustering similar resolutions...")
        
        # Normalize resolution text
        self.df_resolved['resolution_normalized'] = self.df_resolved['close_notes_clean'].apply(self._normalize_resolution)
        
        # Create resolution signature
        self.df_resolved['resolution_signature'] = self.df_resolved.apply(
            lambda row: f"{row['primary_action']}_{self._extract_keywords(row['resolution_normalized'])}",
            axis=1
        )
        
        # Cluster by signature
        self.df_resolved['resolution_cluster_id'] = self.df_resolved.groupby('resolution_signature').ngroup()
        
        # Calculate cluster stats
        res_clusters = self.df_resolved.groupby('resolution_cluster_id').agg({
            'number': 'count',
            'primary_action': 'first',
            'resolution_signature': 'first',
            'close_notes_clean': 'first',
            'resolution_hours': ['mean', 'median', 'sum'],
            'application': lambda x: x.nunique()
        })
        
        res_clusters.columns = ['Incident_Count', 'Primary_Action', 'Signature', 'Example_Resolution',
                               'Avg_Hours', 'Median_Hours', 'Total_Hours', 'Num_Applications']
        
        res_clusters = res_clusters.sort_values('Incident_Count', ascending=False)
        self.resolution_clusters = res_clusters
        
        print(f"✓ Created {len(res_clusters):,} resolution clusters")
        print(f"  - Clusters with 10+ incidents: {len(res_clusters[res_clusters['Incident_Count'] >= 10]):,}\n")
    
    def _normalize_resolution(self, text):
        """Normalize resolution text"""
        text = str(text).lower()
        text = re.sub(r'\d{4,}', 'NUM', text)
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IPADDR', text)
        text = re.sub(r'\b[a-z]{2,4}\d{2}[a-z0-9]+\b', 'SERVERID', text)
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def _extract_keywords(self, text):
        """Extract key words from text"""
        words = text.split()
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                    'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should'}
        meaningful = [w for w in words if w not in stopwords and len(w) > 3][:5]
        return '_'.join(sorted(meaningful)) if meaningful else 'generic'
    
    def analyze_by_application(self):
        """Analyze resolution patterns by application"""
        print("Analyzing resolution patterns by application...")
        
        output_dir = 'output_effort_reduction/by_application'
        
        # Get top 30 applications
        top_apps = self.df_resolved['application'].value_counts().head(30).index
        
        app_summaries = []
        
        for app in top_apps:
            app_data = self.df_resolved[self.df_resolved['application'] == app]
            
            # Resolution action distribution
            action_dist = app_data['primary_action'].value_counts()
            
            # Resolution cluster distribution
            cluster_dist = app_data.groupby('resolution_cluster_id').agg({
                'number': 'count',
                'short_description_clean': 'first',
                'close_notes_clean': 'first',
                'resolution_hours': ['mean', 'sum']
            })
            cluster_dist.columns = ['Count', 'Example_Issue', 'Example_Resolution', 'Avg_Hours', 'Total_Hours']
            cluster_dist = cluster_dist.sort_values('Count', ascending=False)
            
            # Identify automation opportunities
            automation_candidates = cluster_dist[
                (cluster_dist['Count'] >= 5) &
                (cluster_dist['Avg_Hours'] < 4)
            ]
            
            # Calculate effort metrics
            total_incidents = len(app_data)
            total_hours = app_data['resolution_hours'].sum()
            avg_hours = app_data['resolution_hours'].mean()
            
            # Recurring resolution count (5+ same resolution)
            recurring_count = cluster_dist[cluster_dist['Count'] >= 5]['Count'].sum()
            recurring_hours = cluster_dist[cluster_dist['Count'] >= 5]['Total_Hours'].sum()
            
            # Automation potential (assuming 70% automation for recurring)
            potential_savings = recurring_hours * 0.7
            
            app_summaries.append({
                'Application': app,
                'Total_Incidents': total_incidents,
                'Total_Hours': round(total_hours, 0),
                'Avg_Hours_Per_Incident': round(avg_hours, 2),
                'Recurring_Incidents': recurring_count,
                'Recurring_Hours': round(recurring_hours, 0),
                'Potential_Savings_Hours': round(potential_savings, 0),
                'Potential_Savings_USD': round(potential_savings * 50, 0),
                'Automation_Candidates': len(automation_candidates),
                'Top_Action': action_dist.index[0] if len(action_dist) > 0 else 'Unknown',
                'Top_Action_Pct': round(action_dist.iloc[0] / total_incidents * 100, 1) if len(action_dist) > 0 else 0
            })
            
            # Save detailed report
            cluster_dist['Automation_Potential'] = cluster_dist.apply(
                lambda row: self._assess_automation(row['Count'], row['Avg_Hours']), axis=1
            )
            
            safe_app = re.sub(r'[<>:"/\\|?*]', '_', str(app))[:50]
            cluster_dist.to_csv(f'{output_dir}/APP_{safe_app}_resolutions.csv')
        
        # Summary of all applications
        app_summary_df = pd.DataFrame(app_summaries)
        app_summary_df = app_summary_df.sort_values('Potential_Savings_Hours', ascending=False)
        app_summary_df.to_csv(f'{output_dir}/APPLICATION_SUMMARY.csv', index=False)
        
        print(f"✓ Created application analysis for top 30 applications")
        print(f"  - Total potential savings: {app_summary_df['Potential_Savings_Hours'].sum():,.0f} hours")
        print(f"  - Total potential value: ${app_summary_df['Potential_Savings_USD'].sum():,.0f}\n")
        
        self.app_summaries = app_summary_df
    
    def _assess_automation(self, count, avg_hours):
        """Assess automation potential"""
        score = 0
        if count >= 20:
            score += 3
        elif count >= 10:
            score += 2
        elif count >= 5:
            score += 1
        
        if avg_hours < 1:
            score += 2
        elif avg_hours < 2:
            score += 1
        
        if score >= 4:
            return 'High'
        elif score >= 2:
            return 'Medium'
        else:
            return 'Low'
    
    def map_resolution_to_issue(self):
        """Map resolution patterns to issue patterns"""
        print("Mapping resolutions to issue patterns...")
        
        # Normalize short descriptions
        self.df_resolved['issue_normalized'] = self.df_resolved['short_description_clean'].apply(self._normalize_resolution)
        self.df_resolved['issue_signature'] = self.df_resolved['issue_normalized'].apply(
            lambda x: self._extract_keywords(x)
        )
        
        # Create issue-resolution mapping
        mapping = self.df_resolved.groupby(['issue_signature', 'resolution_cluster_id', 'application']).agg({
            'number': 'count',
            'short_description_clean': 'first',
            'close_notes_clean': 'first',
            'resolution_hours': 'mean'
        }).reset_index()
        
        mapping.columns = ['Issue_Signature', 'Resolution_Cluster_ID', 'Application',
                          'Incident_Count', 'Example_Issue', 'Example_Resolution', 'Avg_Hours']
        
        mapping = mapping.sort_values('Incident_Count', ascending=False)
        mapping.to_csv('output_effort_reduction/issue_resolution_mapping.csv', index=False)
        
        print(f"✓ Created issue-resolution mapping\n")
    
    def generate_effort_reduction_proposals(self):
        """Generate specific effort reduction proposals"""
        print("Generating effort reduction proposals...")
        
        output_dir = 'output_effort_reduction/effort_savings'
        
        proposals = []
        
        # High-volume recurring resolutions (10+ incidents)
        high_volume = self.resolution_clusters[self.resolution_clusters['Incident_Count'] >= 10]
        
        for cluster_id, cluster_row in high_volume.iterrows():
            cluster_data = self.df_resolved[self.df_resolved['resolution_cluster_id'] == cluster_id]
            
            # Get application breakdown
            app_breakdown = cluster_data.groupby('application').agg({
                'number': 'count',
                'resolution_hours': 'sum'
            }).sort_values('number', ascending=False)
            
            # Get issue patterns
            issue_patterns = cluster_data['short_description_clean'].value_counts().head(3)
            
            # Calculate current effort
            total_incidents = cluster_row['Incident_Count']
            total_hours = cluster_row['Total_Hours']
            avg_hours = cluster_row['Avg_Hours']
            
            # Determine automation approach
            action = cluster_row['Primary_Action']
            automation_approach = self._suggest_automation_approach(action, cluster_row['Example_Resolution'])
            
            # Calculate savings
            if automation_approach['automation_rate'] > 0:
                automated_incidents = total_incidents * (automation_approach['automation_rate'] / 100)
                hours_saved = automated_incidents * avg_hours
                cost_saved = hours_saved * 50  # $50/hour
                
                proposals.append({
                    'Resolution_Pattern': cluster_row['Example_Resolution'][:150],
                    'Primary_Action': action,
                    'Total_Incidents': total_incidents,
                    'Applications_Affected': cluster_row['Num_Applications'],
                    'Top_3_Applications': ', '.join(app_breakdown.head(3).index.tolist()),
                    'Avg_Hours_Per_Incident': round(avg_hours, 2),
                    'Total_Hours_Spent': round(total_hours, 0),
                    'Current_Effort': f"{int(total_incidents)} incidents × {avg_hours:.1f}h = {total_hours:.0f}h",
                    'Automation_Approach': automation_approach['approach'],
                    'Automation_Type': automation_approach['type'],
                    'Expected_Automation_Rate': f"{automation_approach['automation_rate']}%",
                    'Incidents_Automated': int(automated_incidents),
                    'Hours_Saved': round(hours_saved, 0),
                    'Annual_Cost_Savings': f"${cost_saved:,.0f}",
                    'Implementation_Complexity': automation_approach['complexity'],
                    'Example_Issues': '; '.join(issue_patterns.index[:3].tolist())[:200]
                })
        
        if proposals:
            proposals_df = pd.DataFrame(proposals)
            proposals_df = proposals_df.sort_values('Hours_Saved', ascending=False)
            proposals_df.to_csv(f'{output_dir}/EFFORT_REDUCTION_PROPOSALS.csv', index=False)
            
            # Create executive summary
            self._create_effort_summary(proposals_df, output_dir)
        
        print(f"✓ Created {len(proposals):,} effort reduction proposals\n")
        
        self.proposals = proposals_df if proposals else pd.DataFrame()
    
    def _suggest_automation_approach(self, action, resolution_text):
        """Suggest automation approach based on action and resolution"""
        res_lower = str(resolution_text).lower()
        
        approaches = {
            'Restart/Reboot': {
                'approach': 'Automated Service Restart with Health Check',
                'type': 'Script',
                'automation_rate': 85,
                'complexity': 'Low'
            },
            'Clear/Delete': {
                'approach': 'Scheduled Cleanup Script with Monitoring',
                'type': 'Script',
                'automation_rate': 90,
                'complexity': 'Low'
            },
            'Run/Execute': {
                'approach': 'Auto-Retry Logic with Failure Handling',
                'type': 'Script',
                'automation_rate': 80,
                'complexity': 'Medium'
            },
            'Reset': {
                'approach': 'Self-Service Reset Portal',
                'type': 'Portal',
                'automation_rate': 95,
                'complexity': 'Medium'
            },
            'Grant/Add': {
                'approach': 'Automated Access Request Workflow',
                'type': 'Workflow',
                'automation_rate': 75,
                'complexity': 'High'
            },
            'Kill/Stop': {
                'approach': 'Automated Process Monitoring and Termination',
                'type': 'Script',
                'automation_rate': 70,
                'complexity': 'Medium'
            },
            'Index/Optimize': {
                'approach': 'Scheduled Database Maintenance',
                'type': 'Script',
                'automation_rate': 85,
                'complexity': 'Medium'
            },
            'Configure': {
                'approach': 'Configuration Management Automation',
                'type': 'Tool',
                'automation_rate': 60,
                'complexity': 'High'
            },
            'Fix/Correct': {
                'approach': 'Pattern-Based Auto-Remediation',
                'type': 'Custom',
                'automation_rate': 50,
                'complexity': 'High'
            }
        }
        
        return approaches.get(action, {
            'approach': 'Monitoring with Alert-Based Automation',
            'type': 'Custom',
            'automation_rate': 40,
            'complexity': 'High'
        })
    
    def _create_effort_summary(self, proposals_df, output_dir):
        """Create executive effort reduction summary"""
        with open(f'{output_dir}/EFFORT_REDUCTION_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("EFFORT REDUCTION EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Total Reduction Proposals: {len(proposals_df):,}\n")
            f.write(f"Total Current Effort: {proposals_df['Total_Hours_Spent'].sum():,.0f} hours/year\n")
            f.write(f"Total Potential Savings: {proposals_df['Hours_Saved'].sum():,.0f} hours/year\n")
            f.write(f"Reduction Rate: {proposals_df['Hours_Saved'].sum() / proposals_df['Total_Hours_Spent'].sum() * 100:.1f}%\n")
            f.write(f"Estimated Annual Value: ${proposals_df['Hours_Saved'].sum() * 50:,.0f}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("TOP 15 EFFORT REDUCTION OPPORTUNITIES\n")
            f.write("=" * 100 + "\n\n")
            
            for idx, row in proposals_df.head(15).iterrows():
                f.write(f"{idx+1}. {row['Resolution_Pattern'][:80]}\n")
                f.write(f"   Current Effort: {row['Current_Effort']}\n")
                f.write(f"   Applications: {row['Top_3_Applications'][:70]}\n")
                f.write(f"   SOLUTION: {row['Automation_Approach']}\n")
                f.write(f"   Automation: {row['Expected_Automation_Rate']} | Complexity: {row['Implementation_Complexity']}\n")
                f.write(f"   SAVINGS: {int(row['Hours_Saved']):,} hours/year = {row['Annual_Cost_Savings']}\n")
                f.write(f"   Example Issues: {row['Example_Issues'][:80]}\n\n")
    
    def generate_master_excel(self):
        print("Generating EFFORT_REDUCTION_MASTER.xlsx...")
        
        excel_file = 'output_effort_reduction/EFFORT_REDUCTION_MASTER.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Overall Summary
            overall = pd.DataFrame({
                'Metric': [
                    'Total Incidents Analyzed',
                    'Total Resolution Hours',
                    'Avg Hours Per Incident',
                    'Resolution Clusters Identified',
                    'High-Volume Patterns (10+)',
                    'Automation Candidates',
                    'Total Potential Savings (Hours)',
                    'Total Potential Savings (USD @ $50/hr)',
                    'Expected Effort Reduction %'
                ],
                'Value': [
                    len(self.df_resolved),
                    round(self.df_resolved['resolution_hours'].sum(), 0),
                    round(self.df_resolved['resolution_hours'].mean(), 2),
                    len(self.resolution_clusters),
                    len(self.resolution_clusters[self.resolution_clusters['Incident_Count'] >= 10]),
                    len(self.proposals) if hasattr(self, 'proposals') and len(self.proposals) > 0 else 0,
                    round(self.proposals['Hours_Saved'].sum(), 0) if hasattr(self, 'proposals') and len(self.proposals) > 0 else 0,
                    f"${self.proposals['Hours_Saved'].sum() * 50:,.0f}" if hasattr(self, 'proposals') and len(self.proposals) > 0 else "$0",
                    f"{self.proposals['Hours_Saved'].sum() / self.df_resolved['resolution_hours'].sum() * 100:.1f}%" if hasattr(self, 'proposals') and len(self.proposals) > 0 else "0%"
                ]
            })
            overall.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            # Sheet 2: By Application
            if hasattr(self, 'app_summaries'):
                self.app_summaries.to_excel(writer, sheet_name='02_By_Application', index=False)
            
            # Sheet 3: By Resolution Action
            action_summary = self.df_resolved.groupby('primary_action').agg({
                'number': 'count',
                'resolution_hours': ['sum', 'mean']
            }).round(2)
            action_summary.columns = ['Incident_Count', 'Total_Hours', 'Avg_Hours']
            action_summary = action_summary.sort_values('Incident_Count', ascending=False)
            action_summary.to_excel(writer, sheet_name='03_By_Action_Type')
            
            # Sheet 4: Top Resolution Clusters
            self.resolution_clusters.head(100).to_excel(writer, sheet_name='04_Top_Resolutions')
            
            # Sheet 5: Effort Reduction Proposals
            if hasattr(self, 'proposals') and len(self.proposals) > 0:
                self.proposals.to_excel(writer, sheet_name='05_Reduction_Proposals', index=False)
        
        print(f"✓ Created master Excel: {excel_file}\n")
    
    def run_full_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING RESOLUTION EFFORT REDUCTION ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.extract_resolution_actions()
        self.cluster_resolutions()
        self.analyze_by_application()
        self.map_resolution_to_issue()
        self.generate_effort_reduction_proposals()
        self.generate_master_excel()
        
        print("\n" + "=" * 100)
        print("EFFORT REDUCTION ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_effort_reduction/\n")
        print("KEY FILES:")
        print("  ✓ EFFORT_REDUCTION_MASTER.xlsx ⭐")
        print("  ✓ effort_savings/EFFORT_REDUCTION_PROPOSALS.csv ⭐⭐⭐")
        print("  ✓ effort_savings/EFFORT_REDUCTION_SUMMARY.txt ⭐⭐")
        print("  ✓ by_application/APPLICATION_SUMMARY.csv ⭐\n")
        print("DETAILED FILES:")
        print("  ✓ by_application/APP_*.csv (30 application reports)")
        print("  ✓ issue_resolution_mapping.csv\n")
        
        if hasattr(self, 'proposals') and len(self.proposals) > 0:
            total_savings = self.proposals['Hours_Saved'].sum()
            print(f"💰 POTENTIAL SAVINGS: {total_savings:,.0f} hours/year = ${total_savings * 50:,.0f}\n")
        
        print("=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = ResolutionEffortAnalyzer(FILE_PATH)
        analyzer.run_full_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
