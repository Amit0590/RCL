"""
Advanced Text Analysis for ServiceNow Tickets
Finds patterns, common themes, and actionable insights from ticket descriptions

Author: Automated Analysis Tool
Date: 2025
"""

import pandas as pd
import numpy as np
from collections import Counter
import re
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class TextAnalyzer:
    def __init__(self, file_path):
        """
        Initialize text analyzer
        
        Parameters:
        file_path (str): Path to the CSV file containing ticket data
        """
        print("Loading ticket data for text analysis...")
        
        # Try different encodings
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        df_loaded = False
        
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Successfully loaded with {encoding} encoding")
                df_loaded = True
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
            except Exception as e:
                if 'codec' not in str(e).lower():
                    raise
        
        if not df_loaded:
            raise ValueError("Could not read CSV file. Try running: py fix_encoding.py")
        
        print(f"Loaded {len(self.df):,} tickets")
        
        import os
        os.makedirs('output/text_analysis', exist_ok=True)
        
    def extract_error_patterns(self):
        """Extract common error patterns from descriptions"""
        print("\nExtracting error patterns...")
        
        # Common error keywords
        error_keywords = [
            'error', 'failed', 'failure', 'timeout', 'exception', 
            'unable', 'cannot', 'denied', 'rejected', 'invalid',
            'not responding', 'not found', 'connection', 'crashed'
        ]
        
        error_patterns = {}
        
        for keyword in error_keywords:
            # Find tickets containing this keyword
            mask = self.df['description'].str.contains(keyword, case=False, na=False) | \
                   self.df['short_description'].str.contains(keyword, case=False, na=False)
            
            count = mask.sum()
            if count > 0:
                error_patterns[keyword] = {
                    'count': count,
                    'percentage': (count / len(self.df)) * 100
                }
        
        # Save results
        error_df = pd.DataFrame.from_dict(error_patterns, orient='index')
        error_df = error_df.sort_values('count', ascending=False)
        error_df.to_csv('output/text_analysis/error_patterns.csv')
        
        print(f"Found {len(error_patterns)} error patterns")
        print("Results saved to output/text_analysis/error_patterns.csv")
        
        return error_df
    
    def extract_system_names(self):
        """Extract system/application names from descriptions"""
        print("\nExtracting system names...")
        
        # Combine short_description and description
        all_text = (self.df['short_description'].fillna('') + ' ' + 
                   self.df['description'].fillna('')).str.upper()
        
        # Common patterns for system names (usually uppercase or CamelCase)
        system_pattern = r'\b[A-Z]{2,}(?:[-_][A-Z0-9]+)*\b'
        
        all_systems = []
        for text in all_text:
            systems = re.findall(system_pattern, text)
            all_systems.extend(systems)
        
        # Count occurrences
        system_counts = Counter(all_systems)
        
        # Filter out common words that aren't system names
        common_words = {'THE', 'AND', 'FOR', 'WITH', 'FROM', 'TO', 'IN', 'ON', 'AT', 'BY', 'IS', 'ARE', 'WAS', 'WERE'}
        filtered_systems = {k: v for k, v in system_counts.items() 
                          if k not in common_words and len(k) > 2 and v > 2}
        
        # Save top systems
        top_systems = sorted(filtered_systems.items(), key=lambda x: x[1], reverse=True)[:50]
        
        systems_df = pd.DataFrame(top_systems, columns=['System_Name', 'Occurrences'])
        systems_df['Percentage'] = (systems_df['Occurrences'] / len(self.df) * 100).round(2)
        systems_df.to_csv('output/text_analysis/top_systems.csv', index=False)
        
        print(f"Identified {len(top_systems)} frequently mentioned systems")
        print("Results saved to output/text_analysis/top_systems.csv")
        
        return systems_df
    
    def analyze_description_length(self):
        """Analyze relationship between description length and resolution time"""
        print("\nAnalyzing description length impact...")
        
        # Calculate description length
        self.df['desc_length'] = self.df['description'].fillna('').str.len()
        
        # Convert dates for resolution time calculation
        self.df['opened_at'] = pd.to_datetime(self.df['opened_at'], errors='coerce')
        self.df['resolved_at'] = pd.to_datetime(self.df['resolved_at'], errors='coerce')
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        # Categorize by description length
        self.df['desc_category'] = pd.cut(
            self.df['desc_length'], 
            bins=[0, 100, 500, 1000, float('inf')],
            labels=['Very Short (<100)', 'Short (100-500)', 'Medium (500-1000)', 'Long (>1000)']
        )
        
        length_analysis = self.df.groupby('desc_category').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median']
        }).round(2)
        
        length_analysis.columns = ['Ticket_Count', 'Avg_Resolution_Hours', 'Median_Resolution_Hours']
        length_analysis.to_csv('output/text_analysis/description_length_analysis.csv')
        
        print("Description length analysis saved to output/text_analysis/description_length_analysis.csv")
        
        return length_analysis
    
    def find_quick_resolution_patterns(self, threshold_hours=4):
        """Find patterns in quickly resolved tickets"""
        print(f"\nFinding patterns in tickets resolved within {threshold_hours} hours...")
        
        # Calculate resolution time
        self.df['opened_at'] = pd.to_datetime(self.df['opened_at'], errors='coerce')
        self.df['resolved_at'] = pd.to_datetime(self.df['resolved_at'], errors='coerce')
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        # Filter quick resolutions
        quick_tickets = self.df[self.df['resolution_hours'] <= threshold_hours]
        
        print(f"Found {len(quick_tickets):,} tickets resolved within {threshold_hours} hours")
        
        # Analyze categories
        quick_categories = quick_tickets['category'].value_counts().head(20)
        quick_cat_df = pd.DataFrame({
            'Category': quick_categories.index,
            'Count': quick_categories.values,
            'Percentage_of_Quick': (quick_categories.values / len(quick_tickets) * 100).round(2)
        })
        quick_cat_df.to_csv('output/text_analysis/quick_resolution_categories.csv', index=False)
        
        # Common short descriptions for quick tickets
        quick_descriptions = quick_tickets['short_description'].value_counts().head(30)
        quick_desc_df = pd.DataFrame({
            'Short_Description': quick_descriptions.index,
            'Count': quick_descriptions.values
        })
        quick_desc_df.to_csv('output/text_analysis/quick_resolution_descriptions.csv', index=False)
        
        print("Quick resolution analysis saved to output/text_analysis/")
        
        return quick_cat_df, quick_desc_df
    
    def find_long_resolution_patterns(self, percentile=90):
        """Find patterns in tickets with long resolution times"""
        print(f"\nFinding patterns in tickets with resolution time > {percentile}th percentile...")
        
        # Calculate resolution time
        self.df['opened_at'] = pd.to_datetime(self.df['opened_at'], errors='coerce')
        self.df['resolved_at'] = pd.to_datetime(self.df['resolved_at'], errors='coerce')
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        # Get threshold
        threshold = self.df['resolution_hours'].quantile(percentile / 100)
        
        # Filter long resolutions
        long_tickets = self.df[self.df['resolution_hours'] >= threshold]
        
        print(f"Found {len(long_tickets):,} tickets with resolution time >= {threshold:.1f} hours")
        
        # Analyze categories
        long_categories = long_tickets['category'].value_counts().head(20)
        long_cat_df = pd.DataFrame({
            'Category': long_categories.index,
            'Count': long_categories.values,
            'Percentage_of_Long': (long_categories.values / len(long_tickets) * 100).round(2),
            'Avg_Resolution_Hours': [long_tickets[long_tickets['category'] == cat]['resolution_hours'].mean() 
                                    for cat in long_categories.index]
        })
        long_cat_df['Avg_Resolution_Hours'] = long_cat_df['Avg_Resolution_Hours'].round(2)
        long_cat_df.to_csv('output/text_analysis/long_resolution_categories.csv', index=False)
        
        # Common short descriptions for long tickets
        long_descriptions = long_tickets['short_description'].value_counts().head(30)
        long_desc_df = pd.DataFrame({
            'Short_Description': long_descriptions.index,
            'Count': long_descriptions.values,
            'Avg_Resolution_Hours': [long_tickets[long_tickets['short_description'] == desc]['resolution_hours'].mean() 
                                    for desc in long_descriptions.index]
        })
        long_desc_df['Avg_Resolution_Hours'] = long_desc_df['Avg_Resolution_Hours'].round(2)
        long_desc_df.to_csv('output/text_analysis/long_resolution_descriptions.csv', index=False)
        
        print("Long resolution analysis saved to output/text_analysis/")
        
        return long_cat_df, long_desc_df
    
    def extract_keywords_by_category(self, top_n_categories=10):
        """Extract common keywords for top categories"""
        print(f"\nExtracting keywords for top {top_n_categories} categories...")
        
        top_categories = self.df['category'].value_counts().head(top_n_categories).index
        
        category_keywords = {}
        
        for category in top_categories:
            cat_tickets = self.df[self.df['category'] == category]
            
            # Combine descriptions
            all_text = (cat_tickets['short_description'].fillna('') + ' ' + 
                       cat_tickets['description'].fillna('')).str.lower()
            
            # Split into words and count
            words = []
            for text in all_text:
                # Remove special characters and split
                clean_text = re.sub(r'[^a-z0-9\s]', ' ', text)
                words.extend(clean_text.split())
            
            # Filter out common words and short words
            stop_words = {'the', 'and', 'for', 'with', 'from', 'to', 'in', 'on', 'at', 'by', 
                         'is', 'are', 'was', 'were', 'been', 'be', 'have', 'has', 'had',
                         'this', 'that', 'these', 'those', 'not', 'but', 'or', 'as', 'of'}
            
            filtered_words = [w for w in words if len(w) > 3 and w not in stop_words]
            
            # Count top words
            word_counts = Counter(filtered_words).most_common(15)
            category_keywords[category] = word_counts
        
        # Save to file
        with open('output/text_analysis/category_keywords.txt', 'w') as f:
            f.write("COMMON KEYWORDS BY CATEGORY\n")
            f.write("=" * 80 + "\n\n")
            
            for category, keywords in category_keywords.items():
                f.write(f"\n{category}\n")
                f.write("-" * 80 + "\n")
                for word, count in keywords:
                    f.write(f"  {word}: {count}\n")
        
        print("Category keywords saved to output/text_analysis/category_keywords.txt")
        
        return category_keywords
    
    def generate_automation_candidates(self):
        """Identify tickets that could potentially be automated"""
        print("\nIdentifying automation candidates...")
        
        # Calculate resolution time
        self.df['opened_at'] = pd.to_datetime(self.df['opened_at'], errors='coerce')
        self.df['resolved_at'] = pd.to_datetime(self.df['resolved_at'], errors='coerce')
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        # Criteria for automation:
        # 1. Occurs frequently (same short_description)
        # 2. Resolved quickly (< median resolution time)
        # 3. Same category
        
        median_resolution = self.df['resolution_hours'].median()
        
        desc_counts = self.df['short_description'].value_counts()
        frequent_issues = desc_counts[desc_counts >= 5]  # Occurs 5+ times (now a Series)
        
        automation_candidates = []
        
        for desc in frequent_issues.index:
            count = frequent_issues[desc]
            desc_tickets = self.df[self.df['short_description'] == desc]
            avg_resolution = desc_tickets['resolution_hours'].mean()
            
            if avg_resolution <= median_resolution * 1.5:  # Resolved relatively quickly
                automation_candidates.append({
                    'Short_Description': desc,
                    'Occurrences': int(count),
                    'Avg_Resolution_Hours': avg_resolution,
                    'Most_Common_Category': desc_tickets['category'].mode()[0] if len(desc_tickets['category'].mode()) > 0 else 'Unknown',
                    'Most_Common_Priority': desc_tickets['priority'].mode()[0] if len(desc_tickets['priority'].mode()) > 0 else 'Unknown'
                })
        
        automation_df = pd.DataFrame(automation_candidates)
        automation_df = automation_df.sort_values('Occurrences', ascending=False)
        automation_df['Avg_Resolution_Hours'] = automation_df['Avg_Resolution_Hours'].round(2)
        automation_df.to_csv('output/text_analysis/automation_candidates.csv', index=False)
        
        print(f"Identified {len(automation_df)} potential automation candidates")
        print("Results saved to output/text_analysis/automation_candidates.csv")
        
        return automation_df
    
    def run_full_text_analysis(self):
        """Run complete text analysis pipeline"""
        print("\n" + "=" * 60)
        print("STARTING ADVANCED TEXT ANALYSIS")
        print("=" * 60)
        
        self.extract_error_patterns()
        self.extract_system_names()
        self.analyze_description_length()
        self.find_quick_resolution_patterns()
        self.find_long_resolution_patterns()
        self.extract_keywords_by_category()
        self.generate_automation_candidates()
        
        print("\n" + "=" * 60)
        print("TEXT ANALYSIS COMPLETE!")
        print("=" * 60)
        print("\nAll outputs saved to output/text_analysis/")
        print("\nKey insights files:")
        print("  - automation_candidates.csv")
        print("  - error_patterns.csv")
        print("  - quick_resolution_descriptions.csv")
        print("  - category_keywords.txt")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    # USAGE: Replace with your actual file path
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = TextAnalyzer(FILE_PATH)
        analyzer.run_full_text_analysis()
        
    except FileNotFoundError:
        print(f"\nERROR: File '{FILE_PATH}' not found!")
        print("Please update the FILE_PATH variable with the correct path to your CSV file.")
    except Exception as e:
        print(f"\nERROR: An error occurred during text analysis:")
        print(f"{str(e)}")
        import traceback
        traceback.print_exc()
