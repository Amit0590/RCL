"""
ADVANCED DUAL CLUSTERING ANALYSIS
1. Cluster issues by description
2. Cluster resolutions by close_notes
3. Map issue clusters to resolution clusters (one-to-one or many-to-one)
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class DualClusterAnalyzer:
    def __init__(self, file_path):
        print("=" * 100)
        print("ADVANCED DUAL CLUSTERING ANALYSIS".center(100))
        print("=" * 100)
        print("\nClustering Issues → Clustering Resolutions → Mapping\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        os.makedirs('output_dual_clustering', exist_ok=True)
        os.makedirs('output_dual_clustering/issue_clusters', exist_ok=True)
        os.makedirs('output_dual_clustering/resolution_clusters', exist_ok=True)
        os.makedirs('output_dual_clustering/cluster_mapping', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing dual clustering dataset...")
        
        # Clean description (for issue clustering)
        self.df['description_clean'] = self.df.get('description', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['description_normalized'] = self.df['description_clean'].apply(self._normalize_text)
        
        # Clean close_notes (for resolution clustering)
        self.df['close_notes_clean'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['resolution_normalized'] = self.df['close_notes_clean'].apply(self._normalize_text)
        
        # Filter out very short descriptions/resolutions
        self.df['desc_length'] = self.df['description_normalized'].str.len()
        self.df['res_length'] = self.df['resolution_normalized'].str.len()
        
        print(f"  - Incidents with description (50+ chars): {(self.df['desc_length'] >= 50).sum():,}")
        print(f"  - Incidents with resolution (20+ chars): {(self.df['res_length'] >= 20).sum():,}")
        
        # Keep only incidents with both description and resolution
        self.df_complete = self.df[(self.df['desc_length'] >= 50) & (self.df['res_length'] >= 20)].copy()
        print(f"  - Incidents with BOTH: {len(self.df_complete):,}\n")
        
        print("✓ Dataset prepared\n")
    
    def _normalize_text(self, text):
        """Normalize text for clustering"""
        text = str(text).lower()
        # Replace variable parts
        text = re.sub(r'\d{4,}', 'NUM', text)
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IPADDR', text)
        text = re.sub(r'\b[a-z0-9]+@[a-z0-9]+\.[a-z]+\b', 'EMAIL', text)
        text = re.sub(r'\b[a-z]{2,4}\d{2}[a-z0-9]+\b', 'SERVERID', text)
        text = re.sub(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', 'DATE', text)
        text = re.sub(r'\b\d{1,2}:\d{2}(:\d{2})?\s*(am|pm)?\b', 'TIME', text)
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def cluster_issues(self):
        """Cluster incidents by description similarity"""
        print("STEP 1: Clustering ISSUES by description...")
        
        # Extract key patterns from descriptions
        self.df_complete['issue_pattern'] = self.df_complete['description_normalized'].apply(
            lambda x: self._extract_pattern(x, pattern_type='issue')
        )
        
        # Cluster by issue pattern
        self.df_complete['issue_cluster_id'] = self.df_complete.groupby('issue_pattern').ngroup()
        
        # Calculate issue cluster statistics
        issue_stats = self.df_complete.groupby('issue_cluster_id').agg({
            'number': 'count',
            'issue_pattern': 'first',
            'description_clean': 'first'
        })
        issue_stats.columns = ['Incident_Count', 'Pattern', 'Example_Description']
        issue_stats = issue_stats.sort_values('Incident_Count', ascending=False)
        
        self.issue_clusters = issue_stats
        
        print(f"✓ Created {len(issue_stats):,} issue clusters")
        print(f"  - Clusters with 10+ incidents: {len(issue_stats[issue_stats['Incident_Count'] >= 10]):,}")
        print(f"  - Clusters with 5-9 incidents: {len(issue_stats[(issue_stats['Incident_Count'] >= 5) & (issue_stats['Incident_Count'] < 10)]):,}")
        print(f"  - Largest cluster: {issue_stats['Incident_Count'].max():,} incidents\n")
    
    def cluster_resolutions(self):
        """Cluster incidents by resolution similarity"""
        print("STEP 2: Clustering RESOLUTIONS by close_notes...")
        
        # Extract key patterns from resolutions
        self.df_complete['resolution_pattern'] = self.df_complete['resolution_normalized'].apply(
            lambda x: self._extract_pattern(x, pattern_type='resolution')
        )
        
        # Cluster by resolution pattern
        self.df_complete['resolution_cluster_id'] = self.df_complete.groupby('resolution_pattern').ngroup()
        
        # Calculate resolution cluster statistics
        resolution_stats = self.df_complete.groupby('resolution_cluster_id').agg({
            'number': 'count',
            'resolution_pattern': 'first',
            'close_notes_clean': 'first'
        })
        resolution_stats.columns = ['Incident_Count', 'Pattern', 'Example_Resolution']
        resolution_stats = resolution_stats.sort_values('Incident_Count', ascending=False)
        
        self.resolution_clusters = resolution_stats
        
        print(f"✓ Created {len(resolution_stats):,} resolution clusters")
        print(f"  - Clusters with 10+ incidents: {len(resolution_stats[resolution_stats['Incident_Count'] >= 10]):,}")
        print(f"  - Clusters with 5-9 incidents: {len(resolution_stats[(resolution_stats['Incident_Count'] >= 5) & (resolution_stats['Incident_Count'] < 10)]):,}")
        print(f"  - Largest cluster: {resolution_stats['Incident_Count'].max():,} incidents\n")
    
    def _extract_pattern(self, text, pattern_type='issue'):
        """Extract meaningful pattern from text"""
        words = text.split()
        
        # Different stopwords for issues vs resolutions
        if pattern_type == 'issue':
            stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                        'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should', 'error',
                        'issue', 'problem', 'unable', 'cannot', 'failure'}
            key_words = ['timeout', 'failed', 'error', 'connection', 'database', 'batch', 'job',
                        'performance', 'slow', 'down', 'unavailable', 'missing', 'corrupt']
        else:
            stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                        'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should'}
            key_words = ['restart', 'restarted', 'reboot', 'cleared', 'reset', 'deleted', 'fixed',
                        'corrected', 'updated', 'added', 'removed', 'granted', 'executed', 'ran']
        
        # Extract key words
        meaningful_words = []
        for word in words:
            if word in key_words:
                meaningful_words.append(word)
            elif word not in stopwords and len(word) > 3:
                meaningful_words.append(word)
        
        # Create pattern (up to 10 words)
        pattern_words = meaningful_words[:10]
        
        if len(pattern_words) >= 3:
            return ' '.join(sorted(pattern_words))
        elif len(pattern_words) >= 1:
            return ' '.join(sorted(pattern_words))
        else:
            return text[:50]
    
    def map_clusters(self):
        """Map issue clusters to resolution clusters"""
        print("STEP 3: Mapping ISSUE clusters to RESOLUTION clusters...")
        
        # Create mapping
        mapping = self.df_complete.groupby(['issue_cluster_id', 'resolution_cluster_id']).agg({
            'number': 'count'
        }).reset_index()
        mapping.columns = ['Issue_Cluster_ID', 'Resolution_Cluster_ID', 'Incident_Count']
        
        # Add cluster details
        mapping = mapping.merge(
            self.issue_clusters[['Pattern', 'Example_Description']].reset_index(),
            left_on='Issue_Cluster_ID',
            right_on='issue_cluster_id',
            how='left'
        )
        mapping = mapping.rename(columns={'Pattern': 'Issue_Pattern', 'Example_Description': 'Issue_Example'})
        
        mapping = mapping.merge(
            self.resolution_clusters[['Pattern', 'Example_Resolution']].reset_index(),
            left_on='Resolution_Cluster_ID',
            right_on='resolution_cluster_id',
            how='left'
        )
        mapping = mapping.rename(columns={'Pattern': 'Resolution_Pattern', 'Example_Resolution': 'Resolution_Example'})
        
        # Calculate mapping strength for each issue cluster
        issue_cluster_totals = mapping.groupby('Issue_Cluster_ID')['Incident_Count'].sum()
        mapping['Percent_of_Issue_Cluster'] = mapping.apply(
            lambda row: (row['Incident_Count'] / issue_cluster_totals[row['Issue_Cluster_ID']] * 100),
            axis=1
        ).round(2)
        
        # Determine mapping type - FIXED VERSION
        def classify_mapping_type(issue_cluster_id):
            """Classify mapping type for an issue cluster"""
            cluster_mappings = mapping[mapping['Issue_Cluster_ID'] == issue_cluster_id]
            
            if len(cluster_mappings) == 1:
                return 'One-to-One'
            elif cluster_mappings['Percent_of_Issue_Cluster'].max() >= 80:
                return 'Dominant Resolution (80%+)'
            elif cluster_mappings['Percent_of_Issue_Cluster'].max() >= 60:
                return 'Primary Resolution (60-80%)'
            else:
                return 'Multiple Resolutions'
        
        # Apply classification to each row
        mapping['Mapping_Type'] = mapping['Issue_Cluster_ID'].apply(classify_mapping_type)
        
        self.cluster_mapping = mapping.sort_values('Incident_Count', ascending=False)
        
        # Count mapping types
        mapping_summary = mapping.drop_duplicates('Issue_Cluster_ID')['Mapping_Type'].value_counts()
        
        print(f"✓ Created cluster mapping")
        print(f"\nMapping Type Distribution:")
        for mapping_type, count in mapping_summary.items():
            print(f"  - {mapping_type}: {count:,} issue clusters")
        print()
    
    def analyze_one_to_one_mappings(self):
        """Analyze perfect one-to-one mappings"""
        print("Analyzing ONE-TO-ONE mappings...")
        
        # Get issue clusters with single resolution
        one_to_one = []
        
        for issue_id in self.df_complete['issue_cluster_id'].unique():
            issue_data = self.df_complete[self.df_complete['issue_cluster_id'] == issue_id]
            resolution_counts = issue_data['resolution_cluster_id'].value_counts()
            
            if len(resolution_counts) == 1:
                # Perfect one-to-one
                resolution_id = resolution_counts.index[0]
                one_to_one.append({
                    'Issue_Cluster_ID': issue_id,
                    'Resolution_Cluster_ID': resolution_id,
                    'Incident_Count': len(issue_data),
                    'Issue_Pattern': self.issue_clusters.loc[issue_id, 'Pattern'],
                    'Issue_Example': self.issue_clusters.loc[issue_id, 'Example_Description'][:200],
                    'Resolution_Pattern': self.resolution_clusters.loc[resolution_id, 'Pattern'],
                    'Resolution_Example': self.resolution_clusters.loc[resolution_id, 'Example_Resolution'][:200],
                    'Mapping_Confidence': 100.0
                })
        
        if one_to_one:
            one_to_one_df = pd.DataFrame(one_to_one)
            one_to_one_df = one_to_one_df.sort_values('Incident_Count', ascending=False)
            one_to_one_df.to_csv('output_dual_clustering/cluster_mapping/ONE_TO_ONE_MAPPINGS.csv', index=False)
            
            print(f"✓ Found {len(one_to_one_df):,} perfect one-to-one mappings")
            print(f"  - Covering {one_to_one_df['Incident_Count'].sum():,} incidents\n")
            
            self.one_to_one_mappings = one_to_one_df
        else:
            self.one_to_one_mappings = pd.DataFrame()
    
    def analyze_dominant_mappings(self):
        """Analyze dominant resolution patterns (80%+ consistency)"""
        print("Analyzing DOMINANT mappings (80%+ same resolution)...")
        
        dominant = self.cluster_mapping[
            self.cluster_mapping['Mapping_Type'] == 'Dominant Resolution (80%+)'
        ].copy()
        
        if len(dominant) > 0:
            # Get the dominant resolution for each issue cluster
            dominant_primary = dominant.sort_values('Percent_of_Issue_Cluster', ascending=False).groupby('Issue_Cluster_ID').first().reset_index()
            
            dominant_primary.to_csv('output_dual_clustering/cluster_mapping/DOMINANT_MAPPINGS.csv', index=False)
            
            print(f"✓ Found {len(dominant_primary):,} dominant mappings")
            print(f"  - Covering {dominant_primary['Incident_Count'].sum():,} incidents\n")
            
            self.dominant_mappings = dominant_primary
        else:
            self.dominant_mappings = pd.DataFrame()
    
    def generate_issue_cluster_details(self):
        """Generate detailed reports for issue clusters"""
        print("Generating issue cluster details...")
        
        output_dir = 'output_dual_clustering/issue_clusters'
        
        # Overall summary
        self.issue_clusters.to_csv(f'{output_dir}/issue_cluster_summary.csv')
        
        # Top 50 issue clusters with resolution breakdown
        top_issues = self.issue_clusters.head(50)
        
        for issue_id, issue_row in top_issues.iterrows():
            issue_data = self.df_complete[self.df_complete['issue_cluster_id'] == issue_id]
            
            # Get resolution breakdown
            res_breakdown = issue_data.groupby('resolution_cluster_id').agg({
                'number': 'count',
                'close_notes_clean': 'first'
            })
            res_breakdown.columns = ['Count', 'Example_Resolution']
            res_breakdown['Percentage'] = (res_breakdown['Count'] / len(issue_data) * 100).round(2)
            res_breakdown = res_breakdown.sort_values('Count', ascending=False)
            
            # Save
            safe_pattern = re.sub(r'[<>:"/\\|?*]', '_', str(issue_row['Pattern']))[:50]
            res_breakdown.to_csv(f'{output_dir}/issue_{issue_id:04d}_{safe_pattern}_resolutions.csv')
        
        print(f"✓ Created issue cluster details (top 50)\n")
    
    def generate_resolution_cluster_details(self):
        """Generate detailed reports for resolution clusters"""
        print("Generating resolution cluster details...")
        
        output_dir = 'output_dual_clustering/resolution_clusters'
        
        # Overall summary
        self.resolution_clusters.to_csv(f'{output_dir}/resolution_cluster_summary.csv')
        
        # Top 50 resolution clusters with issue breakdown
        top_resolutions = self.resolution_clusters.head(50)
        
        for res_id, res_row in top_resolutions.iterrows():
            res_data = self.df_complete[self.df_complete['resolution_cluster_id'] == res_id]
            
            # Get issue breakdown
            issue_breakdown = res_data.groupby('issue_cluster_id').agg({
                'number': 'count',
                'description_clean': 'first'
            })
            issue_breakdown.columns = ['Count', 'Example_Issue']
            issue_breakdown['Percentage'] = (issue_breakdown['Count'] / len(res_data) * 100).round(2)
            issue_breakdown = issue_breakdown.sort_values('Count', ascending=False)
            
            # Save
            safe_pattern = re.sub(r'[<>:"/\\|?*]', '_', str(res_row['Pattern']))[:50]
            issue_breakdown.to_csv(f'{output_dir}/resolution_{res_id:04d}_{safe_pattern}_issues.csv')
        
        print(f"✓ Created resolution cluster details (top 50)\n")
    
    def generate_master_excel(self):
        print("Generating DUAL_CLUSTERING_MASTER.xlsx...")
        
        excel_file = 'output_dual_clustering/DUAL_CLUSTERING_MASTER.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Overall Summary
            one_to_one_count = len(self.one_to_one_mappings) if len(self.one_to_one_mappings) > 0 else 0
            dominant_count = len(self.dominant_mappings) if len(self.dominant_mappings) > 0 else 0
            
            overall = pd.DataFrame({
                'Metric': [
                    'Total Incidents Analyzed',
                    'Issue Clusters Created',
                    'Resolution Clusters Created',
                    'One-to-One Mappings',
                    'Dominant Mappings (80%+)',
                    'Primary Mappings (60-80%)',
                    'Multiple Resolution Patterns',
                    'Avg Incidents per Issue Cluster',
                    'Avg Incidents per Resolution Cluster'
                ],
                'Value': [
                    len(self.df_complete),
                    len(self.issue_clusters),
                    len(self.resolution_clusters),
                    one_to_one_count,
                    dominant_count,
                    len(self.cluster_mapping[self.cluster_mapping['Mapping_Type'] == 'Primary Resolution (60-80%)'].drop_duplicates('Issue_Cluster_ID')),
                    len(self.cluster_mapping[self.cluster_mapping['Mapping_Type'] == 'Multiple Resolutions'].drop_duplicates('Issue_Cluster_ID')),
                    round(self.issue_clusters['Incident_Count'].mean(), 2),
                    round(self.resolution_clusters['Incident_Count'].mean(), 2)
                ]
            })
            overall.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            # Sheet 2: Top Issue Clusters
            self.issue_clusters.head(100).to_excel(writer, sheet_name='02_Top_Issue_Clusters')
            
            # Sheet 3: Top Resolution Clusters
            self.resolution_clusters.head(100).to_excel(writer, sheet_name='03_Top_Resolution_Clusters')
            
            # Sheet 4: One-to-One Mappings
            if len(self.one_to_one_mappings) > 0:
                self.one_to_one_mappings.to_excel(writer, sheet_name='04_One_to_One_Mappings', index=False)
            
            # Sheet 5: Dominant Mappings
            if len(self.dominant_mappings) > 0:
                self.dominant_mappings.to_excel(writer, sheet_name='05_Dominant_Mappings', index=False)
            
            # Sheet 6: All Cluster Mappings
            self.cluster_mapping.head(500).to_excel(writer, sheet_name='06_All_Mappings', index=False)
        
        print(f"✓ Created master Excel: {excel_file}\n")
    
    def generate_executive_summary(self):
        print("Generating DUAL_CLUSTERING_SUMMARY.txt...")
        
        with open('output_dual_clustering/DUAL_CLUSTERING_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("DUAL CLUSTERING EXECUTIVE SUMMARY\n")
            f.write("Issue Clustering + Resolution Clustering + Mapping\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Total Incidents Analyzed: {len(self.df_complete):,}\n\n")
            
            f.write("ISSUE CLUSTERING RESULTS:\n")
            f.write(f"  - Total Issue Clusters: {len(self.issue_clusters):,}\n")
            f.write(f"  - Largest Issue Cluster: {self.issue_clusters['Incident_Count'].max():,} incidents\n")
            f.write(f"  - Avg per Cluster: {self.issue_clusters['Incident_Count'].mean():.1f} incidents\n\n")
            
            f.write("RESOLUTION CLUSTERING RESULTS:\n")
            f.write(f"  - Total Resolution Clusters: {len(self.resolution_clusters):,}\n")
            f.write(f"  - Largest Resolution Cluster: {self.resolution_clusters['Incident_Count'].max():,} incidents\n")
            f.write(f"  - Avg per Cluster: {self.resolution_clusters['Incident_Count'].mean():.1f} incidents\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("CLUSTER MAPPING ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            mapping_summary = self.cluster_mapping.drop_duplicates('Issue_Cluster_ID')['Mapping_Type'].value_counts()
            
            f.write("Mapping Type Distribution:\n")
            for mapping_type, count in mapping_summary.items():
                pct = count / len(self.issue_clusters) * 100
                f.write(f"  - {mapping_type}: {count:,} issue clusters ({pct:.1f}%)\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("TOP 10 ONE-TO-ONE MAPPINGS\n")
            f.write("=" * 100 + "\n\n")
            
            if len(self.one_to_one_mappings) > 0:
                for idx, row in self.one_to_one_mappings.head(10).iterrows():
                    f.write(f"\n{idx+1}. ISSUE: {row['Issue_Example'][:80]}\n")
                    f.write(f"   Occurrences: {row['Incident_Count']:,}\n")
                    f.write(f"   RESOLUTION: {row['Resolution_Example'][:80]}\n")
                    f.write(f"   Mapping Confidence: {row['Mapping_Confidence']:.0f}%\n")
            else:
                f.write("No perfect one-to-one mappings found.\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("TOP 10 DOMINANT MAPPINGS (80%+ Consistency)\n")
            f.write("=" * 100 + "\n\n")
            
            if len(self.dominant_mappings) > 0:
                for idx, row in self.dominant_mappings.head(10).iterrows():
                    f.write(f"\n{idx+1}. ISSUE: {row['Issue_Example'][:80]}\n")
                    f.write(f"   Occurrences: {row['Incident_Count']:,}\n")
                    f.write(f"   RESOLUTION: {row['Resolution_Example'][:80]}\n")
                    f.write(f"   Consistency: {row['Percent_of_Issue_Cluster']:.1f}%\n")
            else:
                f.write("No dominant mappings found.\n")
        
        print(f"✓ Created executive summary\n")
    
    def run_full_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING DUAL CLUSTERING ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.cluster_issues()
        self.cluster_resolutions()
        self.map_clusters()
        self.analyze_one_to_one_mappings()
        self.analyze_dominant_mappings()
        self.generate_issue_cluster_details()
        self.generate_resolution_cluster_details()
        self.generate_master_excel()
        self.generate_executive_summary()
        
        print("\n" + "=" * 100)
        print("DUAL CLUSTERING ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_dual_clustering/\n")
        print("KEY FILES:")
        print("  ✓ DUAL_CLUSTERING_MASTER.xlsx ⭐")
        print("  ✓ DUAL_CLUSTERING_SUMMARY.txt ⭐")
        print("  ✓ cluster_mapping/ONE_TO_ONE_MAPPINGS.csv ⭐⭐⭐")
        print("  ✓ cluster_mapping/DOMINANT_MAPPINGS.csv ⭐⭐\n")
        print("DETAILED FILES:")
        print("  ✓ issue_clusters/ (issue cluster details)")
        print("  ✓ resolution_clusters/ (resolution cluster details)\n")
        print("=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = DualClusterAnalyzer(FILE_PATH)
        analyzer.run_full_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
