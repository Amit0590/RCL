"""
INCIDENT CLUSTERING ANALYSIS
Machine Learning clustering based on short_description similarity
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class IncidentClusterAnalyzer:
    def __init__(self, file_path):
        print("=" * 100)
        print("INCIDENT CLUSTERING ANALYSIS".center(100))
        print("=" * 100)
        print("\nClustering incidents by short_description similarity...\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        os.makedirs('output_clustering', exist_ok=True)
        os.makedirs('output_clustering/cluster_reports', exist_ok=True)
        os.makedirs('output_clustering/automation_candidates', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing clustering dataset...")
        
        self.df['short_description_clean'] = self.df['short_description'].fillna('').astype(str)
        self.df['short_description_normalized'] = self.df['short_description_clean'].apply(self._normalize_text)
        
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        self.df['category_clean'] = self.df.get('category', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        self.df['close_notes_clean'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        
        print("✓ Dataset prepared\n")
    
    def _normalize_text(self, text):
        """Normalize text for clustering"""
        text = str(text).lower()
        text = re.sub(r'\d{4,}', 'NUM', text)  # Replace long numbers
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IPADDR', text)  # IP addresses
        text = re.sub(r'\b[a-z0-9]+@[a-z0-9]+\.[a-z]+\b', 'EMAIL', text)  # Emails
        text = re.sub(r'\b[a-z]{3}\d{2}\w+\b', 'SERVERID', text)  # Server IDs
        text = re.sub(r'[^\w\s]', ' ', text)  # Remove special chars
        text = re.sub(r'\s+', ' ', text).strip()  # Normalize spaces
        return text
    
    def extract_patterns(self):
        """Extract word patterns from normalized descriptions"""
        print("Extracting patterns from descriptions...")
        
        self.df['pattern_key'] = self.df['short_description_normalized'].apply(self._create_pattern_key)
        
        print("✓ Patterns extracted\n")
    
    def _create_pattern_key(self, text):
        """Create a pattern key for clustering"""
        words = text.split()
        
        # Filter common words
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                    'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should'}
        
        meaningful_words = [w for w in words if w not in stopwords and len(w) > 2]
        
        if len(meaningful_words) >= 3:
            return ' '.join(sorted(meaningful_words[:5]))
        elif len(meaningful_words) >= 2:
            return ' '.join(sorted(meaningful_words))
        else:
            return text
    
    def cluster_similar_incidents(self):
        """Cluster incidents with similar descriptions"""
        print("Clustering similar incidents...")
        
        # Simple clustering by exact pattern match
        self.df['cluster_id'] = self.df.groupby('pattern_key').ngroup()
        
        # Calculate cluster statistics
        cluster_stats = self.df.groupby('cluster_id').agg({
            'number': 'count',
            'pattern_key': 'first',
            'short_description_clean': 'first',
            'category_clean': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Mixed',
            'resolution_hours': ['mean', 'median'],
            'close_notes_clean': lambda x: x.mode()[0] if len(x.mode()) > 0 else ''
        })
        
        cluster_stats.columns = ['Count', 'Pattern', 'Example_Description', 'Common_Category',
                                'Avg_Resolution_Hours', 'Median_Resolution_Hours', 'Common_Resolution']
        
        cluster_stats = cluster_stats.sort_values('Count', ascending=False)
        self.cluster_stats = cluster_stats
        
        print(f"✓ Created {len(cluster_stats):,} clusters\n")
    
    def identify_recurring_incidents(self):
        """Identify frequently occurring incident patterns"""
        print("Identifying recurring incident patterns...")
        
        # Get clusters with 5+ occurrences
        recurring = self.cluster_stats[self.cluster_stats['Count'] >= 5].copy()
        
        recurring['Automation_Potential'] = recurring.apply(self._assess_automation_potential, axis=1)
        recurring['Priority_Score'] = recurring['Count'] * recurring['Avg_Resolution_Hours']
        
        recurring = recurring.sort_values('Priority_Score', ascending=False)
        
        recurring.to_csv('output_clustering/recurring_incident_patterns.csv')
        
        print(f"✓ Identified {len(recurring):,} recurring patterns\n")
    
    def _assess_automation_potential(self, row):
        """Assess if cluster is good automation candidate"""
        count = row['Count']
        resolution = str(row['Common_Resolution']).lower()
        
        automation_keywords = ['restart', 'reboot', 'clear', 'reset', 'delete', 'run', 'execute']
        
        score = 0
        if count >= 10:
            score += 3
        elif count >= 5:
            score += 2
        
        if any(kw in resolution for kw in automation_keywords):
            score += 2
        
        if row['Median_Resolution_Hours'] < 1:
            score += 1
        
        if score >= 4:
            return 'High'
        elif score >= 2:
            return 'Medium'
        else:
            return 'Low'
    
    def generate_cluster_details(self):
        """Generate detailed reports for top clusters"""
        print("Generating detailed cluster reports...")
        
        output_dir = 'output_clustering/cluster_reports'
        
        # Top 50 clusters by volume
        top_clusters = self.cluster_stats.head(50)
        
        for idx, cluster_row in top_clusters.iterrows():
            cluster_data = self.df[self.df['cluster_id'] == idx]
            
            cluster_detail = cluster_data[[
                'number', 'opened_at', 'resolved_at', 'short_description',
                'category_clean', 'resolution_hours', 'close_notes'
            ]].copy()
            
            cluster_detail = cluster_detail.sort_values('opened_at', ascending=False)
            
            safe_pattern = re.sub(r'[<>:"/\\|?*]', '_', str(cluster_row['Pattern']))[:50]
            cluster_detail.to_csv(f'{output_dir}/cluster_{idx:04d}_{safe_pattern}.csv', index=False)
        
        print(f"✓ Created detailed reports for top 50 clusters\n")
    
    def identify_automation_candidates(self):
        """Identify high-value automation opportunities"""
        print("Identifying automation candidates...")
        
        output_dir = 'output_clustering/automation_candidates'
        
        # High automation potential clusters
        high_auto = self.cluster_stats[
            (self.cluster_stats['Count'] >= 10) &
            (self.cluster_stats['Median_Resolution_Hours'] < 2)
        ].copy()
        
        if len(high_auto) > 0:
            automation_candidates = []
            
            for idx, cluster_row in high_auto.iterrows():
                cluster_data = self.df[self.df['cluster_id'] == idx]
                
                # Get resolution patterns
                resolutions = cluster_data['close_notes_clean'].value_counts()
                common_resolution = resolutions.index[0] if len(resolutions) > 0 else 'Unknown'
                
                automation_candidates.append({
                    'Cluster_ID': idx,
                    'Pattern': cluster_row['Pattern'],
                    'Example_Description': cluster_row['Example_Description'],
                    'Occurrences': cluster_row['Count'],
                    'Avg_Resolution_Hours': round(cluster_row['Avg_Resolution_Hours'], 2),
                    'Total_Hours_Spent': round(cluster_row['Count'] * cluster_row['Avg_Resolution_Hours'], 0),
                    'Potential_Savings_Hours': round(cluster_row['Count'] * cluster_row['Avg_Resolution_Hours'] * 0.8, 0),
                    'Common_Resolution': common_resolution[:200],
                    'Automation_Type': self._suggest_automation_type(common_resolution)
                })
            
            auto_df = pd.DataFrame(automation_candidates)
            auto_df = auto_df.sort_values('Potential_Savings_Hours', ascending=False)
            auto_df.to_csv(f'{output_dir}/high_value_automation_candidates.csv', index=False)
        
        print(f"✓ Identified automation candidates\n")
    
    def _suggest_automation_type(self, resolution):
        """Suggest automation approach based on resolution"""
        resolution = str(resolution).lower()
        
        if any(kw in resolution for kw in ['restart', 'reboot', 'start']):
            return 'Automated Restart Script'
        elif any(kw in resolution for kw in ['clear', 'delete', 'purge']):
            return 'Automated Cleanup Script'
        elif any(kw in resolution for kw in ['reset', 'password']):
            return 'Self-Service Portal'
        elif any(kw in resolution for kw in ['run', 'execute', 'rerun']):
            return 'Automated Job Execution'
        elif any(kw in resolution for kw in ['update', 'change', 'modify']):
            return 'Configuration Management'
        else:
            return 'Custom Automation'
    
    def generate_master_excel(self):
        print("Generating CLUSTERING_MASTER_SUMMARY.xlsx...")
        
        excel_file = 'output_clustering/CLUSTERING_MASTER_SUMMARY.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Overall Summary
            overall = pd.DataFrame({
                'Metric': [
                    'Total Incidents',
                    'Total Clusters',
                    'Clusters with 10+ Incidents',
                    'Clusters with 5-9 Incidents',
                    'Clusters with 2-4 Incidents',
                    'Unique Incidents (1 occurrence)',
                    'Avg Incidents per Cluster',
                    'High Automation Potential',
                    'Medium Automation Potential',
                    'Total Hours Spent (Recurring)'
                ],
                'Value': [
                    len(self.df),
                    len(self.cluster_stats),
                    len(self.cluster_stats[self.cluster_stats['Count'] >= 10]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 5) & (self.cluster_stats['Count'] < 10)]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 2) & (self.cluster_stats['Count'] < 5)]),
                    len(self.cluster_stats[self.cluster_stats['Count'] == 1]),
                    round(self.cluster_stats['Count'].mean(), 2),
                    len(self.cluster_stats[self.cluster_stats.get('Automation_Potential', '') == 'High']) if 'Automation_Potential' in self.cluster_stats.columns else 0,
                    len(self.cluster_stats[self.cluster_stats.get('Automation_Potential', '') == 'Medium']) if 'Automation_Potential' in self.cluster_stats.columns else 0,
                    round((self.cluster_stats[self.cluster_stats['Count'] >= 5]['Count'] * 
                          self.cluster_stats[self.cluster_stats['Count'] >= 5]['Avg_Resolution_Hours']).sum(), 0)
                ]
            })
            overall.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            # Sheet 2: Top 100 Clusters
            top_100 = self.cluster_stats.head(100)[['Count', 'Pattern', 'Example_Description', 
                                                     'Common_Category', 'Avg_Resolution_Hours']]
            top_100.to_excel(writer, sheet_name='02_Top_100_Clusters')
            
            # Sheet 3: Automation Candidates
            if 'Automation_Potential' in self.cluster_stats.columns:
                auto_candidates = self.cluster_stats[
                    self.cluster_stats['Automation_Potential'].isin(['High', 'Medium'])
                ][['Count', 'Pattern', 'Example_Description', 'Avg_Resolution_Hours', 
                   'Automation_Potential']]
                auto_candidates.to_excel(writer, sheet_name='03_Automation_Candidates')
            
            # Sheet 4: Volume Distribution
            volume_dist = pd.DataFrame({
                'Cluster_Size': ['1 incident', '2-4 incidents', '5-9 incidents', 
                               '10-19 incidents', '20-49 incidents', '50+ incidents'],
                'Cluster_Count': [
                    len(self.cluster_stats[self.cluster_stats['Count'] == 1]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 2) & (self.cluster_stats['Count'] <= 4)]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 5) & (self.cluster_stats['Count'] <= 9)]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 10) & (self.cluster_stats['Count'] <= 19)]),
                    len(self.cluster_stats[(self.cluster_stats['Count'] >= 20) & (self.cluster_stats['Count'] <= 49)]),
                    len(self.cluster_stats[self.cluster_stats['Count'] >= 50])
                ]
            })
            volume_dist.to_excel(writer, sheet_name='04_Volume_Distribution', index=False)
        
        print(f"✓ Created master Excel: {excel_file}\n")
    
    def generate_executive_summary(self):
        print("Generating CLUSTERING_EXECUTIVE_SUMMARY.txt...")
        
        with open('output_clustering/CLUSTERING_EXECUTIVE_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("INCIDENT CLUSTERING EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Total Incidents Analyzed: {len(self.df):,}\n")
            f.write(f"Total Clusters Identified: {len(self.cluster_stats):,}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("CLUSTER DISTRIBUTION\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Clusters with 50+ incidents:    {len(self.cluster_stats[self.cluster_stats['Count'] >= 50]):,}\n")
            f.write(f"Clusters with 20-49 incidents:  {len(self.cluster_stats[(self.cluster_stats['Count'] >= 20) & (self.cluster_stats['Count'] < 50)]):,}\n")
            f.write(f"Clusters with 10-19 incidents:  {len(self.cluster_stats[(self.cluster_stats['Count'] >= 10) & (self.cluster_stats['Count'] < 20)]):,}\n")
            f.write(f"Clusters with 5-9 incidents:    {len(self.cluster_stats[(self.cluster_stats['Count'] >= 5) & (self.cluster_stats['Count'] < 10)]):,}\n")
            f.write(f"Unique incidents (1 occurrence): {len(self.cluster_stats[self.cluster_stats['Count'] == 1]):,}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("TOP 20 RECURRING INCIDENT PATTERNS\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"{'Rank':<6}{'Occurrences':<12}{'Avg Hours':<12}{'Pattern/Example'}\n")
            f.write("-" * 100 + "\n")
            
            for rank, (idx, row) in enumerate(self.cluster_stats.head(20).iterrows(), 1):
                f.write(f"{rank:<6}{int(row['Count']):<12}{row['Avg_Resolution_Hours']:<12.2f}{row['Example_Description'][:60]}\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("AUTOMATION OPPORTUNITY SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            recurring = self.cluster_stats[self.cluster_stats['Count'] >= 5]
            total_recurring_hours = (recurring['Count'] * recurring['Avg_Resolution_Hours']).sum()
            potential_savings = total_recurring_hours * 0.7
            
            f.write(f"Recurring Incidents (5+ occurrences): {recurring['Count'].sum():,}\n")
            f.write(f"Total Hours Spent on Recurring:       {total_recurring_hours:,.0f} hours\n")
            f.write(f"Potential Savings (70% automation):   {potential_savings:,.0f} hours\n")
            f.write(f"Estimated Cost Savings (@$50/hour):   ${potential_savings * 50:,.0f}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("END OF EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n")
        
        print(f"✓ Created executive summary\n")
    
    def run_full_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING CLUSTERING ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.extract_patterns()
        self.cluster_similar_incidents()
        self.identify_recurring_incidents()
        self.generate_cluster_details()
        self.identify_automation_candidates()
        self.generate_master_excel()
        self.generate_executive_summary()
        
        print("\n" + "=" * 100)
        print("CLUSTERING ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_clustering/\n")
        print("SUMMARY FILES:")
        print("  ✓ CLUSTERING_MASTER_SUMMARY.xlsx")
        print("  ✓ CLUSTERING_EXECUTIVE_SUMMARY.txt")
        print("  ✓ recurring_incident_patterns.csv\n")
        print("DETAILED FILES:")
        print("  ✓ cluster_reports/ (top 50 cluster details)")
        print("  ✓ automation_candidates/ (high-value opportunities)\n")
        print("=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = IncidentClusterAnalyzer(FILE_PATH)
        analyzer.run_full_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
