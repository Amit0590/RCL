"""
Enhanced ServiceNow Resolution Analysis
Analyzes close_notes, caller_id, assigned_to with detailed resolution patterns
Separates Alert/Error/Warning categories with resolution tracking

Features:
- Resolution pattern extraction from close_notes
- Resolver (assigned_to) performance analysis
- Caller analysis and frequent requesters
- Alert/Error/Warning categorization and resolution
- Resolution time correlation with resolution type
- Top resolvers and their specializations
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from collections import Counter
import re
import warnings
warnings.filterwarnings('ignore')

class EnhancedResolutionAnalyzer:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        """Initialize enhanced resolution analyzer"""
        print("=" * 100)
        print("ENHANCED RESOLUTION ANALYSIS - DETAILED INSIGHTS".center(100))
        print("=" * 100)
        
        # Load data
        print(f"\nLoading ticket data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} tickets with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            print("⚠ Mapping file not found, using auto-detection")
            self.mapping_dict = {}
        
        # Create output directories
        import os
        self.output_dirs = [
            'output_enhanced/01_resolution_patterns',
            'output_enhanced/02_resolver_analysis',
            'output_enhanced/03_caller_analysis',
            'output_enhanced/04_alert_error_warning',
            'output_enhanced/05_resolution_correlation',
            'output_enhanced/06_charts',
            'output_enhanced/07_summaries'
        ]
        for directory in self.output_dirs:
            os.makedirs(directory, exist_ok=True)
        
        print(f"✓ Created {len(self.output_dirs)} output directories")
    
    def prepare_data(self):
        """Prepare and enrich data"""
        print("\nPreparing data with enhanced fields...")
        
        # Map applications
        self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        self.df['application'].fillna('Other', inplace=True)
        
        # Convert dates
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        # Time calculations
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        self.df['resolution_days'] = self.df['resolution_hours'] / 24
        
        # Clean text fields
        if 'close_notes' in self.df.columns:
            self.df['close_notes_clean'] = self.df['close_notes'].fillna('').astype(str)
        else:
            self.df['close_notes_clean'] = ''
        
        if 'description' in self.df.columns:
            self.df['description_clean'] = self.df['description'].fillna('').astype(str)
        else:
            self.df['description_clean'] = ''
        
        # Extract alert/error/warning from category and description
        self.df['issue_type'] = self.df.apply(self._classify_issue_type, axis=1)
        
        print(f"✓ Data prepared with enhanced fields")
    
    def _classify_issue_type(self, row):
        """Classify ticket as Alert, Error, Warning, or Other"""
        combined_text = f"{row.get('category', '')} {row.get('description_clean', '')} {row.get('short_description', '')}".lower()
        
        # Priority order: Error > Alert > Warning > Other
        if any(word in combined_text for word in ['error', 'failure', 'failed', 'exception']):
            return 'Error'
        elif any(word in combined_text for word in ['alert', 'alarm', 'notification']):
            return 'Alert'
        elif any(word in combined_text for word in ['warning', 'warn', 'caution']):
            return 'Warning'
        else:
            return 'Other'
    
    def analyze_resolution_patterns(self):
        """Extract and analyze resolution patterns from close_notes"""
        print("\nAnalyzing resolution patterns from close_notes...")
        
        # Common resolution pattern keywords
        resolution_patterns = {
            'Password Reset': ['password reset', 'reset password', 'pwd reset', 'password changed'],
            'Service Restart': ['restarted service', 'service restart', 'restart application', 'bounced service'],
            'Permission Granted': ['granted access', 'permission granted', 'access provided', 'added to group'],
            'Configuration Change': ['config change', 'configuration updated', 'modified settings', 'changed parameter'],
            'Software Install': ['installed software', 'software installed', 'application installed', 'installed app'],
            'Batch Job Rerun': ['reran batch', 'batch rerun', 'job restarted', 'reprocessed batch'],
            'Disk Cleanup': ['cleaned disk', 'disk cleanup', 'freed space', 'deleted files'],
            'Cache Clear': ['cleared cache', 'cache cleared', 'purged cache', 'cache refresh'],
            'Network Issue': ['network fixed', 'connectivity restored', 'network issue resolved'],
            'Database Query': ['query optimized', 'index created', 'database tuned', 'query fixed'],
            'User Error': ['user error', 'training provided', 'user educated', 'instructed user'],
            'Escalated': ['escalated to', 'forwarded to', 'transferred to', 'routed to'],
            'Duplicate': ['duplicate', 'duplicate ticket', 'already resolved', 'related to'],
            'Not Reproducible': ['not reproducible', 'cannot reproduce', 'unable to reproduce'],
            'Monitoring Alert': ['false alert', 'alert suppressed', 'threshold adjusted', 'monitoring updated']
        }
        
        # Extract patterns
        pattern_counts = {pattern: 0 for pattern in resolution_patterns.keys()}
        pattern_tickets = {pattern: [] for pattern in resolution_patterns.keys()}
        
        for idx, row in self.df.iterrows():
            close_notes = row['close_notes_clean'].lower()
            
            for pattern_name, keywords in resolution_patterns.items():
                if any(keyword in close_notes for keyword in keywords):
                    pattern_counts[pattern_name] += 1
                    pattern_tickets[pattern_name].append({
                        'ticket_number': row.get('number', ''),
                        'resolution_hours': row.get('resolution_hours', 0),
                        'assigned_to': row.get('assigned_to', ''),
                        'caller_id': row.get('caller_id', ''),
                        'application': row.get('application', ''),
                        'close_notes': row['close_notes_clean'][:200]
                    })
        
        # Create detailed pattern analysis
        pattern_analysis = []
        
        for pattern_name, count in pattern_counts.items():
            if count > 0:
                tickets = pattern_tickets[pattern_name]
                resolution_times = [t['resolution_hours'] for t in tickets if pd.notna(t['resolution_hours']) and t['resolution_hours'] > 0]
                
                pattern_analysis.append({
                    'Resolution_Pattern': pattern_name,
                    'Total_Occurrences': count,
                    'Percentage_of_Total': round(count / len(self.df) * 100, 2),
                    'Avg_Resolution_Hours': round(np.mean(resolution_times), 2) if resolution_times else 0,
                    'Median_Resolution_Hours': round(np.median(resolution_times), 2) if resolution_times else 0,
                    'Min_Resolution_Hours': round(np.min(resolution_times), 2) if resolution_times else 0,
                    'Max_Resolution_Hours': round(np.max(resolution_times), 2) if resolution_times else 0,
                    'Total_Hours_Spent': round(sum(resolution_times), 1) if resolution_times else 0
                })
        
        pattern_df = pd.DataFrame(pattern_analysis).sort_values('Total_Occurrences', ascending=False)
        pattern_df.to_csv('output_enhanced/01_resolution_patterns/resolution_patterns_summary.csv', index=False)
        
        # Save detailed tickets per pattern
        for pattern_name, tickets in pattern_tickets.items():
            if len(tickets) > 0:
                safe_name = pattern_name.replace(' ', '_').replace('/', '_')
                tickets_df = pd.DataFrame(tickets)
                tickets_df.to_csv(f'output_enhanced/01_resolution_patterns/{safe_name}_tickets.csv', index=False)
        
        print(f"✓ Identified {len(pattern_df)} resolution patterns")
        print(f"✓ Saved detailed analysis for each pattern")
        
        return pattern_df
    
    def analyze_resolvers(self):
        """Analyze assigned_to (resolvers) performance"""
        print("\nAnalyzing resolver (assigned_to) performance...")
        
        if 'assigned_to' not in self.df.columns:
            print("⚠ assigned_to column not found, skipping resolver analysis")
            return None
        
        # Resolver performance
        resolver_stats = self.df.groupby('assigned_to').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median', 'std', lambda x: x.quantile(0.9)],
            'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple',
            'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple'
        }).round(2)
        
        resolver_stats.columns = [
            'Total_Tickets_Resolved',
            'Avg_Resolution_Hours',
            'Median_Resolution_Hours',
            'Std_Resolution_Hours',
            'P90_Resolution_Hours',
            'Primary_Application',
            'Primary_Category'
        ]
        
        # Calculate additional metrics
        resolver_stats['Total_Hours_Spent'] = (
            resolver_stats['Total_Tickets_Resolved'] * resolver_stats['Avg_Resolution_Hours']
        ).round(0)
        
        resolver_stats['Efficiency_Score'] = (
            resolver_stats['Total_Tickets_Resolved'] / resolver_stats['Avg_Resolution_Hours']
        ).round(2)
        
        # Add resolution pattern analysis per resolver
        resolver_patterns = []
        
        for resolver in resolver_stats.index[:50]:  # Top 50 resolvers
            resolver_tickets = self.df[self.df['assigned_to'] == resolver]
            
            # Extract common resolution words from close_notes
            all_notes = ' '.join(resolver_tickets['close_notes_clean'].tolist()).lower()
            
            # Common resolution keywords
            keywords = {
                'restart': all_notes.count('restart'),
                'reset': all_notes.count('reset'),
                'install': all_notes.count('install'),
                'configure': all_notes.count('config'),
                'access': all_notes.count('access'),
                'fix': all_notes.count('fix'),
                'update': all_notes.count('update'),
                'general': 0  # Default fallback
            }
            
            top_keyword = max(keywords, key=keywords.get) if any(keywords.values()) else 'general'
            
            resolver_patterns.append({
                'Resolver': resolver,
                'Specialization': top_keyword,
                'Keyword_Count': keywords[top_keyword]
            })
        
        resolver_patterns_df = pd.DataFrame(resolver_patterns)
        
        # Merge specialization
        resolver_stats = resolver_stats.merge(
            resolver_patterns_df.set_index('Resolver'),
            left_index=True,
            right_index=True,
            how='left'
        )
        
        # Sort and save
        resolver_stats = resolver_stats.sort_values('Total_Tickets_Resolved', ascending=False)
        resolver_stats.to_csv('output_enhanced/02_resolver_analysis/resolver_performance.csv')
        
        # Top 20 resolvers detail
        top_20 = resolver_stats.head(20)
        top_20.to_csv('output_enhanced/02_resolver_analysis/top_20_resolvers.csv')
        
        print(f"✓ Analyzed {len(resolver_stats)} resolvers")
        print(f"✓ Identified specializations for top 50 resolvers")
        
        return resolver_stats
    
    def analyze_callers(self):
        """Analyze caller_id patterns"""
        print("\nAnalyzing caller (caller_id) patterns...")
        
        if 'caller_id' not in self.df.columns:
            print("⚠ caller_id column not found, skipping caller analysis")
            return None
        
        # Caller statistics
        caller_stats = self.df.groupby('caller_id').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median'],
            'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple',
            'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple',
            'assigned_to': 'nunique'
        }).round(2)
        
        caller_stats.columns = [
            'Total_Tickets',
            'Avg_Resolution_Hours',
            'Median_Resolution_Hours',
            'Most_Common_Category',
            'Most_Common_Application',
            'Unique_Resolvers'
        ]
        
        # Identify power users (>10 tickets)
        caller_stats['User_Type'] = caller_stats['Total_Tickets'].apply(
            lambda x: 'Power User (50+)' if x >= 50 else 
                     'Frequent User (20-49)' if x >= 20 else 
                     'Regular User (10-19)' if x >= 10 else 
                     'Occasional User (<10)'
        )
        
        # Calculate recurrence rate
        caller_stats['Avg_Days_Between_Tickets'] = self.df.groupby('caller_id').apply(
            lambda x: (x['opened_at'].max() - x['opened_at'].min()).days / max(len(x) - 1, 1)
        ).round(1)
        
        # Sort and save
        caller_stats = caller_stats.sort_values('Total_Tickets', ascending=False)
        caller_stats.to_csv('output_enhanced/03_caller_analysis/caller_statistics.csv')
        
        # Power users (top requesters)
        power_users = caller_stats[caller_stats['Total_Tickets'] >= 20].copy()
        power_users.to_csv('output_enhanced/03_caller_analysis/power_users_top_requesters.csv')
        
        # User type distribution
        user_type_dist = caller_stats['User_Type'].value_counts().reset_index()
        user_type_dist.columns = ['User_Type', 'Count']
        user_type_dist.to_csv('output_enhanced/03_caller_analysis/user_type_distribution.csv', index=False)
        
        print(f"✓ Analyzed {len(caller_stats)} unique callers")
        print(f"✓ Identified {len(power_users)} power users (20+ tickets)")
        
        return caller_stats
    
    def analyze_alert_error_warning(self):
        """Detailed analysis of Alert/Error/Warning issues"""
        print("\nAnalyzing Alert/Error/Warning categorization...")
        
        # Distribution
        issue_dist = self.df['issue_type'].value_counts()
        print(f"\n  Issue Type Distribution:")
        for issue_type, count in issue_dist.items():
            pct = count / len(self.df) * 100
            print(f"    {issue_type}: {count:,} ({pct:.1f}%)")
        
        # Detailed analysis per type
        for issue_type in ['Alert', 'Error', 'Warning']:
            print(f"\n  Analyzing {issue_type} issues...")
            
            issue_df = self.df[self.df['issue_type'] == issue_type].copy()
            
            if len(issue_df) == 0:
                print(f"    No {issue_type} issues found")
                continue
            
            # Resolution patterns for this issue type
            resolution_analysis = issue_df.groupby('close_notes_clean').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median'],
                'assigned_to': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Unknown'
            }).round(2)
            
            resolution_analysis.columns = [
                'Occurrences',
                'Avg_Resolution_Hours',
                'Median_Resolution_Hours',
                'Most_Common_Resolver'
            ]
            
            resolution_analysis = resolution_analysis.sort_values('Occurrences', ascending=False)
            
            # Save top 100 resolutions
            top_resolutions = resolution_analysis.head(100)
            top_resolutions.to_csv(f'output_enhanced/04_alert_error_warning/{issue_type.lower()}_resolutions.csv')
            
            # Category breakdown
            category_breakdown = issue_df.groupby('category').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median'],
                'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple'
            }).round(2)
            
            category_breakdown.columns = [
                'Total_Tickets',
                'Avg_Resolution_Hours',
                'Median_Resolution_Hours',
                'Primary_Application'
            ]
            
            category_breakdown = category_breakdown.sort_values('Total_Tickets', ascending=False)
            category_breakdown.to_csv(f'output_enhanced/04_alert_error_warning/{issue_type.lower()}_by_category.csv')
            
            # Application breakdown
            app_breakdown = issue_df.groupby('application').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median'],
                'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple'
            }).round(2)
            
            app_breakdown.columns = [
                'Total_Tickets',
                'Avg_Resolution_Hours',
                'Median_Resolution_Hours',
                'Primary_Category'
            ]
            
            app_breakdown = app_breakdown.sort_values('Total_Tickets', ascending=False)
            app_breakdown.to_csv(f'output_enhanced/04_alert_error_warning/{issue_type.lower()}_by_application.csv')
            
            print(f"    ✓ Saved {issue_type} analysis (resolutions, categories, applications)")
        
        # Summary comparison
        summary_data = []
        for issue_type in ['Alert', 'Error', 'Warning', 'Other']:
            issue_df = self.df[self.df['issue_type'] == issue_type]
            
            summary_data.append({
                'Issue_Type': issue_type,
                'Total_Tickets': len(issue_df),
                'Percentage': round(len(issue_df) / len(self.df) * 100, 2),
                'Avg_Resolution_Hours': round(issue_df['resolution_hours'].mean(), 2),
                'Median_Resolution_Hours': round(issue_df['resolution_hours'].median(), 2),
                'Total_Hours_Spent': round(issue_df['resolution_hours'].sum(), 0)
            })
        
        summary_df = pd.DataFrame(summary_data)
        summary_df.to_csv('output_enhanced/04_alert_error_warning/issue_type_summary.csv', index=False)
        
        print(f"✓ Completed Alert/Error/Warning analysis")
    
    def analyze_resolution_correlation(self):
        """Correlation between resolution type and resolution time"""
        print("\nAnalyzing resolution type vs resolution time correlation...")
        
        # Common resolution actions
        resolution_actions = {
            'Automated': ['automated', 'auto-resolved', 'script', 'automatic'],
            'Manual Fix': ['manually', 'manual fix', 'manually resolved'],
            'Configuration': ['config change', 'configuration', 'settings'],
            'Restart': ['restart', 'reboot', 'bounce'],
            'Reset': ['reset', 'pwd reset', 'password reset'],
            'Escalated': ['escalated', 'forwarded', 'transferred'],
            'User Training': ['trained', 'educated', 'instructed'],
            'Investigation': ['investigating', 'researching', 'analyzing']
        }
        
        # Categorize each ticket
        action_data = []
        
        for idx, row in self.df.iterrows():
            close_notes = row['close_notes_clean'].lower()
            
            action_detected = 'Other'
            for action_name, keywords in resolution_actions.items():
                if any(keyword in close_notes for keyword in keywords):
                    action_detected = action_name
                    break
            
            action_data.append({
                'ticket_number': row.get('number', ''),
                'resolution_action': action_detected,
                'resolution_hours': row.get('resolution_hours', 0),
                'issue_type': row.get('issue_type', ''),
                'application': row.get('application', ''),
                'assigned_to': row.get('assigned_to', '')
            })
        
        action_df = pd.DataFrame(action_data)
        
        # Aggregate by action
        action_summary = action_df.groupby('resolution_action').agg({
            'ticket_number': 'count',
            'resolution_hours': ['mean', 'median', 'std', lambda x: x.quantile(0.9)]
        }).round(2)
        
        action_summary.columns = [
            'Total_Tickets',
            'Avg_Resolution_Hours',
            'Median_Resolution_Hours',
            'Std_Resolution_Hours',
            'P90_Resolution_Hours'
        ]
        
        action_summary['Total_Hours'] = (
            action_summary['Total_Tickets'] * action_summary['Avg_Resolution_Hours']
        ).round(0)
        
        action_summary = action_summary.sort_values('Total_Tickets', ascending=False)
        action_summary.to_csv('output_enhanced/05_resolution_correlation/resolution_action_vs_time.csv')
        
        # Cross-tabulation: Issue Type vs Resolution Action
        cross_tab = pd.crosstab(
            action_df['issue_type'],
            action_df['resolution_action'],
            values=action_df['resolution_hours'],
            aggfunc='mean'
        ).round(2)
        
        cross_tab.to_csv('output_enhanced/05_resolution_correlation/issue_type_vs_action_time.csv')
        
        print(f"✓ Analyzed correlation between resolution actions and resolution time")
        
        return action_summary
    
    def generate_charts(self, pattern_df, resolver_stats, caller_stats):
        """Generate comprehensive charts"""
        print("\nGenerating visualization charts...")
        
        # Chart 1: Resolution patterns
        if pattern_df is not None and len(pattern_df) > 0:
            plt.figure(figsize=(14, 8))
            top_patterns = pattern_df.head(15)
            ax = top_patterns.set_index('Resolution_Pattern')['Total_Occurrences'].plot(
                kind='barh',
                color='#1E2761'
            )
            plt.xlabel('Number of Tickets', fontsize=12)
            plt.ylabel('Resolution Pattern', fontsize=12)
            plt.title('Top 15 Resolution Patterns', fontsize=14, fontweight='bold')
            plt.tight_layout()
            plt.savefig('output_enhanced/06_charts/01_resolution_patterns.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # Chart 2: Issue type distribution
        plt.figure(figsize=(10, 8))
        issue_counts = self.df['issue_type'].value_counts()
        colors = ['#F96167', '#F9E795', '#2F3C7E', '#A7BEAE']
        plt.pie(issue_counts, labels=issue_counts.index, autopct='%1.1f%%',
                colors=colors, startangle=90)
        plt.title('Issue Type Distribution (Alert/Error/Warning/Other)', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig('output_enhanced/06_charts/02_issue_type_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # Chart 3: Top resolvers
        if resolver_stats is not None and len(resolver_stats) > 0:
            plt.figure(figsize=(14, 8))
            top_resolvers = resolver_stats.head(15)
            ax = top_resolvers['Total_Tickets_Resolved'].plot(kind='barh', color='#028090')
            plt.xlabel('Tickets Resolved', fontsize=12)
            plt.ylabel('Resolver', fontsize=12)
            plt.title('Top 15 Resolvers by Volume', fontsize=14, fontweight='bold')
            plt.tight_layout()
            plt.savefig('output_enhanced/06_charts/03_top_resolvers.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        # Chart 4: Power users
        if caller_stats is not None and len(caller_stats) > 0:
            plt.figure(figsize=(14, 8))
            top_callers = caller_stats.head(15)
            ax = top_callers['Total_Tickets'].plot(kind='barh', color='#B85042')
            plt.xlabel('Total Tickets', fontsize=12)
            plt.ylabel('Caller', fontsize=12)
            plt.title('Top 15 Power Users (Most Tickets)', fontsize=14, fontweight='bold')
            plt.tight_layout()
            plt.savefig('output_enhanced/06_charts/04_power_users.png', dpi=300, bbox_inches='tight')
            plt.close()
        
        print(f"✓ Generated 4 visualization charts (300 DPI)")
    
    def generate_executive_summary(self, pattern_df, resolver_stats, caller_stats):
        """Generate comprehensive executive summary"""
        print("\nGenerating executive summary...")
        
        with open('output_enhanced/07_summaries/ENHANCED_EXECUTIVE_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("ENHANCED RESOLUTION ANALYSIS - EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Analysis Date: {datetime.now().strftime('%B %d, %Y')}\n")
            f.write(f"Total Tickets Analyzed: {len(self.df):,}\n\n")
            
            # Resolution Patterns
            f.write("\n" + "=" * 100 + "\n")
            f.write("RESOLUTION PATTERNS ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            if pattern_df is not None and len(pattern_df) > 0:
                f.write("Top 10 Resolution Patterns:\n")
                f.write("-" * 100 + "\n")
                for i, row in pattern_df.head(10).iterrows():
                    f.write(f"{i+1:2d}. {row['Resolution_Pattern']:<30s} ")
                    f.write(f"{int(row['Total_Occurrences']):>6,} tickets ")
                    f.write(f"({row['Percentage_of_Total']:>5.2f}%) ")
                    f.write(f"Avg: {row['Avg_Resolution_Hours']:>6.2f}h\n")
            
            # Alert/Error/Warning
            f.write("\n" + "=" * 100 + "\n")
            f.write("ALERT / ERROR / WARNING ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            issue_dist = self.df['issue_type'].value_counts()
            for issue_type, count in issue_dist.items():
                issue_df = self.df[self.df['issue_type'] == issue_type]
                pct = count / len(self.df) * 100
                avg_time = issue_df['resolution_hours'].mean()
                f.write(f"{issue_type:<15s}: {count:>8,} tickets ({pct:>5.1f}%) ")
                f.write(f"Avg Resolution: {avg_time:>6.2f} hours\n")
            
            # Resolver Performance
            f.write("\n" + "=" * 100 + "\n")
            f.write("TOP RESOLVER PERFORMANCE\n")
            f.write("=" * 100 + "\n\n")
            
            if resolver_stats is not None and len(resolver_stats) > 0:
                f.write("Top 10 Resolvers:\n")
                f.write("-" * 100 + "\n")
                for i, (resolver, row) in enumerate(resolver_stats.head(10).iterrows(), 1):
                    f.write(f"{i:2d}. {resolver[:30]:<30s} ")
                    f.write(f"{int(row['Total_Tickets_Resolved']):>6,} tickets ")
                    f.write(f"Avg: {row['Avg_Resolution_Hours']:>6.2f}h ")
                    f.write(f"Spec: {row.get('Specialization', 'N/A')}\n")
            
            # Caller Analysis
            f.write("\n" + "=" * 100 + "\n")
            f.write("CALLER / REQUESTER ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            if caller_stats is not None and len(caller_stats) > 0:
                f.write("Top 10 Power Users (Most Tickets):\n")
                f.write("-" * 100 + "\n")
                for i, (caller, row) in enumerate(caller_stats.head(10).iterrows(), 1):
                    f.write(f"{i:2d}. {caller[:30]:<30s} ")
                    f.write(f"{int(row['Total_Tickets']):>6,} tickets ")
                    f.write(f"Common: {row['Most_Common_Category'][:25]}\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("END OF EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n")
        
        print(f"✓ Executive summary generated")
    
    def run_full_enhanced_analysis(self):
        """Run complete enhanced analysis"""
        print("\n" + "=" * 100)
        print("STARTING ENHANCED RESOLUTION ANALYSIS".center(100))
        print("=" * 100)
        
        self.prepare_data()
        
        pattern_df = self.analyze_resolution_patterns()
        resolver_stats = self.analyze_resolvers()
        caller_stats = self.analyze_callers()
        self.analyze_alert_error_warning()
        self.analyze_resolution_correlation()
        
        self.generate_charts(pattern_df, resolver_stats, caller_stats)
        self.generate_executive_summary(pattern_df, resolver_stats, caller_stats)
        
        print("\n" + "=" * 100)
        print("ENHANCED RESOLUTION ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\nOutputs saved to output_enhanced/ with 7 subdirectories:")
        print("  📊 01_resolution_patterns/ - Detailed pattern analysis")
        print("  📊 02_resolver_analysis/ - Assigned_to performance")
        print("  📊 03_caller_analysis/ - Caller_id statistics")
        print("  📊 04_alert_error_warning/ - Alert/Error/Warning breakdowns")
        print("  📊 05_resolution_correlation/ - Action vs time correlation")
        print("  📊 06_charts/ - Visualization charts (4 PNGs)")
        print("  📊 07_summaries/ - Executive summary")
        print("\n" + "=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = EnhancedResolutionAnalyzer(FILE_PATH)
        analyzer.run_full_enhanced_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
