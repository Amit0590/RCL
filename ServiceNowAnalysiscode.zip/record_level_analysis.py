"""
Record-Level Analysis for ServiceNow Tickets
Creates detailed analysis with enriched data for each individual ticket

Author: Automated Analysis Tool
Date: 2025
"""

import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class RecordLevelAnalyzer:
    def __init__(self, file_path):
        """
        Initialize record-level analyzer
        
        Parameters:
        file_path (str): Path to the CSV file containing ticket data
        """
        print("Loading ticket data for record-level analysis...")
        
        # Try different encodings
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        df_loaded = False
        
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Successfully loaded with {encoding} encoding")
                df_loaded = True
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
            except Exception as e:
                if 'codec' not in str(e).lower():
                    raise
        
        if not df_loaded:
            raise ValueError("Could not read CSV file. Try running: py fix_encoding.py")
        
        print(f"Loaded {len(self.df):,} tickets")
        
        import os
        os.makedirs('output/record_level', exist_ok=True)
        
    def enrich_ticket_data(self):
        """Add calculated fields and enrichments to each ticket"""
        print("\nEnriching ticket data with calculated fields...")
        
        # Convert dates
        date_columns = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_columns:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        # Calculate time metrics
        if 'opened_at' in self.df.columns and 'resolved_at' in self.df.columns:
            self.df['resolution_time_hours'] = (
                self.df['resolved_at'] - self.df['opened_at']
            ).dt.total_seconds() / 3600
            self.df['resolution_time_days'] = self.df['resolution_time_hours'] / 24
            
        if 'resolved_at' in self.df.columns and 'closed_at' in self.df.columns:
            self.df['closure_time_hours'] = (
                self.df['closed_at'] - self.df['resolved_at']
            ).dt.total_seconds() / 3600
            self.df['closure_time_days'] = self.df['closure_time_hours'] / 24
        
        # Add time-based fields
        if 'opened_at' in self.df.columns:
            self.df['opened_date'] = self.df['opened_at'].dt.date
            self.df['opened_hour'] = self.df['opened_at'].dt.hour
            self.df['opened_day_of_week'] = self.df['opened_at'].dt.day_name()
            self.df['opened_month'] = self.df['opened_at'].dt.month
            self.df['opened_month_name'] = self.df['opened_at'].dt.month_name()
            self.df['opened_year'] = self.df['opened_at'].dt.year
            self.df['opened_quarter'] = self.df['opened_at'].dt.quarter
        
        # Calculate category-level metrics for each ticket
        print("Calculating comparative metrics...")
        
        # Average resolution time by category
        category_avg = self.df.groupby('category')['resolution_time_hours'].mean()
        self.df['category_avg_resolution_hours'] = self.df['category'].map(category_avg)
        
        # Average resolution time by priority
        priority_avg = self.df.groupby('priority')['resolution_time_hours'].mean()
        self.df['priority_avg_resolution_hours'] = self.df['priority'].map(priority_avg)
        
        # Average resolution time by assignment group
        group_avg = self.df.groupby('assignment_group')['resolution_time_hours'].mean()
        self.df['group_avg_resolution_hours'] = self.df['assignment_group'].map(group_avg)
        
        # Performance vs. category average
        self.df['vs_category_avg'] = self.df['resolution_time_hours'] - self.df['category_avg_resolution_hours']
        self.df['category_percentile'] = self.df.groupby('category')['resolution_time_hours'].rank(pct=True) * 100
        
        # Performance vs. priority average
        self.df['vs_priority_avg'] = self.df['resolution_time_hours'] - self.df['priority_avg_resolution_hours']
        
        # Overall percentile
        self.df['overall_percentile'] = self.df['resolution_time_hours'].rank(pct=True) * 100
        
        # Flag quick/slow tickets
        median_resolution = self.df['resolution_time_hours'].median()
        self.df['resolution_speed'] = 'Normal'
        self.df.loc[self.df['resolution_time_hours'] <= median_resolution * 0.5, 'resolution_speed'] = 'Very Fast'
        self.df.loc[self.df['resolution_time_hours'] <= median_resolution, 'resolution_speed'] = 'Fast'
        self.df.loc[self.df['resolution_time_hours'] >= median_resolution * 2, 'resolution_speed'] = 'Slow'
        self.df.loc[self.df['resolution_time_hours'] >= median_resolution * 3, 'resolution_speed'] = 'Very Slow'
        
        # Count occurrences of same issue
        desc_counts = self.df['short_description'].value_counts()
        self.df['issue_occurrence_count'] = self.df['short_description'].map(desc_counts)
        
        # Flag recurring issues
        self.df['is_recurring_issue'] = self.df['issue_occurrence_count'] >= 10
        
        # Flag potential automation candidates
        self.df['automation_candidate'] = (
            (self.df['issue_occurrence_count'] >= 5) & 
            (self.df['resolution_time_hours'] <= median_resolution * 1.5)
        )
        
        # Description length
        self.df['description_length'] = self.df['description'].fillna('').str.len()
        
        # SLA compliance (adjust these values to your actual SLAs)
        sla_targets = {
            '1 - Critical': 4,
            '2 - High': 8,
            '3 - Moderate': 24,
            '4 - Low': 72,
            '5 - Minimal': 120
        }
        
        self.df['sla_target_hours'] = self.df['priority'].map(sla_targets)
        self.df['sla_breach'] = self.df['resolution_time_hours'] > self.df['sla_target_hours']
        self.df['sla_margin_hours'] = self.df['sla_target_hours'] - self.df['resolution_time_hours']
        
        print(f"✓ Enrichment complete - added {len([col for col in self.df.columns if col not in ['number', 'opened_at', 'resolved_at', 'closed_at', 'short_description', 'description', 'service_offering', 'caller_id', 'priority', 'state', 'category', 'assignment_group', 'assigned_to', 'close_notes']])} new fields")
        
    def create_full_enriched_export(self):
        """Export all tickets with all enriched fields"""
        print("\nCreating full enriched export...")
        
        # Select columns in a logical order
        columns_order = [
            # Original fields
            'number',
            'opened_at',
            'resolved_at', 
            'closed_at',
            'short_description',
            'description',
            'category',
            'priority',
            'state',
            'assignment_group',
            'assigned_to',
            'service_offering',
            'caller_id',
            'close_notes',
            
            # Time metrics
            'resolution_time_hours',
            'resolution_time_days',
            'closure_time_hours',
            'closure_time_days',
            
            # Date/time breakdown
            'opened_date',
            'opened_hour',
            'opened_day_of_week',
            'opened_month_name',
            'opened_quarter',
            'opened_year',
            
            # Performance metrics
            'resolution_speed',
            'overall_percentile',
            'category_percentile',
            'category_avg_resolution_hours',
            'vs_category_avg',
            'priority_avg_resolution_hours',
            'vs_priority_avg',
            'group_avg_resolution_hours',
            
            # SLA metrics
            'sla_target_hours',
            'sla_breach',
            'sla_margin_hours',
            
            # Recurrence metrics
            'issue_occurrence_count',
            'is_recurring_issue',
            'automation_candidate',
            
            # Other
            'description_length'
        ]
        
        # Only include columns that exist
        export_columns = [col for col in columns_order if col in self.df.columns]
        
        output_file = 'output/record_level/all_tickets_enriched.csv'
        self.df[export_columns].to_csv(output_file, index=False)
        
        print(f"✓ Full enriched export saved: {output_file}")
        print(f"  Total records: {len(self.df):,}")
        print(f"  Total columns: {len(export_columns)}")
        
        return output_file
    
    def create_filtered_exports(self):
        """Create filtered exports for specific use cases"""
        print("\nCreating filtered exports...")
        
        exports_created = []
        
        # 1. SLA Breaches Only
        sla_breaches = self.df[self.df['sla_breach'] == True].copy()
        if len(sla_breaches) > 0:
            file = 'output/record_level/sla_breaches.csv'
            sla_breaches.to_csv(file, index=False)
            exports_created.append(f"SLA Breaches ({len(sla_breaches):,} tickets)")
            print(f"  ✓ SLA breaches: {len(sla_breaches):,} tickets")
        
        # 2. Automation Candidates
        automation = self.df[self.df['automation_candidate'] == True].copy()
        if len(automation) > 0:
            file = 'output/record_level/automation_candidates_detailed.csv'
            automation = automation.sort_values('issue_occurrence_count', ascending=False)
            automation.to_csv(file, index=False)
            exports_created.append(f"Automation Candidates ({len(automation):,} tickets)")
            print(f"  ✓ Automation candidates: {len(automation):,} tickets")
        
        # 3. Very Slow Tickets
        very_slow = self.df[self.df['resolution_speed'] == 'Very Slow'].copy()
        if len(very_slow) > 0:
            file = 'output/record_level/very_slow_tickets.csv'
            very_slow = very_slow.sort_values('resolution_time_hours', ascending=False)
            very_slow.to_csv(file, index=False)
            exports_created.append(f"Very Slow Tickets ({len(very_slow):,} tickets)")
            print(f"  ✓ Very slow tickets: {len(very_slow):,} tickets")
        
        # 4. Very Fast Tickets (potential automation)
        very_fast = self.df[self.df['resolution_speed'] == 'Very Fast'].copy()
        if len(very_fast) > 0:
            file = 'output/record_level/very_fast_tickets.csv'
            very_fast.to_csv(file, index=False)
            exports_created.append(f"Very Fast Tickets ({len(very_fast):,} tickets)")
            print(f"  ✓ Very fast tickets: {len(very_fast):,} tickets")
        
        # 5. Recurring Issues
        recurring = self.df[self.df['is_recurring_issue'] == True].copy()
        if len(recurring) > 0:
            file = 'output/record_level/recurring_issues_detailed.csv'
            recurring = recurring.sort_values('issue_occurrence_count', ascending=False)
            recurring.to_csv(file, index=False)
            exports_created.append(f"Recurring Issues ({len(recurring):,} tickets)")
            print(f"  ✓ Recurring issues: {len(recurring):,} tickets")
        
        # 6. By Category - Top 5 Categories
        top_categories = self.df['category'].value_counts().head(5).index
        for category in top_categories:
            cat_tickets = self.df[self.df['category'] == category].copy()
            safe_filename = category.replace('/', '_').replace('?', '').replace(' ', '_')[:50]
            file = f'output/record_level/category_{safe_filename}.csv'
            cat_tickets.to_csv(file, index=False)
            exports_created.append(f"Category: {category} ({len(cat_tickets):,} tickets)")
            print(f"  ✓ Category '{category}': {len(cat_tickets):,} tickets")
        
        return exports_created
    
    def create_summary_report(self):
        """Create a summary report about the enriched data"""
        print("\nGenerating record-level summary report...")
        
        with open('output/record_level/RECORD_ANALYSIS_SUMMARY.txt', 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("RECORD-LEVEL ANALYSIS SUMMARY\n")
            f.write("=" * 80 + "\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Tickets Analyzed: {len(self.df):,}\n\n")
            
            f.write("ENRICHED FIELDS ADDED\n")
            f.write("-" * 80 + "\n")
            f.write("• resolution_time_hours/days - How long to resolve\n")
            f.write("• closure_time_hours/days - Time from resolve to close\n")
            f.write("• opened_hour/day_of_week/month - Temporal breakdown\n")
            f.write("• resolution_speed - Fast/Normal/Slow classification\n")
            f.write("• overall_percentile - Where ticket ranks vs all tickets\n")
            f.write("• category_percentile - Where ticket ranks within its category\n")
            f.write("• vs_category_avg - Hours above/below category average\n")
            f.write("• sla_breach - Whether ticket breached SLA\n")
            f.write("• sla_margin_hours - Hours before/after SLA\n")
            f.write("• issue_occurrence_count - How many times this issue occurred\n")
            f.write("• is_recurring_issue - True if occurs 10+ times\n")
            f.write("• automation_candidate - True if good candidate for automation\n\n")
            
            f.write("KEY STATISTICS\n")
            f.write("-" * 80 + "\n")
            
            # Resolution speed breakdown
            f.write("\nResolution Speed Distribution:\n")
            speed_dist = self.df['resolution_speed'].value_counts()
            for speed, count in speed_dist.items():
                pct = (count / len(self.df)) * 100
                f.write(f"  {speed}: {count:,} ({pct:.1f}%)\n")
            
            # SLA breaches
            sla_breaches = self.df['sla_breach'].sum()
            sla_pct = (sla_breaches / len(self.df)) * 100
            f.write(f"\nSLA Breaches: {sla_breaches:,} ({sla_pct:.1f}%)\n")
            
            # Automation candidates
            auto_candidates = self.df['automation_candidate'].sum()
            auto_pct = (auto_candidates / len(self.df)) * 100
            f.write(f"Automation Candidates: {auto_candidates:,} ({auto_pct:.1f}%)\n")
            
            # Recurring issues
            recurring = self.df['is_recurring_issue'].sum()
            recurring_pct = (recurring / len(self.df)) * 100
            f.write(f"Recurring Issues: {recurring:,} ({recurring_pct:.1f}%)\n")
            
            f.write("\n" + "=" * 80 + "\n")
            f.write("FILES CREATED\n")
            f.write("=" * 80 + "\n")
            f.write("• all_tickets_enriched.csv - Every ticket with all enriched fields\n")
            f.write("• sla_breaches.csv - Only tickets that breached SLA\n")
            f.write("• automation_candidates_detailed.csv - Tickets to automate\n")
            f.write("• very_slow_tickets.csv - Tickets in slowest category\n")
            f.write("• very_fast_tickets.csv - Tickets resolved very quickly\n")
            f.write("• recurring_issues_detailed.csv - Issues that occur 10+ times\n")
            f.write("• category_*.csv - Individual files for top 5 categories\n")
            f.write("\n" + "=" * 80 + "\n")
        
        print("✓ Summary report saved")
    
    def run_full_record_analysis(self):
        """Run complete record-level analysis"""
        print("\n" + "=" * 60)
        print("STARTING RECORD-LEVEL ANALYSIS")
        print("=" * 60)
        
        self.enrich_ticket_data()
        self.create_full_enriched_export()
        self.create_filtered_exports()
        self.create_summary_report()
        
        print("\n" + "=" * 60)
        print("RECORD-LEVEL ANALYSIS COMPLETE!")
        print("=" * 60)
        print("\nAll files saved to: output/record_level/")
        print("\nKey files:")
        print("  • all_tickets_enriched.csv - MAIN FILE with all tickets")
        print("  • sla_breaches.csv - Filter by SLA issues")
        print("  • automation_candidates_detailed.csv - What to automate")
        print("  • RECORD_ANALYSIS_SUMMARY.txt - Overview of analysis")
        print("\nYou can now:")
        print("  1. Open any CSV in Excel for filtering/sorting")
        print("  2. Create pivot tables on the enriched data")
        print("  3. Filter by any of the new calculated fields")
        print("  4. Analyze individual tickets with full context")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = RecordLevelAnalyzer(FILE_PATH)
        analyzer.run_full_record_analysis()
        
    except FileNotFoundError:
        print(f"\nERROR: File '{FILE_PATH}' not found!")
        print("Please update the FILE_PATH variable with the correct path to your CSV file.")
    except Exception as e:
        print(f"\nERROR: An error occurred:")
        print(f"{str(e)}")
        import traceback
        traceback.print_exc()
