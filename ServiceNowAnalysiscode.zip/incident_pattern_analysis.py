"""
INCIDENT PATTERN ANALYSIS
ML-based pattern detection from short_description and close_notes to improve categorization
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class IncidentPatternAnalyzer:
    def __init__(self, file_path):
        print("=" * 100)
        print("INCIDENT PATTERN ANALYSIS - CATEGORY IMPROVEMENT".center(100))
        print("=" * 100)
        print("\nAnalyzing patterns to improve categorization...\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        os.makedirs('output_pattern_analysis', exist_ok=True)
        os.makedirs('output_pattern_analysis/pattern_reports', exist_ok=True)
        os.makedirs('output_pattern_analysis/suggested_categories', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing pattern analysis dataset...")
        
        self.df['short_description_clean'] = self.df['short_description'].fillna('').astype(str).str.lower()
        self.df['close_notes_clean'] = self.df['close_notes'].fillna('').astype(str).str.lower()
        self.df['category_clean'] = self.df['category'].fillna('Unknown').astype(str)
        
        print("✓ Dataset prepared\n")
    
    def extract_keywords(self, text, min_length=3):
        """Extract meaningful keywords from text"""
        words = re.findall(r'\b[a-z]{' + str(min_length) + r',}\b', text)
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                    'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should', 'can',
                    'may', 'might', 'must', 'shall', 'into', 'onto', 'upon', 'about', 'over'}
        return [w for w in words if w not in stopwords]
    
    def detect_patterns(self):
        print("Detecting patterns from short_description and close_notes...")
        
        patterns = {
            'Batch Job Issues': {
                'keywords': ['batch', 'job', 'failed', 'failure', 'timeout', 'dtexec', 'schedule', 'execution'],
                'resolution_keywords': ['rerun', 'restart', 'restarted', 'executed', 'manually', 'fixed']
            },
            'Database Issues': {
                'keywords': ['database', 'sql', 'query', 'connection', 'timeout', 'deadlock', 'table', 'oracle'],
                'resolution_keywords': ['index', 'restarted', 'killed', 'session', 'optimized', 'analyzed']
            },
            'Performance Issues': {
                'keywords': ['slow', 'performance', 'degraded', 'timeout', 'hanging', 'response', 'latency'],
                'resolution_keywords': ['optimized', 'tuned', 'restarted', 'cleared', 'cache', 'increased']
            },
            'Access/Permission Issues': {
                'keywords': ['access', 'permission', 'denied', 'unauthorized', 'login', 'authentication', 'credential'],
                'resolution_keywords': ['granted', 'added', 'reset', 'updated', 'enabled', 'permission']
            },
            'Service Down/Outage': {
                'keywords': ['down', 'outage', 'unavailable', 'not responding', 'offline', 'stopped', 'crash'],
                'resolution_keywords': ['restarted', 'restart', 'brought up', 'started', 'recovered']
            },
            'Configuration Issues': {
                'keywords': ['config', 'configuration', 'setting', 'parameter', 'property', 'incorrect'],
                'resolution_keywords': ['corrected', 'updated', 'changed', 'modified', 'configured']
            },
            'Network/Connectivity Issues': {
                'keywords': ['network', 'connection', 'connectivity', 'timeout', 'unreachable', 'vpn', 'firewall'],
                'resolution_keywords': ['restored', 'reconnected', 'fixed', 'route', 'opened']
            },
            'Data Issues': {
                'keywords': ['data', 'missing', 'corrupt', 'incorrect', 'invalid', 'duplicate', 'mismatch'],
                'resolution_keywords': ['corrected', 'updated', 'deleted', 'reprocessed', 'fixed']
            },
            'Alert/Monitoring Issues': {
                'keywords': ['alert', 'alarm', 'monitoring', 'notification', 'warning', 'threshold'],
                'resolution_keywords': ['acknowledged', 'cleared', 'adjusted', 'tuned', 'disabled']
            },
            'Disk Space Issues': {
                'keywords': ['disk', 'space', 'storage', 'full', 'capacity', 'volume', 'drive'],
                'resolution_keywords': ['cleaned', 'deleted', 'archived', 'expanded', 'freed']
            }
        }
        
        self.df['detected_pattern'] = 'Unclassified'
        self.df['pattern_confidence'] = 0.0
        
        for idx, row in self.df.iterrows():
            text = f"{row['short_description_clean']} {row['close_notes_clean']}"
            
            scores = {}
            for pattern_name, pattern_def in patterns.items():
                keyword_matches = sum(1 for kw in pattern_def['keywords'] if kw in text)
                resolution_matches = sum(1 for kw in pattern_def['resolution_keywords'] if kw in text)
                total_score = (keyword_matches * 2) + resolution_matches
                scores[pattern_name] = total_score
            
            if scores:
                best_pattern = max(scores, key=scores.get)
                best_score = scores[best_pattern]
                
                if best_score >= 2:
                    self.df.at[idx, 'detected_pattern'] = best_pattern
                    self.df.at[idx, 'pattern_confidence'] = min(best_score / 5, 1.0)
        
        print(f"✓ Detected patterns for {(self.df['detected_pattern'] != 'Unclassified').sum():,} incidents\n")
    
    def generate_pattern_summary(self):
        print("Generating pattern analysis summary...")
        
        with open('output_pattern_analysis/PATTERN_ANALYSIS_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("INCIDENT PATTERN ANALYSIS SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Total Incidents Analyzed: {len(self.df):,}\n")
            f.write(f"Patterns Detected: {(self.df['detected_pattern'] != 'Unclassified').sum():,}\n")
            f.write(f"Unclassified: {(self.df['detected_pattern'] == 'Unclassified').sum():,}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("DETECTED PATTERN DISTRIBUTION\n")
            f.write("=" * 100 + "\n\n")
            
            pattern_dist = self.df['detected_pattern'].value_counts()
            f.write(f"{'Pattern':<40}{'Count':<12}{'% Total'}\n")
            f.write("-" * 100 + "\n")
            for pattern, count in pattern_dist.items():
                pct = count / len(self.df) * 100
                f.write(f"{pattern:<40}{count:<12,}{pct:.2f}%\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("CURRENT CATEGORY vs DETECTED PATTERN COMPARISON\n")
            f.write("=" * 100 + "\n\n")
            
            for pattern in pattern_dist.index[:10]:
                if pattern != 'Unclassified':
                    pattern_data = self.df[self.df['detected_pattern'] == pattern]
                    current_cats = pattern_data['category_clean'].value_counts().head(5)
                    
                    f.write(f"\nDetected Pattern: {pattern} ({len(pattern_data):,} incidents)\n")
                    f.write(f"Current Categories:\n")
                    for cat, count in current_cats.items():
                        pct = count / len(pattern_data) * 100
                        f.write(f"  - {cat}: {count:,} ({pct:.1f}%)\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("CATEGORY ACCURACY ASSESSMENT\n")
            f.write("=" * 100 + "\n\n")
            
            category_mapping = {
                'Batch Job Issues': ['Broken / Damaged / Failed?', 'Other'],
                'Database Issues': ['Poor Performance', 'Broken / Damaged / Failed?'],
                'Performance Issues': ['Poor Performance'],
                'Access/Permission Issues': ['Cannot log in', 'Other'],
                'Service Down/Outage': ['Broken / Damaged / Failed?', 'Alert / Error / Warning'],
                'Configuration Issues': ['Other', 'Broken / Damaged / Failed?'],
                'Data Issues': ['Reporting a data issue / Corrupt data']
            }
            
            for pattern, expected_cats in category_mapping.items():
                pattern_data = self.df[self.df['detected_pattern'] == pattern]
                if len(pattern_data) > 0:
                    correctly_categorized = pattern_data[pattern_data['category_clean'].isin(expected_cats)]
                    accuracy = len(correctly_categorized) / len(pattern_data) * 100
                    
                    f.write(f"\n{pattern}:\n")
                    f.write(f"  Total incidents: {len(pattern_data):,}\n")
                    f.write(f"  Correctly categorized: {len(correctly_categorized):,} ({accuracy:.1f}%)\n")
                    f.write(f"  Expected categories: {', '.join(expected_cats)}\n")
        
        print("✓ Created pattern analysis summary\n")
    
    def generate_suggested_categories(self):
        print("Generating suggested category corrections...")
        
        output_dir = 'output_pattern_analysis/suggested_categories'
        
        category_suggestions = []
        
        for idx, row in self.df.iterrows():
            if row['detected_pattern'] != 'Unclassified':
                suggestion = self._suggest_category(row['detected_pattern'], row['category_clean'])
                
                if suggestion != row['category_clean']:
                    category_suggestions.append({
                        'number': row['number'],
                        'current_category': row['category_clean'],
                        'suggested_category': suggestion,
                        'detected_pattern': row['detected_pattern'],
                        'confidence': row['pattern_confidence'],
                        'short_description': row['short_description'],
                        'close_notes_preview': row['close_notes'][:200] if pd.notna(row['close_notes']) else ''
                    })
        
        if category_suggestions:
            suggestions_df = pd.DataFrame(category_suggestions)
            suggestions_df = suggestions_df.sort_values('confidence', ascending=False)
            suggestions_df.to_csv(f'{output_dir}/category_corrections.csv', index=False)
            
            high_confidence = suggestions_df[suggestions_df['confidence'] >= 0.6]
            if len(high_confidence) > 0:
                high_confidence.to_csv(f'{output_dir}/high_confidence_corrections.csv', index=False)
        
        print(f"✓ Generated {len(category_suggestions):,} category correction suggestions\n")
    
    def _suggest_category(self, pattern, current_category):
        """Suggest better category based on detected pattern"""
        
        pattern_to_category = {
            'Batch Job Issues': 'Broken / Damaged / Failed?',
            'Database Issues': 'Poor Performance',
            'Performance Issues': 'Poor Performance',
            'Access/Permission Issues': 'Cannot log in',
            'Service Down/Outage': 'Broken / Damaged / Failed?',
            'Configuration Issues': 'Other',
            'Network/Connectivity Issues': 'Broken / Damaged / Failed?',
            'Data Issues': 'Reporting a data issue / Corrupt data',
            'Alert/Monitoring Issues': 'Alert / Error / Warning',
            'Disk Space Issues': 'Broken / Damaged / Failed?'
        }
        
        return pattern_to_category.get(pattern, current_category)
    
    def generate_pattern_reports(self):
        print("Generating detailed pattern reports...")
        
        output_dir = 'output_pattern_analysis/pattern_reports'
        
        pattern_summary = self.df.groupby('detected_pattern').agg({
            'number': 'count',
            'category_clean': lambda x: x.value_counts().to_dict(),
            'service_offering': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple',
            'assignment_group': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple'
        })
        pattern_summary.columns = ['Total_Count', 'Current_Categories', 'Primary_Service', 'Primary_Team']
        pattern_summary.to_csv(f'{output_dir}/pattern_summary.csv')
        
        for pattern in self.df['detected_pattern'].value_counts().head(10).index:
            if pattern != 'Unclassified':
                pattern_data = self.df[self.df['detected_pattern'] == pattern]
                
                pattern_detail = pattern_data[[
                    'number', 'category_clean', 'short_description', 'close_notes',
                    'service_offering', 'assignment_group', 'pattern_confidence'
                ]].copy()
                
                safe_name = re.sub(r'[<>:"/\\|?*]', '_', str(pattern))[:50]
                pattern_detail.to_csv(f'{output_dir}/pattern_{safe_name}.csv', index=False)
        
        print(f"✓ Created detailed pattern reports\n")
    
    def generate_master_excel(self):
        print("Generating PATTERN_ANALYSIS_MASTER.xlsx...")
        
        excel_file = 'output_pattern_analysis/PATTERN_ANALYSIS_MASTER.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            overall = pd.DataFrame({
                'Metric': ['Total Incidents', 'Patterns Detected', 'Unclassified',
                          'High Confidence (>60%)', 'Medium Confidence (40-60%)', 'Low Confidence (<40%)',
                          'Category Corrections Suggested'],
                'Value': [
                    len(self.df),
                    (self.df['detected_pattern'] != 'Unclassified').sum(),
                    (self.df['detected_pattern'] == 'Unclassified').sum(),
                    (self.df['pattern_confidence'] >= 0.6).sum(),
                    ((self.df['pattern_confidence'] >= 0.4) & (self.df['pattern_confidence'] < 0.6)).sum(),
                    (self.df['pattern_confidence'] < 0.4).sum(),
                    len(self.df[self.df['detected_pattern'] != 'Unclassified'])
                ]
            })
            overall.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            pattern_summary = self.df.groupby('detected_pattern').agg({
                'number': 'count',
                'pattern_confidence': 'mean'
            }).round(3)
            pattern_summary.columns = ['Total_Incidents', 'Avg_Confidence']
            pattern_summary['Percentage'] = (pattern_summary['Total_Incidents'] / len(self.df) * 100).round(2)
            pattern_summary.sort_values('Total_Incidents', ascending=False).to_excel(writer, sheet_name='02_By_Pattern')
            
            cross_pattern_category = pd.crosstab(
                self.df['detected_pattern'],
                self.df['category_clean'],
                values=self.df['number'],
                aggfunc='count'
            ).fillna(0)
            cross_pattern_category.to_excel(writer, sheet_name='03_Pattern_vs_Category')
            
            high_conf = self.df[self.df['pattern_confidence'] >= 0.6]
            if len(high_conf) > 0:
                high_conf_summary = high_conf.groupby('detected_pattern')['number'].count()
                high_conf_summary.to_excel(writer, sheet_name='04_High_Confidence')
        
        print(f"✓ Created master Excel: {excel_file}\n")
    
    def run_full_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING PATTERN ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.detect_patterns()
        self.generate_pattern_summary()
        self.generate_suggested_categories()
        self.generate_pattern_reports()
        self.generate_master_excel()
        
        print("\n" + "=" * 100)
        print("PATTERN ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_pattern_analysis/\n")
        print("SUMMARY FILES:")
        print("  ✓ PATTERN_ANALYSIS_SUMMARY.txt")
        print("  ✓ PATTERN_ANALYSIS_MASTER.xlsx\n")
        print("DETAILED FILES:")
        print("  ✓ suggested_categories/category_corrections.csv")
        print("  ✓ suggested_categories/high_confidence_corrections.csv")
        print("  ✓ pattern_reports/ (pattern-specific reports)\n")
        print("=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = IncidentPatternAnalyzer(FILE_PATH)
        analyzer.run_full_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
