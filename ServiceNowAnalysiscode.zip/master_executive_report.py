"""
MASTER EXECUTIVE REPORT
Comprehensive analysis combining ALL analytics into ONE detailed report
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
from datetime import datetime
import warnings
import os
warnings.filterwarnings('ignore')

class MasterExecutiveReport:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        print("=" * 100)
        print("MASTER EXECUTIVE REPORT GENERATOR".center(100))
        print("=" * 100)
        print("\nGenerating comprehensive executive report with ALL analytics...\n")
        
        # Load data
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load application mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
            print("⚠ Using service_offering for applications")
        
        os.makedirs('output_master_report', exist_ok=True)
        print("✓ Created output directory\n")
    
    def prepare_data(self):
        print("Preparing comprehensive dataset...")
        
        # Map applications
        if self.mapping_dict:
            self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        else:
            self.df['application'] = self.df.get('service_offering', 'Unknown')
        
        self.df['application'] = self.df['application'].fillna('Unknown')
        
        # Clean fields
        self.df['short_description'] = self.df['short_description'].fillna('').astype(str)
        self.df['close_notes'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['assigned_to'] = self.df.get('assigned_to', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        self.df['assignment_group'] = self.df.get('assignment_group', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        self.df['category'] = self.df.get('category', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        self.df['priority'] = self.df.get('priority', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        
        # Parse dates
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        # Calculate resolution time
        self.df['resolution_hours'] = (self.df['resolved_at'] - self.df['opened_at']).dt.total_seconds() / 3600
        
        # Only analyze resolved incidents
        self.df = self.df[
            (self.df['close_notes'].str.len() > 10) & 
            (self.df['resolution_hours'].notna())
        ].copy()
        
        print(f"✓ Prepared {len(self.df):,} resolved incidents for analysis\n")
    
    def analyze_all(self):
        print("Running comprehensive analysis...")
        
        # 1. Cluster by short description
        self.df['desc_normalized'] = self.df['short_description'].apply(self._normalize)
        self.df['cluster_signature'] = self.df['desc_normalized'].apply(self._extract_signature)
        self.df['cluster_id'] = self.df.groupby('cluster_signature').ngroup()
        
        # 2. Extract resolution actions
        self.df['resolution_action'] = self.df['close_notes'].apply(self._extract_action)
        
        # 3. Calculate cluster statistics - FIXED: Use proper aggregation
        cluster_agg = self.df.groupby('cluster_id').agg({
            'number': 'count',
            'short_description': 'first',
            'application': lambda x: ', '.join(x.value_counts().head(3).index.tolist()),
            'assigned_to': 'nunique',
            'assignment_group': lambda x: ', '.join(x.value_counts().head(3).index.tolist()),
            'resolution_hours': ['mean', 'sum'],
            'resolution_action': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Other',
            'close_notes': lambda x: str(x.iloc[0])[:200]
        })
        
        cluster_agg.columns = ['Count', 'Example_Issue', 'Top_Applications', 'Team_Members',
                              'Top_Teams', 'Avg_Hours', 'Total_Hours', 'Action', 'Example_Resolution']
        
        # Filter and sort
        cluster_agg = cluster_agg[cluster_agg['Count'] >= 5].sort_values('Count', ascending=False)
        
        # CRITICAL FIX: Create new columns BEFORE assignment to avoid dtype issues
        cluster_agg = cluster_agg.copy()
        cluster_agg['Automation_Rate'] = 0.0
        cluster_agg['Hours_Saved'] = 0.0
        cluster_agg['Team_Freed'] = 0.0
        
        self.clusters = cluster_agg
        
        # 4. Application analysis
        self.app_summary = self.df.groupby('application').agg({
            'number': 'count',
            'assigned_to': 'nunique',
            'resolution_hours': ['sum', 'mean'],
            'cluster_id': 'nunique'
        })
        self.app_summary.columns = ['Total_Incidents', 'Team_Members', 'Total_Hours', 'Avg_Hours', 'Unique_Issues']
        self.app_summary = self.app_summary.sort_values('Total_Hours', ascending=False)
        
        # 5. Team analysis
        self.team_summary = self.df.groupby('assignment_group').agg({
            'number': 'count',
            'assigned_to': 'nunique',
            'resolution_hours': ['sum', 'mean'],
            'cluster_id': 'nunique'
        })
        self.team_summary.columns = ['Total_Incidents', 'Team_Size', 'Total_Hours', 'Avg_Hours', 'Unique_Issues']
        self.team_summary = self.team_summary.sort_values('Total_Hours', ascending=False)
        
        # 6. Calculate reduction potential
        self.calculate_reduction_potential()
        
        print(f"✓ Analysis complete\n")
    
    def _normalize(self, text):
        """Normalize text"""
        text = str(text).lower()
        text = re.sub(r'\d{4,}', 'NUM', text)
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IP', text)
        text = re.sub(r'\b[a-z]{2,4}\d{2}[a-z0-9]+\b', 'SERVER', text)
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def _extract_signature(self, text):
        """Extract signature from text"""
        words = text.split()
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'error', 'failure'}
        meaningful = [w for w in words if w not in stopwords and len(w) > 3][:8]
        return ' '.join(sorted(meaningful)) if meaningful else text[:50]
    
    def _extract_action(self, text):
        """Extract resolution action"""
        text_lower = str(text).lower()
        
        if re.search(r'\b(restart|restarted|reboot|rebooted)\b', text_lower):
            return 'Restarted'
        elif re.search(r'\b(clear|cleared|delete|deleted)\b', text_lower):
            return 'Cleared'
        elif re.search(r'\b(reset)\b', text_lower):
            return 'Reset'
        elif re.search(r'\b(execute|executed|run|ran|rerun)\b', text_lower):
            return 'Executed'
        elif re.search(r'\b(fix|fixed|correct|corrected)\b', text_lower):
            return 'Fixed'
        elif re.search(r'\b(update|updated|modify|modified)\b', text_lower):
            return 'Updated'
        elif re.search(r'\b(grant|granted|add|added)\b', text_lower):
            return 'Granted'
        else:
            return 'Other'
    
    def calculate_reduction_potential(self):
        """Calculate automation potential for each cluster"""
        
        # Calculate values for each row
        automation_rates = []
        hours_saved = []
        team_freed = []
        
        for idx, row in self.clusters.iterrows():
            action = row['Action']
            count = row['Count']
            avg_hours = row['Avg_Hours']
            
            # Determine automation rate
            if action in ['Restarted', 'Cleared', 'Executed']:
                if count >= 20 and avg_hours < 2:
                    rate = 85.0
                elif count >= 10:
                    rate = 80.0
                else:
                    rate = 70.0
            elif action in ['Reset', 'Granted']:
                rate = 75.0
            elif action in ['Fixed', 'Updated']:
                rate = 50.0
            else:
                rate = 30.0
            
            saved = float(row['Total_Hours']) * (rate / 100.0)
            freed = max(1.0, float(row['Team_Members']) * (rate / 100.0))
            
            automation_rates.append(rate)
            hours_saved.append(saved)
            team_freed.append(freed)
        
        # Assign all at once to avoid dtype issues
        self.clusters['Automation_Rate'] = automation_rates
        self.clusters['Hours_Saved'] = hours_saved
        self.clusters['Team_Freed'] = team_freed
    
    def generate_master_report(self):
        print("Generating MASTER_EXECUTIVE_REPORT.txt...")
        
        report_file = 'output_master_report/MASTER_EXECUTIVE_REPORT.txt'
        
        with open(report_file, 'w', encoding='utf-8') as f:
            # Header
            f.write("=" * 120 + "\n")
            f.write("MASTER EXECUTIVE REPORT - COMPREHENSIVE INCIDENT ANALYSIS\n".center(120))
            f.write("=" * 120 + "\n\n")
            
            f.write(f"Report Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}\n")
            if len(self.df) > 0:
                date_range = f"{self.df['opened_at'].min().strftime('%Y-%m-%d')} to {self.df['opened_at'].max().strftime('%Y-%m-%d')}"
                f.write(f"Analysis Period: {date_range}\n")
            f.write("\n" + "=" * 120 + "\n\n")
            
            # SECTION 1: EXECUTIVE SUMMARY
            self._write_executive_summary(f)
            
            # SECTION 2: CURRENT STATE ANALYSIS
            self._write_current_state(f)
            
            # SECTION 3: ISSUE CLUSTERING ANALYSIS
            self._write_clustering_analysis(f)
            
            # SECTION 4: APPLICATION BREAKDOWN
            self._write_application_breakdown(f)
            
            # SECTION 5: TEAM ANALYSIS
            self._write_team_analysis(f)
            
            # SECTION 6: REDUCTION OPPORTUNITIES
            self._write_reduction_opportunities(f)
            
            # SECTION 7: DETAILED RECOMMENDATIONS
            self._write_recommendations(f)
            
            # SECTION 8: IMPLEMENTATION ROADMAP
            self._write_roadmap(f)
            
            # SECTION 9: ROI ANALYSIS
            self._write_roi_analysis(f)
            
            # Footer
            f.write("\n" + "=" * 120 + "\n")
            f.write("END OF MASTER EXECUTIVE REPORT\n".center(120))
            f.write("=" * 120 + "\n")
        
        print(f"✓ Created: {report_file}\n")
    
    def _write_executive_summary(self, f):
        """Write executive summary section"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 1: EXECUTIVE SUMMARY ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        total_incidents = len(self.df)
        total_hours = self.df['resolution_hours'].sum()
        total_team = self.df['assigned_to'].nunique()
        recurring_incidents = self.clusters['Count'].sum()
        recurring_hours = self.clusters['Total_Hours'].sum()
        
        potential_savings = self.clusters['Hours_Saved'].sum()
        team_freed = int(self.clusters['Team_Freed'].sum())
        
        f.write("KEY FINDINGS:\n")
        f.write("-" * 120 + "\n\n")
        
        f.write(f"📊 INCIDENT VOLUME:\n")
        f.write(f"   • Total incidents analyzed: {total_incidents:,}\n")
        f.write(f"   • Recurring patterns (5+ occurrences): {len(self.clusters):,} clusters\n")
        f.write(f"   • Recurring incidents: {recurring_incidents:,} ({recurring_incidents/total_incidents*100:.1f}%)\n\n")
        
        f.write(f"👥 CURRENT EFFORT:\n")
        f.write(f"   • Team members involved: {total_team:,} people\n")
        f.write(f"   • Total hours spent annually: {total_hours:,.0f} hours\n")
        f.write(f"   • Annual cost (@$50/hr): ${total_hours * 50:,.0f}\n")
        f.write(f"   • Hours on recurring issues: {recurring_hours:,.0f} hours ({recurring_hours/total_hours*100:.1f}%)\n\n")
        
        f.write(f"💰 REDUCTION OPPORTUNITY:\n")
        f.write(f"   • Potential hours saved: {potential_savings:,.0f} hours/year\n")
        f.write(f"   • Effort reduction: {potential_savings/total_hours*100:.0f}%\n")
        f.write(f"   • Team members that can be freed: ~{team_freed} people\n")
        f.write(f"   • Annual cost savings: ${potential_savings * 50:,.0f}\n\n")
        
        f.write(f"🎯 BOTTOM LINE:\n")
        f.write(f"   By automating the top recurring patterns, we can reduce incident resolution\n")
        f.write(f"   effort by {potential_savings/total_hours*100:.0f}% and free up approximately {team_freed} team members\n")
        f.write(f"   for higher-value work, saving ${potential_savings * 50:,.0f} annually.\n\n")
        
        f.write("=" * 120 + "\n\n")
    
    def _write_current_state(self, f):
        """Write current state analysis"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 2: CURRENT STATE ANALYSIS ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write("INCIDENT DISTRIBUTION BY CATEGORY:\n")
        f.write("-" * 120 + "\n")
        category_dist = self.df['category'].value_counts().head(10)
        f.write(f"{'Category':<50}{'Count':<15}{'% of Total'}\n")
        f.write("-" * 120 + "\n")
        for cat, count in category_dist.items():
            pct = count / len(self.df) * 100
            f.write(f"{str(cat)[:48]:<50}{count:<15,}{pct:>6.1f}%\n")
        
        f.write("\n")
        f.write("INCIDENT DISTRIBUTION BY PRIORITY:\n")
        f.write("-" * 120 + "\n")
        priority_dist = self.df['priority'].value_counts()
        f.write(f"{'Priority':<50}{'Count':<15}{'% of Total'}\n")
        f.write("-" * 120 + "\n")
        for pri, count in priority_dist.items():
            pct = count / len(self.df) * 100
            f.write(f"{str(pri)[:48]:<50}{count:<15,}{pct:>6.1f}%\n")
        
        f.write("\n")
        f.write("RESOLUTION TIME STATISTICS:\n")
        f.write("-" * 120 + "\n")
        f.write(f"Average resolution time: {self.df['resolution_hours'].mean():.1f} hours\n")
        f.write(f"Median resolution time: {self.df['resolution_hours'].median():.1f} hours\n")
        f.write(f"Fastest resolution: {self.df['resolution_hours'].min():.1f} hours\n")
        f.write(f"Slowest resolution: {self.df['resolution_hours'].max():.1f} hours\n")
        
        f.write("\n" + "=" * 120 + "\n\n")
    
    def _write_clustering_analysis(self, f):
        """Write clustering analysis"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 3: ISSUE CLUSTERING ANALYSIS ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write(f"Total recurring issue patterns identified: {len(self.clusters):,}\n")
        f.write(f"Covering {self.clusters['Count'].sum():,} incidents ({self.clusters['Count'].sum()/len(self.df)*100:.1f}% of total)\n\n")
        
        f.write("TOP 20 RECURRING ISSUE PATTERNS:\n")
        f.write("=" * 120 + "\n\n")
        
        for rank, (idx, row) in enumerate(self.clusters.head(20).iterrows(), 1):
            f.write(f"{rank}. {row['Example_Issue'][:90]}\n")
            f.write(f"   Occurrences: {int(row['Count']):,} | Team Members: {int(row['Team_Members'])} | ")
            f.write(f"Total Hours: {row['Total_Hours']:,.0f} | Avg Hours: {row['Avg_Hours']:.1f}\n")
            f.write(f"   Applications: {row['Top_Applications'][:80]}\n")
            f.write(f"   Teams: {row['Top_Teams'][:80]}\n")
            f.write(f"   Resolution: {row['Action']} - {row['Example_Resolution'][:60]}\n")
            f.write(f"   Automation Potential: {int(row['Automation_Rate'])}% | Hours Saved: {row['Hours_Saved']:,.0f}\n")
            f.write("\n")
        
        f.write("=" * 120 + "\n\n")
    
    def _write_application_breakdown(self, f):
        """Write application breakdown"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 4: APPLICATION BREAKDOWN ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write("TOP 15 APPLICATIONS BY TOTAL EFFORT:\n")
        f.write("=" * 120 + "\n")
        f.write(f"{'Application':<45}{'Incidents':<12}{'Team':<8}{'Hours':<12}{'Avg Hours':<12}{'Issues'}\n")
        f.write("=" * 120 + "\n")
        
        for app, row in self.app_summary.head(15).iterrows():
            f.write(f"{str(app)[:43]:<45}{int(row['Total_Incidents']):<12,}{int(row['Team_Members']):<8}")
            f.write(f"{row['Total_Hours']:<12,.0f}{row['Avg_Hours']:<12.1f}{int(row['Unique_Issues'])}\n")
        
        f.write("\n" + "=" * 120 + "\n\n")
    
    def _write_team_analysis(self, f):
        """Write team analysis"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 5: TEAM ANALYSIS ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write("TOP 15 TEAMS BY WORKLOAD:\n")
        f.write("=" * 120 + "\n")
        f.write(f"{'Team':<50}{'Incidents':<12}{'Size':<8}{'Hours':<12}{'Avg Hours'}\n")
        f.write("=" * 120 + "\n")
        
        for team, row in self.team_summary.head(15).iterrows():
            f.write(f"{str(team)[:48]:<50}{int(row['Total_Incidents']):<12,}{int(row['Team_Size']):<8}")
            f.write(f"{row['Total_Hours']:<12,.0f}{row['Avg_Hours']:.1f}\n")
        
        f.write("\n" + "=" * 120 + "\n\n")
    
    def _write_reduction_opportunities(self, f):
        """Write reduction opportunities"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 6: TOP 10 EFFORT REDUCTION OPPORTUNITIES ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        top_opportunities = self.clusters.sort_values('Hours_Saved', ascending=False).head(10)
        
        for rank, (idx, row) in enumerate(top_opportunities.iterrows(), 1):
            f.write(f"\n{'─' * 120}\n")
            f.write(f"OPPORTUNITY #{rank}: {row['Example_Issue'][:80]}\n")
            f.write(f"{'─' * 120}\n\n")
            
            f.write(f"CURRENT STATE:\n")
            f.write(f"  • Occurrences: {int(row['Count']):,} times/year\n")
            f.write(f"  • Team members handling: {int(row['Team_Members'])} people\n")
            f.write(f"  • Total effort: {row['Total_Hours']:,.0f} hours/year (${row['Total_Hours'] * 50:,.0f})\n")
            f.write(f"  • Average per incident: {row['Avg_Hours']:.1f} hours\n")
            f.write(f"  • What they do: {row['Action']} - {row['Example_Resolution'][:70]}\n\n")
            
            f.write(f"PROPOSED SOLUTION:\n")
            f.write(f"  • Automation approach: {self._suggest_solution(row['Action'])}\n")
            f.write(f"  • Automation rate: {int(row['Automation_Rate'])}%\n\n")
            
            f.write(f"EXPECTED IMPACT:\n")
            f.write(f"  • Hours saved: {row['Hours_Saved']:,.0f} hours/year\n")
            f.write(f"  • Cost saved: ${row['Hours_Saved'] * 50:,.0f}/year\n")
            f.write(f"  • Team members freed: {int(row['Team_Freed'])} people\n")
            f.write(f"  • Effort reduction: {int(row['Automation_Rate'])}%\n\n")
        
        f.write("=" * 120 + "\n\n")
    
    def _suggest_solution(self, action):
        """Suggest automation solution"""
        solutions = {
            'Restarted': 'Automated service restart with health monitoring',
            'Cleared': 'Scheduled cleanup script with capacity alerts',
            'Executed': 'Auto-retry logic with failure handling',
            'Reset': 'Self-service portal for users',
            'Granted': 'Workflow-based access automation',
            'Fixed': 'Pattern-based auto-remediation',
            'Updated': 'Configuration management automation'
        }
        return solutions.get(action, 'Custom automation solution')
    
    def _write_recommendations(self, f):
        """Write recommendations"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 7: DETAILED RECOMMENDATIONS ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write("IMMEDIATE ACTIONS (0-3 months):\n")
        f.write("=" * 120 + "\n")
        
        quick_wins = self.clusters[
            (self.clusters['Automation_Rate'] >= 80) & 
            (self.clusters['Count'] >= 10)
        ].sort_values('Hours_Saved', ascending=False).head(5)
        
        for idx, row in quick_wins.iterrows():
            f.write(f"\n• Automate: {row['Example_Issue'][:70]}\n")
            f.write(f"  Impact: {row['Hours_Saved']:,.0f} hours saved, {int(row['Team_Freed'])} people freed\n")
            f.write(f"  Approach: {self._suggest_solution(row['Action'])}\n")
        
        f.write("\n\nMEDIUM-TERM ACTIONS (3-6 months):\n")
        f.write("=" * 120 + "\n")
        f.write("• Implement self-service portal for common requests\n")
        f.write("• Deploy automated monitoring and alerting\n")
        f.write("• Create runbook automation for standard procedures\n")
        
        f.write("\n\nLONG-TERM ACTIONS (6-12 months):\n")
        f.write("=" * 120 + "\n")
        f.write("• Build comprehensive automation platform\n")
        f.write("• Implement AI-powered incident prediction\n")
        f.write("• Create knowledge base with auto-suggested solutions\n")
        
        f.write("\n" + "=" * 120 + "\n\n")
    
    def _write_roadmap(self, f):
        """Write implementation roadmap"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 8: IMPLEMENTATION ROADMAP ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        f.write("PHASE 1: QUICK WINS (Months 1-3)\n")
        f.write("=" * 120 + "\n")
        f.write("• Implement automated restarts for top 3 recurring failures\n")
        f.write("• Deploy cleanup scripts for disk space issues\n")
        f.write("• Set up auto-retry for batch job timeouts\n")
        if len(self.clusters) >= 3:
            f.write(f"• Expected savings: {self.clusters.head(3)['Hours_Saved'].sum():,.0f} hours, ")
            f.write(f"${self.clusters.head(3)['Hours_Saved'].sum() * 50:,.0f}\n\n")
        else:
            f.write(f"• Expected savings: TBD\n\n")
        
        f.write("PHASE 2: SCALABLE AUTOMATION (Months 4-6)\n")
        f.write("=" * 120 + "\n")
        f.write("• Build self-service portal\n")
        f.write("• Implement workflow-based access management\n")
        f.write("• Deploy comprehensive monitoring\n")
        if len(self.clusters) >= 10:
            f.write(f"• Expected savings: {self.clusters.iloc[3:10]['Hours_Saved'].sum():,.0f} hours, ")
            f.write(f"${self.clusters.iloc[3:10]['Hours_Saved'].sum() * 50:,.0f}\n\n")
        else:
            f.write(f"• Expected savings: TBD\n\n")
        
        f.write("PHASE 3: ADVANCED AUTOMATION (Months 7-12)\n")
        f.write("=" * 120 + "\n")
        f.write("• Implement AI-powered incident prediction\n")
        f.write("• Build knowledge base with auto-suggestions\n")
        f.write("• Create comprehensive automation platform\n\n")
        
        f.write("=" * 120 + "\n\n")
    
    def _write_roi_analysis(self, f):
        """Write ROI analysis"""
        f.write("╔" + "═" * 118 + "╗\n")
        f.write("║" + " SECTION 9: ROI ANALYSIS ".center(118) + "║\n")
        f.write("╚" + "═" * 118 + "╝\n\n")
        
        total_savings = self.clusters['Hours_Saved'].sum() * 50
        implementation_cost = 100000  # Estimated
        
        f.write("FINANCIAL ANALYSIS:\n")
        f.write("=" * 120 + "\n\n")
        
        f.write(f"Current Annual Cost:\n")
        f.write(f"  • Total hours: {self.df['resolution_hours'].sum():,.0f}\n")
        f.write(f"  • Cost (@$50/hr): ${self.df['resolution_hours'].sum() * 50:,.0f}\n\n")
        
        f.write(f"After Automation:\n")
        f.write(f"  • Hours saved: {self.clusters['Hours_Saved'].sum():,.0f}\n")
        f.write(f"  • Annual savings: ${total_savings:,.0f}\n")
        f.write(f"  • Remaining manual effort: {self.df['resolution_hours'].sum() - self.clusters['Hours_Saved'].sum():,.0f} hours\n\n")
        
        f.write(f"Investment & ROI:\n")
        f.write(f"  • Estimated implementation cost: ${implementation_cost:,}\n")
        f.write(f"  • Payback period: {implementation_cost / total_savings * 12:.1f} months\n")
        f.write(f"  • Year 1 ROI: {(total_savings - implementation_cost) / implementation_cost * 100:.0f}%\n")
        f.write(f"  • 3-Year NPV: ${total_savings * 3 - implementation_cost:,.0f}\n\n")
        
        f.write("=" * 120 + "\n\n")
    
    def generate_detailed_excel(self):
        print("Generating MASTER_ANALYSIS_DETAILED.xlsx...")
        
        excel_file = 'output_master_report/MASTER_ANALYSIS_DETAILED.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Executive Summary
            exec_data = {
                'Metric': [
                    'Total Incidents',
                    'Recurring Patterns',
                    'Total Team Members',
                    'Total Hours/Year',
                    'Potential Hours Saved',
                    'Potential Cost Savings',
                    'Team Members Freed',
                    'Effort Reduction %'
                ],
                'Value': [
                    len(self.df),
                    len(self.clusters),
                    self.df['assigned_to'].nunique(),
                    f"{self.df['resolution_hours'].sum():,.0f}",
                    f"{self.clusters['Hours_Saved'].sum():,.0f}",
                    f"${self.clusters['Hours_Saved'].sum() * 50:,.0f}",
                    int(self.clusters['Team_Freed'].sum()),
                    f"{self.clusters['Hours_Saved'].sum() / self.df['resolution_hours'].sum() * 100:.0f}%"
                ]
            }
            pd.DataFrame(exec_data).to_excel(writer, sheet_name='Executive_Summary', index=False)
            
            # Issue Clusters
            self.clusters.to_excel(writer, sheet_name='Issue_Clusters')
            
            # Application Summary
            self.app_summary.to_excel(writer, sheet_name='By_Application')
            
            # Team Summary
            self.team_summary.to_excel(writer, sheet_name='By_Team')
            
            # Top Opportunities
            top_opps = self.clusters.sort_values('Hours_Saved', ascending=False).head(20)
            top_opps.to_excel(writer, sheet_name='Top_20_Opportunities')
        
        print(f"✓ Created: {excel_file}\n")
    
    def run_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING MASTER ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.analyze_all()
        self.generate_master_report()
        self.generate_detailed_excel()
        
        print("\n" + "=" * 100)
        print("MASTER REPORT COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 OUTPUTS:\n")
        print("  ✓ MASTER_EXECUTIVE_REPORT.txt ⭐⭐⭐ READ THIS FIRST!")
        print("  ✓ MASTER_ANALYSIS_DETAILED.xlsx ⭐⭐\n")
        print("=" * 100 + "\n")
        print("👉 Open: output_master_report/MASTER_EXECUTIVE_REPORT.txt\n")
        print("   This single report contains ALL analysis in one comprehensive document!\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = MasterExecutiveReport(FILE_PATH)
        analyzer.run_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
