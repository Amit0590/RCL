"""
MASTER CONSOLIDATED REPORT GENERATOR
Creates comprehensive summary and detailed reports that tie everything together

Outputs:
1. MASTER_CONSOLIDATED_SUMMARY.xlsx - All metrics in one Excel workbook
2. MASTER_EXECUTIVE_REPORT.txt - Complete text report
3. Individual detailed reports for each dimension
4. Resolution summaries and detailed breakdowns
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
import os
warnings.filterwarnings('ignore')

class MasterConsolidatedReporter:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        """Initialize master consolidated reporter"""
        print("=" * 100)
        print("MASTER CONSOLIDATED REPORT GENERATOR".center(100))
        print("=" * 100)
        print("\nGenerating comprehensive consolidated reports...")
        print("All metrics tied together in single summary and detailed reports\n")
        
        # Load data
        print("Loading ticket data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} tickets with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
        
        # Create output directories
        os.makedirs('output_master', exist_ok=True)
        os.makedirs('output_master/detailed_reports', exist_ok=True)
        os.makedirs('output_master/resolution_reports', exist_ok=True)
        
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        """Prepare comprehensive dataset"""
        print("Preparing comprehensive dataset...")
        
        # Map applications
        self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        self.df['application'].fillna('Other/Unmapped', inplace=True)
        
        # Date conversions
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        # Time calculations
        self.df['resolution_hours'] = (self.df['resolved_at'] - self.df['opened_at']).dt.total_seconds() / 3600
        self.df['resolution_days'] = self.df['resolution_hours'] / 24
        self.df['closure_hours'] = (self.df['closed_at'] - self.df['resolved_at']).dt.total_seconds() / 3600
        
        # Clean text fields
        self.df['close_notes_clean'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['description_clean'] = self.df.get('description', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['short_description_clean'] = self.df.get('short_description', pd.Series([''] * len(self.df))).fillna('').astype(str)
        
        # Extract resolution patterns
        self.df['resolution_pattern'] = self.df['close_notes_clean'].apply(self._extract_resolution_pattern)
        
        # Classify issue types
        self.df['issue_type'] = self.df.apply(self._classify_issue_type, axis=1)
        
        # Temporal features
        self.df['opened_year'] = self.df['opened_at'].dt.year
        self.df['opened_month'] = self.df['opened_at'].dt.month
        self.df['opened_month_name'] = self.df['opened_at'].dt.month_name()
        self.df['opened_week'] = self.df['opened_at'].dt.isocalendar().week
        self.df['opened_day_of_week'] = self.df['opened_at'].dt.day_name()
        
        print("✓ Dataset prepared with comprehensive fields\n")
    
    def _extract_resolution_pattern(self, close_notes):
        """Extract resolution pattern from close notes"""
        close_notes_lower = close_notes.lower()
        
        patterns = {
            'Password Reset': ['password reset', 'reset password', 'pwd reset'],
            'Service Restart': ['restart', 'reboot', 'service restart'],
            'Permission Granted': ['granted', 'permission', 'access granted'],
            'Configuration Change': ['config', 'configuration', 'setting'],
            'Software Install': ['install', 'installed'],
            'Batch Job Fixed': ['batch', 'job', 'rerun'],
            'Disk Cleanup': ['disk', 'cleanup', 'space'],
            'Cache Clear': ['cache', 'clear cache'],
            'Escalated': ['escalate', 'forwarded'],
            'User Training': ['train', 'educate', 'instruct'],
            'Duplicate': ['duplicate'],
            'Not Reproducible': ['not reproducible', 'cannot reproduce']
        }
        
        for pattern_name, keywords in patterns.items():
            if any(keyword in close_notes_lower for keyword in keywords):
                return pattern_name
        
        return 'Other Resolution'
    
    def _classify_issue_type(self, row):
        """Classify issue type"""
        combined = f"{row.get('category', '')} {row.get('description_clean', '')}".lower()
        
        if any(word in combined for word in ['error', 'failure', 'failed']):
            return 'Error'
        elif any(word in combined for word in ['alert', 'alarm']):
            return 'Alert'
        elif any(word in combined for word in ['warning', 'warn']):
            return 'Warning'
        else:
            return 'Other'
    
    def generate_master_summary_excel(self):
        """Generate master Excel workbook with all summaries"""
        print("Generating MASTER_CONSOLIDATED_SUMMARY.xlsx...")
        
        excel_file = 'output_master/MASTER_CONSOLIDATED_SUMMARY.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Overall Summary
            overall_summary = pd.DataFrame({
                'Metric': [
                    'Total Tickets',
                    'Unique Applications',
                    'Unique Categories',
                    'Unique Assignment Groups',
                    'Unique Resolvers',
                    'Unique Callers',
                    'Date Range (Days)',
                    'Avg Resolution Hours',
                    'Median Resolution Hours',
                    'Total Resolution Hours',
                    'Estimated Cost (@$50/hr)',
                    'Estimated Cost (@$75/hr)'
                ],
                'Value': [
                    len(self.df),
                    self.df['application'].nunique(),
                    self.df['category'].nunique(),
                    self.df['assignment_group'].nunique(),
                    self.df.get('assigned_to', pd.Series([np.nan])).nunique(),
                    self.df.get('caller_id', pd.Series([np.nan])).nunique(),
                    (self.df['opened_at'].max() - self.df['opened_at'].min()).days,
                    round(self.df['resolution_hours'].mean(), 2),
                    round(self.df['resolution_hours'].median(), 2),
                    round(self.df['resolution_hours'].sum(), 0),
                    f"${self.df['resolution_hours'].sum() * 50:,.0f}",
                    f"${self.df['resolution_hours'].sum() * 75:,.0f}"
                ]
            })
            overall_summary.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            # Sheet 2: By Application
            app_summary = self.df.groupby('application').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median', 'sum'],
                'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'N/A'
            }).round(2)
            app_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 'Total_Hours', 'Primary_Category']
            app_summary['Percentage'] = (app_summary['Ticket_Count'] / len(self.df) * 100).round(2)
            app_summary['Cost_50USD'] = (app_summary['Total_Hours'] * 50).round(0)
            app_summary = app_summary.sort_values('Ticket_Count', ascending=False)
            app_summary.to_excel(writer, sheet_name='02_By_Application')
            
            # Sheet 3: By Category
            cat_summary = self.df.groupby('category').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median', 'sum'],
                'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'N/A'
            }).round(2)
            cat_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 'Total_Hours', 'Primary_Application']
            cat_summary['Percentage'] = (cat_summary['Ticket_Count'] / len(self.df) * 100).round(2)
            cat_summary = cat_summary.sort_values('Ticket_Count', ascending=False)
            cat_summary.to_excel(writer, sheet_name='03_By_Category')
            
            # Sheet 4: By Priority
            priority_summary = self.df.groupby('priority').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median']
            }).round(2)
            priority_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours']
            priority_summary['Percentage'] = (priority_summary['Ticket_Count'] / len(self.df) * 100).round(2)
            priority_summary.to_excel(writer, sheet_name='04_By_Priority')
            
            # Sheet 5: By Resolution Pattern
            pattern_summary = self.df.groupby('resolution_pattern').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median', 'sum']
            }).round(2)
            pattern_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 'Total_Hours']
            pattern_summary['Percentage'] = (pattern_summary['Ticket_Count'] / len(self.df) * 100).round(2)
            pattern_summary = pattern_summary.sort_values('Ticket_Count', ascending=False)
            pattern_summary.to_excel(writer, sheet_name='05_Resolution_Patterns')
            
            # Sheet 6: By Issue Type
            issue_summary = self.df.groupby('issue_type').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median', 'sum']
            }).round(2)
            issue_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 'Total_Hours']
            issue_summary['Percentage'] = (issue_summary['Ticket_Count'] / len(self.df) * 100).round(2)
            issue_summary.to_excel(writer, sheet_name='06_Issue_Types')
            
            # Sheet 7: By Assignment Group
            group_summary = self.df.groupby('assignment_group').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median'],
                'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'N/A'
            }).round(2)
            group_summary.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 'Application']
            group_summary = group_summary.sort_values('Ticket_Count', ascending=False)
            group_summary.to_excel(writer, sheet_name='07_By_Assignment_Group')
            
            # Sheet 8: By Resolver (if available)
            if 'assigned_to' in self.df.columns:
                resolver_summary = self.df.groupby('assigned_to').agg({
                    'number': 'count',
                    'resolution_hours': ['mean', 'median']
                }).round(2)
                resolver_summary.columns = ['Tickets_Resolved', 'Avg_Hours', 'Median_Hours']
                resolver_summary = resolver_summary.sort_values('Tickets_Resolved', ascending=False)
                resolver_summary.head(100).to_excel(writer, sheet_name='08_Top_100_Resolvers')
            
            # Sheet 9: By Caller (if available)
            if 'caller_id' in self.df.columns:
                caller_summary = self.df.groupby('caller_id').agg({
                    'number': 'count',
                    'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'N/A'
                }).round(2)
                caller_summary.columns = ['Total_Tickets', 'Most_Common_Category']
                caller_summary = caller_summary.sort_values('Total_Tickets', ascending=False)
                caller_summary.head(100).to_excel(writer, sheet_name='09_Top_100_Callers')
            
            # Sheet 10: Monthly Trends
            monthly_summary = self.df.groupby(['opened_year', 'opened_month']).agg({
                'number': 'count',
                'resolution_hours': 'mean'
            }).round(2)
            monthly_summary.columns = ['Ticket_Count', 'Avg_Resolution_Hours']
            monthly_summary.to_excel(writer, sheet_name='10_Monthly_Trends')
            
            # Sheet 11: Cross-tab - Application vs Category
            cross_tab_app_cat = pd.crosstab(
                self.df['application'],
                self.df['category'],
                values=self.df['number'],
                aggfunc='count'
            ).fillna(0)
            cross_tab_app_cat.to_excel(writer, sheet_name='11_App_vs_Category')
            
            # Sheet 12: Cross-tab - Category vs Resolution
            cross_tab_cat_res = pd.crosstab(
                self.df['category'],
                self.df['resolution_pattern'],
                values=self.df['number'],
                aggfunc='count'
            ).fillna(0)
            cross_tab_cat_res.to_excel(writer, sheet_name='12_Category_vs_Resolution')
        
        print(f"✓ Created master Excel with 12 sheets: {excel_file}\n")
    
    def generate_detailed_reports(self):
        """Generate individual detailed CSV reports"""
        print("Generating detailed individual reports...")
        
        output_dir = 'output_master/detailed_reports'
        
        # Report 1: Complete ticket-level data
        ticket_level = self.df[[
            'number', 'opened_at', 'resolved_at', 'category', 'priority',
            'application', 'assignment_group', 'resolution_hours',
            'resolution_pattern', 'issue_type', 'short_description_clean'
        ]].copy()
        ticket_level.to_csv(f'{output_dir}/01_complete_ticket_data.csv', index=False)
        
        # Report 2: Application detailed
        app_detail = self.df.groupby('application').agg({
            'number': ['count', lambda x: list(x)[:5]],
            'resolution_hours': ['mean', 'median', 'std', 'min', 'max', 'sum'],
            'category': lambda x: x.value_counts().head(3).to_dict(),
            'resolution_pattern': lambda x: x.value_counts().head(3).to_dict()
        })
        app_detail.columns = ['_'.join(col).strip() for col in app_detail.columns.values]
        app_detail.to_csv(f'{output_dir}/02_application_detailed.csv')
        
        # Report 3: Category detailed
        cat_detail = self.df.groupby('category').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median', 'std'],
            'application': lambda x: x.value_counts().head(3).to_dict(),
            'resolution_pattern': lambda x: x.value_counts().head(3).to_dict()
        })
        cat_detail.columns = ['_'.join(col).strip() for col in cat_detail.columns.values]
        cat_detail.to_csv(f'{output_dir}/03_category_detailed.csv')
        
        # Report 4: Resolution pattern detailed
        pattern_detail = self.df.groupby('resolution_pattern').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median', 'std', 'min', 'max'],
            'category': lambda x: x.value_counts().head(5).to_dict(),
            'application': lambda x: x.value_counts().head(5).to_dict()
        })
        pattern_detail.columns = ['_'.join(col).strip() for col in pattern_detail.columns.values]
        pattern_detail.to_csv(f'{output_dir}/04_resolution_pattern_detailed.csv')
        
        # Report 5: Issue type detailed
        issue_detail = self.df.groupby('issue_type').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median'],
            'category': lambda x: x.value_counts().head(5).to_dict(),
            'resolution_pattern': lambda x: x.value_counts().head(5).to_dict()
        })
        issue_detail.columns = ['_'.join(col).strip() for col in issue_detail.columns.values]
        issue_detail.to_csv(f'{output_dir}/05_issue_type_detailed.csv')
        
        # Report 6: Other Resolution detailed analysis
        other_res = self.df[self.df['resolution_pattern'] == 'Other Resolution'].copy()
        if len(other_res) > 0:
            other_analysis = other_res.groupby(['category', 'application']).agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median', 'sum'],
                'close_notes_clean': lambda x: ' || '.join(x.head(5))
            }).round(2)
            other_analysis.columns = ['Ticket_Count', 'Avg_Hours', 'Median_Hours', 
                                      'Total_Hours', 'Sample_Close_Notes']
            other_analysis = other_analysis.sort_values('Ticket_Count', ascending=False)
            other_analysis.to_csv(f'{output_dir}/06_other_resolution_detailed.csv')
            
            # Top 100 individual "Other Resolution" tickets with full details
            other_sample = other_res[['number', 'opened_at', 'category', 'application', 
                                      'assignment_group', 'resolution_hours', 
                                      'short_description_clean', 'close_notes_clean']].head(100)
            other_sample.to_csv(f'{output_dir}/07_other_resolution_sample_tickets.csv', index=False)
        
        print(f"✓ Created 7 detailed reports in: {output_dir}\n")
    
    def generate_resolution_reports(self):
        """Generate comprehensive resolution reports"""
        print("Generating resolution summary and detailed reports...")
        
        output_dir = 'output_master/resolution_reports'
        
        # Resolution Summary
        resolution_summary = self.df.groupby('resolution_pattern').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median', 'min', 'max', 'std', 'sum'],
            'category': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple',
            'application': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Multiple'
        }).round(2)
        
        resolution_summary.columns = [
            'Total_Tickets',
            'Avg_Hours', 'Median_Hours', 'Min_Hours', 'Max_Hours', 'Std_Hours', 'Total_Hours',
            'Primary_Category', 'Primary_Application'
        ]
        
        resolution_summary['Percentage_of_Total'] = (
            resolution_summary['Total_Tickets'] / len(self.df) * 100
        ).round(2)
        
        resolution_summary['Estimated_Cost_50USD'] = (
            resolution_summary['Total_Hours'] * 50
        ).round(0)
        
        resolution_summary = resolution_summary.sort_values('Total_Tickets', ascending=False)
        resolution_summary.to_csv(f'{output_dir}/resolution_summary.csv')
        
        # Detailed resolution by category
        resolution_by_category = pd.crosstab(
            [self.df['resolution_pattern'], self.df['category']],
            self.df['application'],
            values=self.df['resolution_hours'],
            aggfunc='mean'
        ).round(2)
        resolution_by_category.to_csv(f'{output_dir}/resolution_by_category_application.csv')
        
        # Resolution timeline analysis
        resolution_timeline = self.df.groupby(['resolution_pattern', 'opened_month_name']).agg({
            'number': 'count',
            'resolution_hours': 'mean'
        }).round(2)
        resolution_timeline.columns = ['Ticket_Count', 'Avg_Resolution_Hours']
        resolution_timeline.to_csv(f'{output_dir}/resolution_timeline.csv')
        
        # Top 10 resolutions per category
        for category in self.df['category'].value_counts().head(10).index:
            cat_data = self.df[self.df['category'] == category]
            cat_resolutions = cat_data.groupby('resolution_pattern').agg({
                'number': 'count',
                'resolution_hours': 'mean',
                'close_notes_clean': lambda x: ' | '.join(x.head(3))
            }).round(2)
            cat_resolutions.columns = ['Count', 'Avg_Hours', 'Sample_Notes']
            cat_resolutions = cat_resolutions.sort_values('Count', ascending=False)
            
            # Sanitize filename - remove all invalid Windows characters
            import re
            safe_name = re.sub(r'[<>:"/\\|?*]', '_', category)  # Remove Windows invalid chars
            safe_name = safe_name.replace(' ', '_')[:50]  # Replace spaces and limit length
            cat_resolutions.to_csv(f'{output_dir}/resolutions_for_{safe_name}.csv')
        
        print(f"✓ Created resolution reports in: {output_dir}\n")
    
    def generate_master_text_report(self):
        """Generate comprehensive master text report"""
        print("Generating MASTER_EXECUTIVE_REPORT.txt...")
        
        with open('output_master/MASTER_EXECUTIVE_REPORT.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("MASTER CONSOLIDATED EXECUTIVE REPORT\n")
            f.write("ServiceNow Ticket Analysis - Complete Summary\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Report Generated: {datetime.now().strftime('%B %d, %Y at %I:%M %p')}\n")
            f.write(f"Analysis Period: {self.df['opened_at'].min().strftime('%Y-%m-%d')} to {self.df['opened_at'].max().strftime('%Y-%m-%d')}\n")
            f.write(f"Total Days: {(self.df['opened_at'].max() - self.df['opened_at'].min()).days}\n\n")
            
            # Section 1: Overall Summary
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 1: OVERALL SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            total_hours = self.df['resolution_hours'].sum()
            f.write(f"Total Tickets Analyzed:        {len(self.df):,}\n")
            f.write(f"Unique Applications:            {self.df['application'].nunique()}\n")
            f.write(f"Unique Categories:              {self.df['category'].nunique()}\n")
            f.write(f"Unique Assignment Groups:       {self.df['assignment_group'].nunique()}\n\n")
            
            f.write(f"Average Resolution Time:        {self.df['resolution_hours'].mean():.2f} hours\n")
            f.write(f"Median Resolution Time:         {self.df['resolution_hours'].median():.2f} hours\n")
            f.write(f"90th Percentile:                {self.df['resolution_hours'].quantile(0.9):.2f} hours\n")
            f.write(f"95th Percentile:                {self.df['resolution_hours'].quantile(0.95):.2f} hours\n\n")
            
            f.write(f"Total Resolution Hours:         {total_hours:,.0f} hours\n")
            f.write(f"Estimated FTE Equivalent:       {total_hours/2080:.1f} FTEs\n")
            f.write(f"Estimated Cost (@$50/hour):     ${total_hours * 50:,.0f}\n")
            f.write(f"Estimated Cost (@$75/hour):     ${total_hours * 75:,.0f}\n")
            
            # Section 2: Top Applications
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 2: TOP 15 APPLICATIONS\n")
            f.write("=" * 100 + "\n\n")
            
            top_apps = self.df['application'].value_counts().head(15)
            f.write(f"{'Rank':<6}{'Application':<40}{'Tickets':<12}{'% of Total':<12}{'Avg Hours'}\n")
            f.write("-" * 100 + "\n")
            
            for rank, (app, count) in enumerate(top_apps.items(), 1):
                pct = count / len(self.df) * 100
                avg_hours = self.df[self.df['application'] == app]['resolution_hours'].mean()
                f.write(f"{rank:<6}{app[:38]:<40}{count:<12,}{pct:<12.2f}{avg_hours:.2f}\n")
            
            # Section 3: Top Categories
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 3: TOP 15 CATEGORIES\n")
            f.write("=" * 100 + "\n\n")
            
            top_cats = self.df['category'].value_counts().head(15)
            f.write(f"{'Rank':<6}{'Category':<50}{'Tickets':<12}{'% of Total'}\n")
            f.write("-" * 100 + "\n")
            
            for rank, (cat, count) in enumerate(top_cats.items(), 1):
                pct = count / len(self.df) * 100
                f.write(f"{rank:<6}{cat[:48]:<50}{count:<12,}{pct:.2f}%\n")
            
            # Section 4: Resolution Patterns
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 4: RESOLUTION PATTERNS\n")
            f.write("=" * 100 + "\n\n")
            
            patterns = self.df['resolution_pattern'].value_counts()
            f.write(f"{'Pattern':<30}{'Tickets':<12}{'% Total':<12}{'Avg Hours':<12}{'Total Hours'}\n")
            f.write("-" * 100 + "\n")
            
            for pattern, count in patterns.items():
                pct = count / len(self.df) * 100
                pattern_data = self.df[self.df['resolution_pattern'] == pattern]
                avg_hours = pattern_data['resolution_hours'].mean()
                total_hours = pattern_data['resolution_hours'].sum()
                f.write(f"{pattern[:28]:<30}{count:<12,}{pct:<12.2f}{avg_hours:<12.2f}{total_hours:,.0f}\n")
            
            # Section 5: Issue Types
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 5: ISSUE TYPE CLASSIFICATION (ALL TICKETS)\n")
            f.write("=" * 100 + "\n\n")
            
            f.write("NOTE: This classifies ALL tickets by detected issue type in description/category,\n")
            f.write("      NOT just tickets in the 'Alert / Error / Warning' category.\n\n")
            
            f.write(f"Category 'Alert / Error / Warning': {len(self.df[self.df['category'] == 'Alert / Error / Warning']):,} tickets\n")
            f.write(f"Total tickets classified by type:   {len(self.df):,} tickets\n\n")
            
            issues = self.df['issue_type'].value_counts()
            f.write(f"{'Issue Type':<20}{'Tickets':<15}{'% Total':<15}{'Avg Hours'}\n")
            f.write("-" * 100 + "\n")
            
            for issue_type, count in issues.items():
                pct = count / len(self.df) * 100
                avg_hours = self.df[self.df['issue_type'] == issue_type]['resolution_hours'].mean()
                f.write(f"{issue_type:<20}{count:<15,}{pct:<15.2f}{avg_hours:.2f}\n")
            
            f.write("\n")
            f.write("BREAKDOWN: Tickets in 'Alert / Error / Warning' category by detected type:\n")
            f.write("-" * 100 + "\n")
            alert_cat_tickets = self.df[self.df['category'] == 'Alert / Error / Warning']
            if len(alert_cat_tickets) > 0:
                alert_breakdown = alert_cat_tickets['issue_type'].value_counts()
                for issue_type, count in alert_breakdown.items():
                    pct = count / len(alert_cat_tickets) * 100
                    f.write(f"  {issue_type:<20} {count:>10,} ({pct:>5.1f}%)\n")
            
            # Section 6: Cross-Analysis
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 6: CROSS-DIMENSIONAL ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            f.write("Top 5 Application + Category Combinations:\n")
            f.write("-" * 100 + "\n")
            combos = self.df.groupby(['application', 'category']).size().sort_values(ascending=False).head(5)
            for (app, cat), count in combos.items():
                f.write(f"  {app[:30]:<30} + {cat[:40]:<40} = {count:,} tickets\n")
            
            f.write("\n")
            f.write("Top 5 Category + Resolution Pattern Combinations:\n")
            f.write("-" * 100 + "\n")
            combos2 = self.df.groupby(['category', 'resolution_pattern']).size().sort_values(ascending=False).head(5)
            for (cat, pattern), count in combos2.items():
                f.write(f"  {cat[:35]:<35} → {pattern:<30} = {count:,} tickets\n")
            
            # Section 7: Key Findings
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 7: DETAILED 'OTHER RESOLUTION' ANALYSIS\n")
            f.write("=" * 100 + "\n\n")
            
            other_res_tickets = self.df[self.df['resolution_pattern'] == 'Other Resolution']
            f.write(f"Total 'Other Resolution' Tickets: {len(other_res_tickets):,} ({len(other_res_tickets)/len(self.df)*100:.1f}%)\n")
            f.write(f"Avg Resolution Time: {other_res_tickets['resolution_hours'].mean():.2f} hours\n")
            f.write(f"Total Hours Spent: {other_res_tickets['resolution_hours'].sum():,.0f} hours\n")
            f.write(f"Estimated Cost (@$50/hr): ${other_res_tickets['resolution_hours'].sum() * 50:,.0f}\n\n")
            
            f.write("Top 15 Categories with 'Other Resolution':\n")
            f.write("-" * 100 + "\n")
            other_by_cat = other_res_tickets.groupby('category').agg({
                'number': 'count',
                'resolution_hours': 'mean'
            }).sort_values('number', ascending=False).head(15)
            f.write(f"{'Category':<50}{'Tickets':<12}{'Avg Hours'}\n")
            f.write("-" * 100 + "\n")
            for cat, row in other_by_cat.iterrows():
                f.write(f"{cat[:48]:<50}{int(row['number']):<12,}{row['resolution_hours']:.2f}\n")
            
            f.write("\n")
            f.write("Top 15 Applications with 'Other Resolution':\n")
            f.write("-" * 100 + "\n")
            other_by_app = other_res_tickets.groupby('application').agg({
                'number': 'count',
                'resolution_hours': 'mean'
            }).sort_values('number', ascending=False).head(15)
            f.write(f"{'Application':<50}{'Tickets':<12}{'Avg Hours'}\n")
            f.write("-" * 100 + "\n")
            for app, row in other_by_app.iterrows():
                f.write(f"{app[:48]:<50}{int(row['number']):<12,}{row['resolution_hours']:.2f}\n")
            
            f.write("\n")
            f.write("Sample 'Other Resolution' Close Notes (first 100 characters):\n")
            f.write("-" * 100 + "\n")
            sample_notes = other_res_tickets['close_notes_clean'].head(20)
            for i, note in enumerate(sample_notes, 1):
                if note and len(note.strip()) > 10:
                    f.write(f"{i:2d}. {note[:100]}\n")
            
            f.write("\n")
            f.write("RECOMMENDATIONS FOR 'OTHER RESOLUTION':\n")
            f.write("-" * 100 + "\n")
            f.write("1. Review close notes to identify hidden patterns\n")
            f.write("2. Implement better resolution categorization in ServiceNow\n")
            f.write("3. Train teams to use specific resolution codes\n")
            f.write("4. Create new resolution patterns for common issues\n")
            f.write("5. Consider text analysis to auto-categorize these resolutions\n")
            
            # Section 8: Key Findings
            f.write("\n" + "=" * 100 + "\n")
            f.write("SECTION 8: KEY FINDINGS & INSIGHTS\n")
            f.write("=" * 100 + "\n\n")
            
            # Top automation opportunity
            top_pattern = self.df['resolution_pattern'].value_counts().index[0]
            top_pattern_count = self.df['resolution_pattern'].value_counts().iloc[0]
            top_pattern_hours = self.df[self.df['resolution_pattern'] == top_pattern]['resolution_hours'].sum()
            
            f.write(f"1. TOP AUTOMATION OPPORTUNITY:\n")
            f.write(f"   Pattern: {top_pattern}\n")
            f.write(f"   Occurrences: {top_pattern_count:,} tickets ({top_pattern_count/len(self.df)*100:.1f}%)\n")
            f.write(f"   Total Hours: {top_pattern_hours:,.0f} hours\n")
            f.write(f"   Potential Savings (80% automation): ${top_pattern_hours * 0.8 * 50:,.0f} annually\n\n")
            
            # Longest resolution times
            f.write(f"2. LONGEST AVERAGE RESOLUTION TIMES:\n")
            long_cats = self.df.groupby('category')['resolution_hours'].mean().sort_values(ascending=False).head(5)
            for cat, hours in long_cats.items():
                count = len(self.df[self.df['category'] == cat])
                f.write(f"   {cat[:60]:<60} {hours:.2f}h ({count:,} tickets)\n")
            
            f.write("\n" + "=" * 100 + "\n")
            f.write("END OF MASTER CONSOLIDATED REPORT\n")
            f.write("=" * 100 + "\n")
            f.write("\nFor detailed breakdowns, see:\n")
            f.write("  - MASTER_CONSOLIDATED_SUMMARY.xlsx (12 worksheets)\n")
            f.write("  - detailed_reports/ folder (5 CSV files)\n")
            f.write("  - resolution_reports/ folder (comprehensive resolution analysis)\n")
        
        print(f"✓ Created master text report: output_master/MASTER_EXECUTIVE_REPORT.txt\n")
    
    def run_full_consolidated_reporting(self):
        """Run complete consolidated reporting"""
        print("\n" + "=" * 100)
        print("STARTING MASTER CONSOLIDATED REPORTING".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.generate_master_summary_excel()
        self.generate_detailed_reports()
        self.generate_resolution_reports()
        self.generate_master_text_report()
        
        print("\n" + "=" * 100)
        print("MASTER CONSOLIDATED REPORTING COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_master/\n")
        print("SUMMARY FILES:")
        print("  ✓ MASTER_CONSOLIDATED_SUMMARY.xlsx (12 worksheets - open this first!)")
        print("  ✓ MASTER_EXECUTIVE_REPORT.txt (complete text summary)\n")
        print("DETAILED FILES:")
        print("  ✓ detailed_reports/ (5 detailed CSV files)")
        print("  ✓ resolution_reports/ (resolution summaries and details)\n")
        print("=" * 100 + "\n")
        
        print("📖 RECOMMENDED READING ORDER:")
        print("  1. MASTER_EXECUTIVE_REPORT.txt - Start here for overview")
        print("  2. MASTER_CONSOLIDATED_SUMMARY.xlsx - All metrics in Excel")
        print("  3. detailed_reports/*.csv - Deep dives into each dimension")
        print("  4. resolution_reports/*.csv - Resolution-specific analysis\n")
        print("=" * 100 + "\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        reporter = MasterConsolidatedReporter(FILE_PATH)
        reporter.run_full_consolidated_reporting()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
