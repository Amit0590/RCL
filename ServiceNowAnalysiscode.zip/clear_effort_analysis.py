"""
CLEAR EFFORT REDUCTION ANALYSIS
Simple and clear: Short description → Clusters → Resolutions → Team members → Solution
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class ClearEffortAnalyzer:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        print("=" * 100)
        print("CLEAR EFFORT REDUCTION ANALYSIS".center(100))
        print("=" * 100)
        print("\nCluster issues → Check resolutions → Count team members → Show reduction\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load application mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
            print("⚠ Using service_offering for applications")
        
        os.makedirs('output_clear_analysis', exist_ok=True)
        os.makedirs('output_clear_analysis/cluster_summaries', exist_ok=True)
        os.makedirs('output_clear_analysis/solutions', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing data...")
        
        # Map to applications
        if self.mapping_dict:
            self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        else:
            self.df['application'] = self.df.get('service_offering', 'Unknown')
        
        self.df['application'] = self.df['application'].fillna('Unknown')
        
        # Clean fields
        self.df['short_description'] = self.df['short_description'].fillna('').astype(str)
        self.df['close_notes'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['assigned_to'] = self.df.get('assigned_to', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        
        # Resolution time
        date_cols = ['opened_at', 'resolved_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        self.df['resolution_hours'] = (self.df['resolved_at'] - self.df['opened_at']).dt.total_seconds() / 3600
        
        # Keep only resolved incidents
        self.df = self.df[
            (self.df['close_notes'].str.len() > 10) & 
            (self.df['resolution_hours'].notna())
        ].copy()
        
        print(f"✓ Analyzing {len(self.df):,} resolved incidents\n")
    
    def cluster_by_short_description(self):
        print("STEP 1: Clustering by short_description...")
        
        # Normalize short descriptions
        self.df['desc_normalized'] = self.df['short_description'].apply(self._normalize)
        
        # Create cluster signature (key words)
        self.df['cluster_signature'] = self.df['desc_normalized'].apply(self._extract_signature)
        
        # Assign cluster IDs
        self.df['cluster_id'] = self.df.groupby('cluster_signature').ngroup()
        
        # Calculate cluster statistics
        clusters = self.df.groupby('cluster_id').agg({
            'number': 'count',
            'short_description': 'first',
            'cluster_signature': 'first',
            'application': lambda x: ', '.join(x.value_counts().head(3).index.tolist()),
            'assigned_to': 'nunique',
            'resolution_hours': ['mean', 'sum'],
            'close_notes': lambda x: self._common_resolution(x)
        })
        
        clusters.columns = ['Incident_Count', 'Example_Issue', 'Pattern', 'Top_Applications',
                           'Team_Members_Involved', 'Avg_Hours', 'Total_Hours', 'Common_Resolution']
        
        clusters = clusters[clusters['Incident_Count'] >= 5]  # Focus on recurring (5+)
        clusters = clusters.sort_values('Incident_Count', ascending=False)
        
        self.clusters = clusters
        
        print(f"✓ Found {len(clusters):,} recurring issue clusters (5+ incidents each)")
        print(f"  - Total incidents in clusters: {clusters['Incident_Count'].sum():,}")
        print(f"  - Total hours spent: {clusters['Total_Hours'].sum():,.0f}")
        print(f"  - Unique team members: {self.df['assigned_to'].nunique():,}\n")
    
    def _normalize(self, text):
        """Normalize text for clustering"""
        text = str(text).lower()
        # Replace variable parts with placeholders
        text = re.sub(r'\d{4,}', 'NUM', text)
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IP', text)
        text = re.sub(r'\b[a-z]{2,4}\d{2}[a-z0-9]+\b', 'SERVER', text)
        text = re.sub(r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', 'DATE', text)
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def _extract_signature(self, text):
        """Extract meaningful signature from normalized text"""
        words = text.split()
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'error', 'failure', 'issue'}
        meaningful = [w for w in words if w not in stopwords and len(w) > 3][:8]
        return ' '.join(sorted(meaningful)) if meaningful else text[:50]
    
    def _common_resolution(self, resolutions):
        """Find most common resolution approach"""
        # Look for action keywords
        all_text = ' '.join([str(r).lower() for r in resolutions if pd.notna(r)])
        
        actions = {
            'Restarted': r'\b(restart|restarted|reboot|rebooted)\b',
            'Cleared': r'\b(clear|cleared|delete|deleted|purge)\b',
            'Reset': r'\b(reset)\b',
            'Fixed': r'\b(fix|fixed|correct|corrected)\b',
            'Executed': r'\b(execute|executed|run|ran|rerun)\b',
            'Updated': r'\b(update|updated|modify|modified)\b',
            'Granted': r'\b(grant|granted|add|added)\b',
            'Killed': r'\b(kill|killed|stop|stopped)\b'
        }
        
        for action, pattern in actions.items():
            if re.search(pattern, all_text):
                # Find example
                for res in resolutions:
                    if pd.notna(res) and re.search(pattern, str(res).lower()):
                        return f"{action}: {str(res)[:150]}"
        
        # Return first non-empty
        for res in resolutions:
            if pd.notna(res) and len(str(res)) > 10:
                return str(res)[:150]
        
        return 'Resolution not documented'
    
    def generate_cluster_summaries(self):
        print("STEP 2: Generating detailed summaries for each cluster...")
        
        output_dir = 'output_clear_analysis/cluster_summaries'
        
        summaries = []
        
        for cluster_id, cluster_row in self.clusters.head(100).iterrows():
            cluster_data = self.df[self.df['cluster_id'] == cluster_id]
            
            # Get detailed info
            apps = cluster_data['application'].value_counts()
            team_members = cluster_data['assigned_to'].value_counts()
            resolutions = cluster_data['close_notes'].tolist()
            
            # Create summary
            summary = {
                'Cluster_ID': cluster_id,
                'Issue_Pattern': cluster_row['Example_Issue'],
                'Total_Incidents': cluster_row['Incident_Count'],
                'Total_Hours_Spent': round(cluster_row['Total_Hours'], 0),
                'Avg_Hours_Per_Incident': round(cluster_row['Avg_Hours'], 2),
                'Team_Members_Involved': cluster_row['Team_Members_Involved'],
                'Top_3_Applications': ', '.join(apps.head(3).index.tolist()),
                'Top_3_Team_Members': ', '.join(team_members.head(3).index.tolist()),
                'Common_Resolution': cluster_row['Common_Resolution'],
                'Automation_Potential': self._assess_automation(cluster_row['Incident_Count'], 
                                                                cluster_row['Avg_Hours'],
                                                                cluster_row['Common_Resolution'])
            }
            
            summaries.append(summary)
            
            # Detailed CSV for this cluster
            cluster_detail = cluster_data[[
                'number', 'application', 'assigned_to', 'short_description',
                'resolution_hours', 'close_notes'
            ]].copy()
            
            cluster_detail = cluster_detail.sort_values('resolution_hours', ascending=False)
            cluster_detail.to_csv(f'{output_dir}/cluster_{cluster_id:04d}_details.csv', index=False)
        
        # Save all summaries
        summaries_df = pd.DataFrame(summaries)
        summaries_df.to_csv(f'{output_dir}/ALL_CLUSTER_SUMMARIES.csv', index=False)
        
        self.summaries = summaries_df
        
        print(f"✓ Created summaries for {len(summaries):,} clusters\n")
    
    def _assess_automation(self, count, avg_hours, resolution):
        """Simple automation assessment"""
        res_lower = str(resolution).lower()
        
        if count >= 20 and avg_hours < 2:
            if any(word in res_lower for word in ['restart', 'clear', 'delete', 'reset', 'run']):
                return 'HIGH - Easy automation'
        
        if count >= 10:
            if any(word in res_lower for word in ['restart', 'clear', 'execute']):
                return 'MEDIUM - Good candidate'
        
        if count >= 5:
            return 'LOW - Consider if high impact'
        
        return 'MINIMAL - Not priority'
    
    def generate_solutions(self):
        print("STEP 3: Generating reduction solutions...")
        
        output_dir = 'output_clear_analysis/solutions'
        
        solutions = []
        
        # Focus on high automation potential
        high_potential = self.summaries[
            self.summaries['Automation_Potential'].str.contains('HIGH|MEDIUM', na=False)
        ].copy()
        
        for idx, row in high_potential.iterrows():
            # Determine solution type
            resolution = row['Common_Resolution'].lower()
            
            if 'restart' in resolution or 'reboot' in resolution:
                solution_type = 'Automated Restart Script'
                implementation = 'Monitor service health → Auto-restart on failure'
                automation_rate = 85
                
            elif 'clear' in resolution or 'delete' in resolution:
                solution_type = 'Automated Cleanup Script'
                implementation = 'Schedule regular cleanup → Monitor disk space'
                automation_rate = 90
                
            elif 'execute' in resolution or 'run' in resolution or 'rerun' in resolution:
                solution_type = 'Auto-Retry Logic'
                implementation = 'Detect failure → Auto-retry with backoff'
                automation_rate = 80
                
            elif 'reset' in resolution:
                solution_type = 'Self-Service Portal'
                implementation = 'User self-service → Auto-approval for standard requests'
                automation_rate = 95
                
            elif 'grant' in resolution or 'add' in resolution:
                solution_type = 'Access Management Automation'
                implementation = 'Workflow-based approval → Auto-provisioning'
                automation_rate = 75
                
            else:
                solution_type = 'Custom Automation'
                implementation = 'Pattern detection → Automated remediation'
                automation_rate = 60
            
            # Calculate impact
            current_hours = row['Total_Hours_Spent']
            current_team = row['Team_Members_Involved']
            
            automated_hours = current_hours * (automation_rate / 100)
            remaining_hours = current_hours - automated_hours
            team_reduction = max(1, int(current_team * (automation_rate / 100)))
            
            solutions.append({
                'Issue_Pattern': row['Issue_Pattern'][:100],
                'Current_Incidents': row['Total_Incidents'],
                'Current_Total_Hours': int(current_hours),
                'Current_Team_Members': current_team,
                'Current_Resolution': row['Common_Resolution'][:100],
                'Applications': row['Top_3_Applications'][:80],
                'Solution_Type': solution_type,
                'How_It_Works': implementation,
                'Automation_Rate': f"{automation_rate}%",
                'Hours_Saved': int(automated_hours),
                'Hours_After_Automation': int(remaining_hours),
                'Team_Members_Freed': team_reduction,
                'Annual_Savings_USD': f"${int(automated_hours * 50):,}",
                'Effort_Reduction': f"{automation_rate}% reduction"
            })
        
        if solutions:
            solutions_df = pd.DataFrame(solutions)
            solutions_df = solutions_df.sort_values('Hours_Saved', ascending=False)
            solutions_df.to_csv(f'{output_dir}/REDUCTION_SOLUTIONS.csv', index=False)
            
            # Create readable summary
            self._create_solution_report(solutions_df, output_dir)
            
            self.solutions = solutions_df
        else:
            self.solutions = pd.DataFrame()
        
        print(f"✓ Created {len(solutions):,} reduction solutions\n")
    
    def _create_solution_report(self, solutions_df, output_dir):
        """Create clear, readable solution report"""
        with open(f'{output_dir}/SOLUTIONS_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("HOW TO REDUCE EFFORT - CLEAR SOLUTIONS\n")
            f.write("=" * 100 + "\n\n")
            
            total_current_hours = solutions_df['Current_Total_Hours'].sum()
            total_saved_hours = solutions_df['Hours_Saved'].sum()
            total_team_freed = solutions_df['Team_Members_Freed'].sum()
            
            f.write(f"CURRENT SITUATION:\n")
            f.write(f"  - Team members working on these issues: {self.df['assigned_to'].nunique():,}\n")
            f.write(f"  - Total hours spent annually: {total_current_hours:,} hours\n")
            f.write(f"  - Annual cost: ${total_current_hours * 50:,}\n\n")
            
            f.write(f"AFTER AUTOMATION:\n")
            f.write(f"  - Hours saved: {total_saved_hours:,} hours ({total_saved_hours/total_current_hours*100:.0f}%)\n")
            f.write(f"  - Team members freed: ~{total_team_freed} people\n")
            f.write(f"  - Annual savings: ${total_saved_hours * 50:,}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write(f"TOP {min(15, len(solutions_df))} SOLUTIONS (Ranked by Hours Saved)\n")
            f.write("=" * 100 + "\n\n")
            
            for idx, row in solutions_df.head(15).iterrows():
                f.write(f"\n{idx+1}. ISSUE: {row['Issue_Pattern']}\n")
                f.write(f"   Occurs: {row['Current_Incidents']} times/year\n")
                f.write(f"   Applications: {row['Applications']}\n\n")
                
                f.write(f"   CURRENT SITUATION:\n")
                f.write(f"   - Team members handling this: {row['Current_Team_Members']}\n")
                f.write(f"   - Total hours spent: {row['Current_Total_Hours']:,} hours/year\n")
                f.write(f"   - What they do: {row['Current_Resolution']}\n\n")
                
                f.write(f"   SOLUTION: {row['Solution_Type']}\n")
                f.write(f"   - How it works: {row['How_It_Works']}\n")
                f.write(f"   - Automation rate: {row['Automation_Rate']}\n\n")
                
                f.write(f"   AFTER AUTOMATION:\n")
                f.write(f"   - Hours saved: {row['Hours_Saved']:,} hours/year\n")
                f.write(f"   - Hours remaining: {row['Hours_After_Automation']:,} hours (edge cases)\n")
                f.write(f"   - Team members freed: {row['Team_Members_Freed']}\n")
                f.write(f"   - Annual savings: {row['Annual_Savings_USD']}\n")
                f.write(f"   - {row['Effort_Reduction']}\n")
                f.write("\n" + "-" * 100 + "\n")
    
    def generate_master_excel(self):
        print("Creating CLEAR_EFFORT_ANALYSIS.xlsx...")
        
        excel_file = 'output_clear_analysis/CLEAR_EFFORT_ANALYSIS.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Executive Summary
            exec_summary = pd.DataFrame({
                'Metric': [
                    'Total Incidents Analyzed',
                    'Recurring Issue Clusters (5+)',
                    'Total Team Members Involved',
                    'Total Hours Spent Annually',
                    'Automatable Hours (High/Medium)',
                    'Potential Hours Saved',
                    'Potential Annual Savings',
                    'Team Members That Can Be Freed',
                    'Expected Effort Reduction %'
                ],
                'Value': [
                    len(self.df),
                    len(self.clusters),
                    self.df['assigned_to'].nunique(),
                    f"{self.clusters['Total_Hours'].sum():,.0f}",
                    f"{self.solutions['Current_Total_Hours'].sum():,}" if hasattr(self, 'solutions') and len(self.solutions) > 0 else "0",
                    f"{self.solutions['Hours_Saved'].sum():,}" if hasattr(self, 'solutions') and len(self.solutions) > 0 else "0",
                    f"${self.solutions['Hours_Saved'].sum() * 50:,.0f}" if hasattr(self, 'solutions') and len(self.solutions) > 0 else "$0",
                    self.solutions['Team_Members_Freed'].sum() if hasattr(self, 'solutions') and len(self.solutions) > 0 else 0,
                    f"{self.solutions['Hours_Saved'].sum() / self.clusters['Total_Hours'].sum() * 100:.0f}%" if hasattr(self, 'solutions') and len(self.solutions) > 0 else "0%"
                ]
            })
            exec_summary.to_excel(writer, sheet_name='Executive_Summary', index=False)
            
            # Sheet 2: All Clusters
            self.clusters.to_excel(writer, sheet_name='All_Clusters')
            
            # Sheet 3: Cluster Summaries
            if hasattr(self, 'summaries'):
                self.summaries.to_excel(writer, sheet_name='Cluster_Summaries', index=False)
            
            # Sheet 4: Solutions
            if hasattr(self, 'solutions') and len(self.solutions) > 0:
                self.solutions.to_excel(writer, sheet_name='Solutions', index=False)
        
        print(f"✓ Created {excel_file}\n")
    
    def run_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING CLEAR EFFORT ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.cluster_by_short_description()
        self.generate_cluster_summaries()
        self.generate_solutions()
        self.generate_master_excel()
        
        print("\n" + "=" * 100)
        print("ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 OUTPUTS:\n")
        print("MAIN FILE:")
        print("  ✓ CLEAR_EFFORT_ANALYSIS.xlsx ⭐\n")
        print("DETAILED FILES:")
        print("  ✓ cluster_summaries/ALL_CLUSTER_SUMMARIES.csv")
        print("  ✓ cluster_summaries/cluster_NNNN_details.csv (for each cluster)")
        print("  ✓ solutions/REDUCTION_SOLUTIONS.csv ⭐⭐⭐")
        print("  ✓ solutions/SOLUTIONS_SUMMARY.txt ⭐⭐ READ THIS!\n")
        
        if hasattr(self, 'solutions') and len(self.solutions) > 0:
            total_saved = self.solutions['Hours_Saved'].sum()
            team_freed = self.solutions['Team_Members_Freed'].sum()
            print(f"💡 KEY FINDINGS:")
            print(f"   - {total_saved:,} hours can be saved annually")
            print(f"   - ~{team_freed} team members can be freed for other work")
            print(f"   - ${total_saved * 50:,} potential annual savings\n")
        
        print("=" * 100 + "\n")
        print("👉 READ: solutions/SOLUTIONS_SUMMARY.txt for clear, actionable recommendations\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = ClearEffortAnalyzer(FILE_PATH)
        analyzer.run_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
