"""
SOLUTION-BASED CLUSTERING ANALYSIS
Analyze close_notes to extract solutions → Categorize solutions → Cluster by solution type
Then map: Solution Type → Short Description → Application → Assignee
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class SolutionBasedAnalyzer:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        print("=" * 100)
        print("SOLUTION-BASED CLUSTERING ANALYSIS".center(100))
        print("=" * 100)
        print("\nAnalyzing close_notes → Extract solutions → Cluster by solution type...\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load application mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
            print("⚠ Using service_offering for applications")
        
        os.makedirs('output_solution_analysis', exist_ok=True)
        os.makedirs('output_solution_analysis/by_solution_type', exist_ok=True)
        os.makedirs('output_solution_analysis/solution_playbooks', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing solution analysis dataset...")
        
        # Map applications
        if self.mapping_dict:
            self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        else:
            self.df['application'] = self.df.get('service_offering', 'Unknown')
        
        self.df['application'] = self.df['application'].fillna('Unknown')
        
        # Clean fields
        self.df['short_description'] = self.df['short_description'].fillna('').astype(str)
        self.df['close_notes'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['assigned_to'] = self.df.get('assigned_to', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        
        # Filter to incidents with resolution notes
        self.df = self.df[self.df['close_notes'].str.len() > 20].copy()
        
        print(f"✓ Prepared {len(self.df):,} incidents with resolution notes\n")
    
    def extract_solution_steps(self):
        """Extract detailed solution steps from close_notes"""
        print("STEP 1: Extracting solution steps from close_notes...")
        
        solutions = []
        
        for idx, row in self.df.iterrows():
            close_notes = row['close_notes']
            
            # Extract solution components
            solution_data = {
                'incident': row.get('number', 'Unknown'),
                'short_description': row['short_description'],
                'application': row['application'],
                'assigned_to': row['assigned_to'],
                'close_notes': close_notes,
                'primary_action': self._extract_primary_action(close_notes),
                'solution_type': self._categorize_solution(close_notes),
                'steps_taken': self._extract_steps(close_notes),
                'tools_used': self._extract_tools(close_notes),
                'root_cause': self._extract_root_cause(close_notes),
                'prevention': self._extract_prevention(close_notes)
            }
            
            solutions.append(solution_data)
        
        self.df_solutions = pd.DataFrame(solutions)
        
        print(f"✓ Extracted solution details from {len(self.df_solutions):,} incidents\n")
    
    def _extract_primary_action(self, text):
        """Extract the primary action taken"""
        text_lower = str(text).lower()
        
        actions = {
            'Restarted Service': r'\b(restart|restarted|reboot|rebooted)\s+(service|server|application|system|job)',
            'Cleared/Deleted Files': r'\b(clear|cleared|delete|deleted|removed|purge|purged)\s+(file|log|cache|temp|disk)',
            'Killed Process/Session': r'\b(kill|killed|terminate|terminated|stop|stopped)\s+(process|session|spid|connection)',
            'Reset Password/Access': r'\b(reset|resetted)\s+(password|access|account|credential)',
            'Granted Permission': r'\b(grant|granted|add|added|enable|enabled)\s+(permission|access|right|role)',
            'Reran Job/Batch': r'\b(rerun|reran|re-run|re-ran|execute|executed)\s+(job|batch|process|script)',
            'Updated Configuration': r'\b(update|updated|change|changed|modify|modified)\s+(config|configuration|setting|parameter)',
            'Applied Patch/Fix': r'\b(apply|applied|install|installed|deploy|deployed)\s+(patch|fix|update|hotfix)',
            'Optimized/Tuned': r'\b(optimize|optimized|tune|tuned|rebuild|rebuilt)\s+(index|query|database|performance)',
            'Escalated': r'\b(escalate|escalated|forward|forwarded|transfer|transferred)',
            'Monitored': r'\b(monitor|monitored|watch|watched|observe|observed)',
            'Investigated': r'\b(investigate|investigated|check|checked|review|reviewed|research|researched)'
        }
        
        for action_name, pattern in actions.items():
            if re.search(pattern, text_lower):
                return action_name
        
        # Check for standalone actions
        if re.search(r'\b(restart|restarted|reboot|rebooted)\b', text_lower):
            return 'Restarted'
        elif re.search(r'\b(clear|cleared|delete|deleted)\b', text_lower):
            return 'Cleared/Deleted'
        elif re.search(r'\b(fix|fixed|correct|corrected)\b', text_lower):
            return 'Fixed'
        
        return 'Other/Manual Action'
    
    def _categorize_solution(self, text):
        """Categorize the solution into standard types"""
        text_lower = str(text).lower()
        
        # Check for solution patterns
        if re.search(r'\b(restart|reboot|bounce)\b', text_lower):
            return 'Service Restart'
        
        elif re.search(r'\b(disk|space|storage|full|capacity)\b', text_lower) and \
             re.search(r'\b(clear|delete|clean|purge)\b', text_lower):
            return 'Disk Space Cleanup'
        
        elif re.search(r'\b(batch|job|schedule)\b', text_lower) and \
             re.search(r'\b(rerun|execute|retry)\b', text_lower):
            return 'Batch Job Retry'
        
        elif re.search(r'\b(password|reset|unlock)\b', text_lower):
            return 'Password Reset'
        
        elif re.search(r'\b(permission|access|grant|add)\b', text_lower):
            return 'Access Grant'
        
        elif re.search(r'\b(kill|terminate|stop)\b', text_lower) and \
             re.search(r'\b(session|spid|process|connection)\b', text_lower):
            return 'Process/Session Termination'
        
        elif re.search(r'\b(database|query|index|sql)\b', text_lower) and \
             re.search(r'\b(optimize|rebuild|tune)\b', text_lower):
            return 'Database Optimization'
        
        elif re.search(r'\b(config|configuration|setting)\b', text_lower) and \
             re.search(r'\b(update|change|modify)\b', text_lower):
            return 'Configuration Change'
        
        elif re.search(r'\b(patch|hotfix|update)\b', text_lower):
            return 'Patch/Update Applied'
        
        elif re.search(r'\b(network|connectivity|vpn|connection)\b', text_lower):
            return 'Network Issue Resolution'
        
        elif re.search(r'\b(monitor|alert|threshold)\b', text_lower) and \
             re.search(r'\b(tune|adjust|disable)\b', text_lower):
            return 'Monitoring Adjustment'
        
        elif re.search(r'\b(escalate|forward|vendor|support)\b', text_lower):
            return 'Escalated to Vendor/Team'
        
        else:
            return 'General Troubleshooting'
    
    def _extract_steps(self, text):
        """Extract step-by-step actions"""
        text_lower = str(text).lower()
        steps = []
        
        # Look for numbered steps
        numbered = re.findall(r'\d+[.)]\s*([^\n]+)', text)
        if numbered:
            return ' → '.join(numbered[:5])
        
        # Look for common action verbs
        if 'checked' in text_lower or 'verified' in text_lower:
            steps.append('Checked/Verified')
        if 'restart' in text_lower or 'reboot' in text_lower:
            steps.append('Restarted')
        if 'clear' in text_lower or 'delete' in text_lower:
            steps.append('Cleared')
        if 'monitor' in text_lower or 'confirm' in text_lower:
            steps.append('Monitored/Confirmed')
        
        return ' → '.join(steps) if steps else 'Single action'
    
    def _extract_tools(self, text):
        """Extract tools/systems used"""
        text_lower = str(text).lower()
        tools = []
        
        tool_patterns = {
            'SQL Server': r'\b(sql server|ssms|t-sql)\b',
            'PowerShell': r'\b(powershell|ps1)\b',
            'Command Line': r'\b(cmd|command line|cli)\b',
            'Control-M': r'\b(control-m|controlm|ctm)\b',
            'Dynatrace': r'\b(dynatrace|dt)\b',
            'PagerDuty': r'\b(pagerduty|pager duty)\b',
            'ServiceNow': r'\b(servicenow|snow)\b',
            'Active Directory': r'\b(active directory|ad|ldap)\b'
        }
        
        for tool, pattern in tool_patterns.items():
            if re.search(pattern, text_lower):
                tools.append(tool)
        
        return ', '.join(tools) if tools else 'Unknown'
    
    def _extract_root_cause(self, text):
        """Extract root cause if mentioned"""
        text_lower = str(text).lower()
        
        if re.search(r'root cause', text_lower):
            # Extract sentence containing root cause
            match = re.search(r'root cause[:\s]+([^.]+)', text_lower)
            if match:
                return match.group(1)[:100]
        
        if re.search(r'\bcause[d]?\s*:?\s*\b', text_lower):
            match = re.search(r'cause[d]?\s*:?\s*([^.]+)', text_lower)
            if match:
                return match.group(1)[:100]
        
        # Look for common causes
        if re.search(r'\b(timeout|timed out)\b', text_lower):
            return 'Timeout'
        elif re.search(r'\b(disk full|space|capacity)\b', text_lower):
            return 'Disk space issue'
        elif re.search(r'\b(deadlock|blocking)\b', text_lower):
            return 'Database deadlock/blocking'
        elif re.search(r'\b(memory|out of memory)\b', text_lower):
            return 'Memory issue'
        
        return 'Not specified'
    
    def _extract_prevention(self, text):
        """Extract prevention measures if mentioned"""
        text_lower = str(text).lower()
        
        if re.search(r'\b(prevent|prevention|avoid|future)\b', text_lower):
            match = re.search(r'(prevent|prevention|avoid|future)[^.]{0,100}', text_lower)
            if match:
                return match.group(0)[:100]
        
        return 'None mentioned'
    
    def cluster_by_solution_type(self):
        """Cluster incidents by solution type"""
        print("STEP 2: Clustering by solution type...")
        
        # Group by solution type
        solution_clusters = self.df_solutions.groupby('solution_type').agg({
            'incident': 'count',
            'application': lambda x: x.value_counts().to_dict(),
            'assigned_to': lambda x: x.value_counts().to_dict(),
            'short_description': lambda x: list(x.value_counts().head(5).index),
            'primary_action': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Various',
            'steps_taken': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Varies',
            'root_cause': lambda x: x.value_counts().to_dict()
        })
        
        solution_clusters.columns = ['Incident_Count', 'Applications', 'Assignees',
                                     'Common_Issues', 'Primary_Action', 'Typical_Steps', 'Root_Causes']
        
        solution_clusters = solution_clusters.sort_values('Incident_Count', ascending=False)
        
        self.solution_clusters = solution_clusters
        
        print(f"✓ Created {len(solution_clusters):,} solution type clusters\n")
    
    def generate_solution_playbooks(self):
        """Generate detailed playbooks for each solution type"""
        print("STEP 3: Generating solution playbooks...")
        
        output_dir = 'output_solution_analysis/solution_playbooks'
        
        playbooks = []
        
        for solution_type, cluster_data in self.solution_clusters.iterrows():
            # Get all incidents of this solution type
            solution_incidents = self.df_solutions[self.df_solutions['solution_type'] == solution_type]
            
            # Top applications using this solution
            app_counts = cluster_data['Applications']
            top_apps = sorted(app_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            
            # Top assignees using this solution
            assignee_counts = cluster_data['Assignees']
            top_assignees = sorted(assignee_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            
            # Root cause distribution
            root_causes = cluster_data['Root_Causes']
            top_causes = sorted(root_causes.items(), key=lambda x: x[1], reverse=True)[:5]
            
            playbook = {
                'Solution_Type': solution_type,
                'Total_Uses': cluster_data['Incident_Count'],
                'Primary_Action': cluster_data['Primary_Action'],
                'Typical_Steps': cluster_data['Typical_Steps'],
                'Top_5_Applications': '; '.join([f"{app} ({count}x)" for app, count in top_apps]),
                'Top_5_Assignees': '; '.join([f"{name} ({count}x)" for name, count in top_assignees]),
                'Common_Root_Causes': '; '.join([f"{cause} ({count}x)" for cause, count in top_causes if cause != 'Not specified']),
                'Example_Issues': '; '.join(cluster_data['Common_Issues'][:3]),
                'Automation_Potential': self._assess_playbook_automation(solution_type, cluster_data['Incident_Count'])
            }
            
            playbooks.append(playbook)
            
            # Save detailed incidents for this solution type
            solution_detail = solution_incidents[[
                'incident', 'short_description', 'application', 'assigned_to',
                'primary_action', 'steps_taken', 'root_cause', 'close_notes'
            ]].copy()
            
            safe_name = re.sub(r'[<>:"/\\|?*]', '_', solution_type)[:50]
            solution_detail.to_csv(f'{output_dir}/{safe_name}_details.csv', index=False)
        
        playbooks_df = pd.DataFrame(playbooks)
        playbooks_df = playbooks_df.sort_values('Total_Uses', ascending=False)
        playbooks_df.to_csv(f'{output_dir}/ALL_SOLUTION_PLAYBOOKS.csv', index=False)
        
        self.playbooks = playbooks_df
        
        print(f"✓ Created {len(playbooks):,} solution playbooks\n")
    
    def _assess_playbook_automation(self, solution_type, count):
        """Assess automation potential for this solution type"""
        automation_friendly = [
            'Service Restart',
            'Disk Space Cleanup',
            'Batch Job Retry',
            'Password Reset',
            'Process/Session Termination',
            'Database Optimization'
        ]
        
        if solution_type in automation_friendly:
            if count >= 50:
                return 'HIGH - Automate immediately'
            elif count >= 20:
                return 'MEDIUM - Good candidate'
            else:
                return 'LOW - Consider if critical'
        else:
            return 'MANUAL - Requires judgment'
    
    def map_solution_to_issue_patterns(self):
        """Map solution types to issue patterns"""
        print("STEP 4: Mapping solutions to issue patterns...")
        
        mappings = []
        
        for solution_type in self.df_solutions['solution_type'].unique():
            solution_data = self.df_solutions[self.df_solutions['solution_type'] == solution_type]
            
            # Cluster short descriptions for this solution
            desc_patterns = solution_data['short_description'].value_counts().head(10)
            
            for issue_pattern, count in desc_patterns.items():
                # Get applications for this specific issue+solution combo
                issue_solution_data = solution_data[solution_data['short_description'] == issue_pattern]
                app_dist = issue_solution_data['application'].value_counts()
                assignee_dist = issue_solution_data['assigned_to'].value_counts()
                
                mappings.append({
                    'Solution_Type': solution_type,
                    'Issue_Pattern': issue_pattern[:100],
                    'Occurrences': count,
                    'Top_Application': app_dist.index[0] if len(app_dist) > 0 else 'Unknown',
                    'Application_Count': len(app_dist),
                    'Top_Assignee': assignee_dist.index[0] if len(assignee_dist) > 0 else 'Unknown',
                    'Assignee_Count': len(assignee_dist),
                    'Consistency_Score': (count / len(solution_data) * 100)
                })
        
        mappings_df = pd.DataFrame(mappings)
        mappings_df = mappings_df.sort_values('Occurrences', ascending=False)
        mappings_df.to_csv('output_solution_analysis/SOLUTION_ISSUE_MAPPING.csv', index=False)
        
        self.mappings = mappings_df
        
        print(f"✓ Created {len(mappings):,} solution-to-issue mappings\n")
    
    def generate_master_report(self):
        print("Generating SOLUTION_ANALYSIS_REPORT.txt...")
        
        report_file = 'output_solution_analysis/SOLUTION_ANALYSIS_REPORT.txt'
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("=" * 120 + "\n")
            f.write("SOLUTION-BASED CLUSTERING ANALYSIS REPORT\n".center(120))
            f.write("=" * 120 + "\n\n")
            
            f.write("ANALYSIS APPROACH:\n")
            f.write("1. Analyzed close_notes to extract solution steps\n")
            f.write("2. Categorized solutions into standard types\n")
            f.write("3. Clustered incidents by solution type\n")
            f.write("4. Mapped: Solution → Issue Pattern → Application → Assignee\n\n")
            
            f.write("=" * 120 + "\n")
            f.write("SECTION 1: SOLUTION TYPE DISTRIBUTION\n")
            f.write("=" * 120 + "\n\n")
            
            f.write(f"{'Solution Type':<40}{'Uses':<10}{'Top Application':<35}{'Automation'}\n")
            f.write("-" * 120 + "\n")
            
            for idx, row in self.playbooks.head(15).iterrows():
                top_app = row['Top_5_Applications'].split(';')[0] if row['Top_5_Applications'] else 'Unknown'
                f.write(f"{row['Solution_Type'][:38]:<40}{int(row['Total_Uses']):<10,}{top_app[:33]:<35}{row['Automation_Potential'][:25]}\n")
            
            f.write("\n" + "=" * 120 + "\n")
            f.write("SECTION 2: TOP 10 SOLUTION PLAYBOOKS\n")
            f.write("=" * 120 + "\n\n")
            
            for rank, (idx, row) in enumerate(self.playbooks.head(10).iterrows(), 1):
                f.write(f"\n{rank}. {row['Solution_Type']}\n")
                f.write(f"{'─' * 120}\n")
                f.write(f"   Uses: {int(row['Total_Uses']):,} times\n")
                f.write(f"   Primary Action: {row['Primary_Action']}\n")
                f.write(f"   Typical Steps: {row['Typical_Steps']}\n")
                f.write(f"   Top Applications: {row['Top_5_Applications'][:80]}\n")
                f.write(f"   Top Assignees: {row['Top_5_Assignees'][:80]}\n")
                f.write(f"   Common Root Causes: {row['Common_Root_Causes'][:80]}\n")
                f.write(f"   Example Issues: {row['Example_Issues'][:80]}\n")
                f.write(f"   Automation: {row['Automation_Potential']}\n")
            
            f.write("\n" + "=" * 120 + "\n")
            f.write("SECTION 3: SOLUTION → ISSUE → APPLICATION MAPPING\n")
            f.write("=" * 120 + "\n\n")
            
            f.write("Top 20 Most Common Patterns:\n\n")
            f.write(f"{'Solution Type':<30}{'Issue Pattern':<45}{'Count':<8}{'Application'}\n")
            f.write("-" * 120 + "\n")
            
            for idx, row in self.mappings.head(20).iterrows():
                f.write(f"{row['Solution_Type'][:28]:<30}{row['Issue_Pattern'][:43]:<45}")
                f.write(f"{int(row['Occurrences']):<8,}{row['Top_Application'][:30]}\n")
            
            f.write("\n" + "=" * 120 + "\n")
            f.write("END OF SOLUTION ANALYSIS REPORT\n".center(120))
            f.write("=" * 120 + "\n")
        
        print(f"✓ Created: {report_file}\n")
    
    def generate_excel_summary(self):
        print("Generating SOLUTION_ANALYSIS_MASTER.xlsx...")
        
        excel_file = 'output_solution_analysis/SOLUTION_ANALYSIS_MASTER.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Solution Playbooks
            self.playbooks.to_excel(writer, sheet_name='Solution_Playbooks', index=False)
            
            # Sheet 2: Solution-Issue Mapping
            self.mappings.to_excel(writer, sheet_name='Solution_Issue_Mapping', index=False)
            
            # Sheet 3: By Solution Type
            for solution_type in self.playbooks.head(10)['Solution_Type']:
                solution_data = self.df_solutions[self.df_solutions['solution_type'] == solution_type]
                
                summary = solution_data.groupby('application').agg({
                    'incident': 'count',
                    'assigned_to': 'nunique'
                })
                summary.columns = ['Incidents', 'Team_Members']
                summary = summary.sort_values('Incidents', ascending=False)
                
                safe_name = re.sub(r'[<>:"/\\|?*\[\]]', '_', solution_type)[:30]
                summary.to_excel(writer, sheet_name=safe_name)
        
        print(f"✓ Created: {excel_file}\n")
    
    def run_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING SOLUTION-BASED ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.extract_solution_steps()
        self.cluster_by_solution_type()
        self.generate_solution_playbooks()
        self.map_solution_to_issue_patterns()
        self.generate_master_report()
        self.generate_excel_summary()
        
        print("\n" + "=" * 100)
        print("SOLUTION-BASED ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 OUTPUTS:\n")
        print("  ✓ SOLUTION_ANALYSIS_REPORT.txt ⭐⭐⭐")
        print("  ✓ SOLUTION_ANALYSIS_MASTER.xlsx ⭐⭐")
        print("  ✓ solution_playbooks/ALL_SOLUTION_PLAYBOOKS.csv ⭐⭐⭐")
        print("  ✓ SOLUTION_ISSUE_MAPPING.csv ⭐\n")
        print("=" * 100 + "\n")
        print("👉 Shows: Solution Type → Issue Pattern → Application → Assignee\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = SolutionBasedAnalyzer(FILE_PATH)
        analyzer.run_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
