"""
INCIDENT APPLICATION CLUSTERING ANALYSIS
Groups similar incidents by short_description, then analyzes by application
Shows recurring issues across applications with resolution patterns
"""

import pandas as pd
import numpy as np
import re
from collections import Counter
import warnings
import os
warnings.filterwarnings('ignore')

class ApplicationClusterAnalyzer:
    def __init__(self, file_path, mapping_file='complete_application_mapping.csv'):
        print("=" * 100)
        print("APPLICATION-BASED INCIDENT CLUSTERING ANALYSIS".center(100))
        print("=" * 100)
        print("\nClustering by description, analyzing by application...\n")
        
        print("Loading incident data...")
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Loaded {len(self.df):,} incidents with {encoding} encoding")
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        
        # Load application mapping
        try:
            mapping = pd.read_csv(mapping_file)
            self.mapping_dict = dict(zip(mapping['assignment_group'], mapping['application']))
            print(f"✓ Loaded {len(self.mapping_dict)} application mappings")
        except:
            self.mapping_dict = {}
            print("⚠ No application mapping file found, using service_offering")
        
        os.makedirs('output_app_clustering', exist_ok=True)
        os.makedirs('output_app_clustering/by_application', exist_ok=True)
        os.makedirs('output_app_clustering/cross_application', exist_ok=True)
        os.makedirs('output_app_clustering/solution_proposals', exist_ok=True)
        print("✓ Created output directories\n")
    
    def prepare_data(self):
        print("Preparing application clustering dataset...")
        
        # Map to applications
        if self.mapping_dict:
            self.df['application'] = self.df['assignment_group'].map(self.mapping_dict)
        else:
            self.df['application'] = self.df.get('service_offering', 'Unknown')
        
        self.df['application'] = self.df['application'].fillna('Unknown')
        
        # Clean text
        self.df['short_description_clean'] = self.df['short_description'].fillna('').astype(str)
        self.df['short_description_normalized'] = self.df['short_description_clean'].apply(self._normalize_text)
        self.df['close_notes_clean'] = self.df.get('close_notes', pd.Series([''] * len(self.df))).fillna('').astype(str)
        self.df['category_clean'] = self.df.get('category', pd.Series([''] * len(self.df))).fillna('Unknown').astype(str)
        
        # Dates and resolution time
        date_cols = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_cols:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        print("✓ Dataset prepared\n")
    
    def _normalize_text(self, text):
        """Normalize text for clustering"""
        text = str(text).lower()
        # Replace variable parts with placeholders
        text = re.sub(r'\d{4,}', 'NNNNN', text)  # Long numbers
        text = re.sub(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b', 'IPADDR', text)
        text = re.sub(r'\b[a-z0-9]+@[a-z0-9]+\.[a-z]+\b', 'EMAIL', text)
        text = re.sub(r'\b[a-z]{2,4}\d{2}[a-z0-9]+\b', 'SERVERID', text)
        text = re.sub(r'\bon\s+\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b', 'on DATE', text)
        text = re.sub(r'\bat\s+\d{1,2}:\d{2}', 'at TIME', text)
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def create_issue_clusters(self):
        """Cluster similar issues across all applications"""
        print("Creating issue clusters from descriptions...")
        
        # Create pattern signature
        self.df['pattern_signature'] = self.df['short_description_normalized'].apply(
            lambda x: ' '.join(sorted(self._extract_keywords(x)))
        )
        
        # Assign cluster IDs
        self.df['issue_cluster_id'] = self.df.groupby('pattern_signature').ngroup()
        
        # Calculate cluster statistics
        cluster_stats = self.df.groupby('issue_cluster_id').agg({
            'number': 'count',
            'pattern_signature': 'first',
            'short_description_clean': 'first',
            'application': lambda x: x.nunique(),
            'resolution_hours': ['mean', 'median'],
            'close_notes_clean': lambda x: self._most_common_resolution(x)
        })
        
        cluster_stats.columns = ['Total_Incidents', 'Pattern', 'Example_Description',
                                'Num_Applications', 'Avg_Hours', 'Median_Hours', 'Common_Resolution']
        
        cluster_stats = cluster_stats.sort_values('Total_Incidents', ascending=False)
        self.cluster_stats = cluster_stats
        
        print(f"✓ Created {len(cluster_stats):,} issue clusters")
        print(f"  - Clusters affecting 5+ applications: {len(cluster_stats[cluster_stats['Num_Applications'] >= 5]):,}")
        print(f"  - Clusters with 10+ incidents: {len(cluster_stats[cluster_stats['Total_Incidents'] >= 10]):,}\n")
    
    def _extract_keywords(self, text):
        """Extract meaningful keywords"""
        words = text.split()
        stopwords = {'the', 'and', 'for', 'with', 'from', 'this', 'that', 'are', 'was', 'were',
                    'been', 'have', 'has', 'had', 'will', 'would', 'could', 'should', 'error',
                    'issue', 'problem', 'unable', 'cannot'}
        return [w for w in words if w not in stopwords and len(w) > 2][:8]
    
    def _most_common_resolution(self, resolutions):
        """Find most common resolution approach"""
        if len(resolutions) == 0:
            return ''
        
        # Extract key action words
        all_words = []
        for res in resolutions:
            if pd.notna(res) and len(str(res)) > 10:
                words = str(res).lower().split()
                action_words = [w for w in words if w in ['restart', 'restarted', 'reboot', 'cleared',
                               'reset', 'deleted', 'updated', 'fixed', 'corrected', 'modified',
                               'added', 'removed', 'granted', 'enabled', 'disabled']]
                all_words.extend(action_words)
        
        if all_words:
            most_common = Counter(all_words).most_common(1)[0][0]
            # Find a resolution that contains this word
            for res in resolutions:
                if pd.notna(res) and most_common in str(res).lower():
                    return str(res)[:300]
        
        # Return first non-empty resolution
        for res in resolutions:
            if pd.notna(res) and len(str(res)) > 10:
                return str(res)[:300]
        
        return 'No resolution documented'
    
    def analyze_cross_application_issues(self):
        """Identify issues occurring across multiple applications"""
        print("Analyzing cross-application issues...")
        
        cross_app_issues = []
        
        # Get clusters affecting 2+ applications
        multi_app_clusters = self.cluster_stats[self.cluster_stats['Num_Applications'] >= 2]
        
        for cluster_id, cluster_row in multi_app_clusters.iterrows():
            cluster_data = self.df[self.df['issue_cluster_id'] == cluster_id]
            
            # Get application breakdown
            app_breakdown = cluster_data.groupby('application').agg({
                'number': 'count',
                'resolution_hours': ['mean', 'median'],
                'close_notes_clean': lambda x: self._most_common_resolution(x)
            }).round(2)
            
            app_breakdown.columns = ['Incident_Count', 'Avg_Hours', 'Median_Hours', 'Common_Resolution']
            app_breakdown = app_breakdown.sort_values('Incident_Count', ascending=False)
            
            cross_app_issues.append({
                'Cluster_ID': cluster_id,
                'Issue_Pattern': cluster_row['Example_Description'],
                'Total_Incidents': cluster_row['Total_Incidents'],
                'Applications_Affected': cluster_row['Num_Applications'],
                'Top_3_Applications': ', '.join(app_breakdown.head(3).index.tolist()),
                'Avg_Resolution_Hours': cluster_row['Avg_Hours'],
                'Total_Hours_Spent': round(cluster_row['Total_Incidents'] * cluster_row['Avg_Hours'], 0),
                'Common_Resolution': cluster_row['Common_Resolution'][:200]
            })
        
        if cross_app_issues:
            cross_app_df = pd.DataFrame(cross_app_issues)
            cross_app_df = cross_app_df.sort_values('Total_Incidents', ascending=False)
            cross_app_df.to_csv('output_app_clustering/cross_application/cross_application_issues.csv', index=False)
        
        print(f"✓ Identified {len(cross_app_issues):,} cross-application issues\n")
    
    def generate_application_reports(self):
        """Generate detailed reports for each application"""
        print("Generating per-application cluster reports...")
        
        output_dir = 'output_app_clustering/by_application'
        
        # Get top 30 applications by incident count
        top_apps = self.df['application'].value_counts().head(30).index
        
        for app in top_apps:
            app_data = self.df[self.df['application'] == app]
            
            # Get cluster breakdown for this application
            app_clusters = app_data.groupby('issue_cluster_id').agg({
                'number': ['count', list],
                'short_description_clean': 'first',
                'resolution_hours': ['mean', 'median', 'sum'],
                'close_notes_clean': lambda x: self._most_common_resolution(x),
                'category_clean': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Mixed'
            })
            
            app_clusters.columns = ['Incident_Count', 'Incident_Numbers', 'Example_Description',
                                   'Avg_Hours', 'Median_Hours', 'Total_Hours',
                                   'Common_Resolution', 'Common_Category']
            
            app_clusters = app_clusters.sort_values('Incident_Count', ascending=False)
            
            # Add cross-app indicator
            app_clusters['Affects_Other_Apps'] = app_clusters.index.map(
                lambda x: self.cluster_stats.loc[x, 'Num_Applications'] > 1
            )
            
            # Add automation potential
            app_clusters['Automation_Potential'] = app_clusters.apply(
                lambda row: self._assess_automation(row['Incident_Count'], 
                                                    row['Median_Hours'],
                                                    row['Common_Resolution']), axis=1
            )
            
            safe_app = re.sub(r'[<>:"/\\|?*]', '_', str(app))[:50]
            app_clusters.to_csv(f'{output_dir}/APP_{safe_app}.csv')
        
        print(f"✓ Created reports for top 30 applications\n")
    
    def _assess_automation(self, count, median_hours, resolution):
        """Assess automation potential"""
        score = 0
        
        if count >= 10:
            score += 3
        elif count >= 5:
            score += 2
        
        if median_hours < 1:
            score += 2
        elif median_hours < 2:
            score += 1
        
        if pd.notna(resolution):
            res_lower = str(resolution).lower()
            automation_keywords = ['restart', 'reboot', 'clear', 'reset', 'delete', 'execute']
            if any(kw in res_lower for kw in automation_keywords):
                score += 2
        
        if score >= 5:
            return 'High'
        elif score >= 3:
            return 'Medium'
        else:
            return 'Low'
    
    def generate_solution_proposals(self):
        """Generate solution proposals based on recurring patterns"""
        print("Generating solution proposals...")
        
        output_dir = 'output_app_clustering/solution_proposals'
        
        proposals = []
        
        # High-value recurring issues (10+ incidents, affecting 2+ apps)
        high_value = self.cluster_stats[
            (self.cluster_stats['Total_Incidents'] >= 10) &
            (self.cluster_stats['Num_Applications'] >= 2)
        ]
        
        for cluster_id, cluster_row in high_value.iterrows():
            cluster_data = self.df[self.df['issue_cluster_id'] == cluster_id]
            
            # Get affected applications
            app_breakdown = cluster_data.groupby('application')['number'].count().sort_values(ascending=False)
            
            # Determine solution type
            resolution = str(cluster_row['Common_Resolution']).lower()
            solution = self._propose_solution(resolution, cluster_row['Example_Description'])
            
            proposals.append({
                'Issue_Pattern': cluster_row['Example_Description'],
                'Total_Occurrences': cluster_row['Total_Incidents'],
                'Applications_Affected': cluster_row['Num_Applications'],
                'Top_5_Applications': ', '.join(app_breakdown.head(5).index.tolist()),
                'Avg_Resolution_Hours': round(cluster_row['Avg_Hours'], 2),
                'Total_Hours_Lost': round(cluster_row['Total_Incidents'] * cluster_row['Avg_Hours'], 0),
                'Potential_Savings_Hours': round(cluster_row['Total_Incidents'] * cluster_row['Avg_Hours'] * 0.7, 0),
                'Potential_Savings_USD': f"${round(cluster_row['Total_Incidents'] * cluster_row['Avg_Hours'] * 0.7 * 50, 0):,}",
                'Current_Resolution': cluster_row['Common_Resolution'][:200],
                'Proposed_Solution': solution['solution'],
                'Solution_Type': solution['type'],
                'Implementation_Complexity': solution['complexity'],
                'Expected_Automation_Rate': solution['automation_rate']
            })
        
        if proposals:
            proposals_df = pd.DataFrame(proposals)
            proposals_df = proposals_df.sort_values('Total_Hours_Lost', ascending=False)
            proposals_df.to_csv(f'{output_dir}/SOLUTION_PROPOSALS.csv', index=False)
            
            # Create executive summary
            self._create_solution_summary(proposals_df, output_dir)
        
        print(f"✓ Created {len(proposals):,} solution proposals\n")
    
    def _propose_solution(self, resolution, description):
        """Propose automated solution based on resolution pattern"""
        res_lower = resolution.lower()
        desc_lower = description.lower()
        
        if 'restart' in res_lower or 'reboot' in res_lower:
            return {
                'solution': 'Automated Service Restart Script with health monitoring',
                'type': 'Automated Script',
                'complexity': 'Low',
                'automation_rate': '85%'
            }
        
        elif 'batch' in desc_lower and ('rerun' in res_lower or 'execute' in res_lower):
            return {
                'solution': 'Automated Batch Job Retry Logic with timeout handling',
                'type': 'Automated Script',
                'complexity': 'Medium',
                'automation_rate': '80%'
            }
        
        elif 'clear' in res_lower or 'delete' in res_lower or 'purge' in res_lower:
            return {
                'solution': 'Scheduled Cleanup Script with capacity monitoring',
                'type': 'Automated Script',
                'complexity': 'Low',
                'automation_rate': '90%'
            }
        
        elif 'reset' in res_lower and 'password' in res_lower:
            return {
                'solution': 'Self-Service Password Reset Portal',
                'type': 'Self-Service',
                'complexity': 'Medium',
                'automation_rate': '95%'
            }
        
        elif 'index' in res_lower or 'optimize' in res_lower:
            return {
                'solution': 'Automated Database Maintenance and Index Optimization',
                'type': 'Automated Script',
                'complexity': 'Medium',
                'automation_rate': '70%'
            }
        
        elif 'timeout' in desc_lower and 'database' in desc_lower:
            return {
                'solution': 'Database Connection Pool Tuning and Monitoring',
                'type': 'Configuration Change',
                'complexity': 'Medium',
                'automation_rate': '60%'
            }
        
        elif 'disk' in desc_lower or 'space' in desc_lower:
            return {
                'solution': 'Automated Disk Space Monitoring with Cleanup',
                'type': 'Automated Script',
                'complexity': 'Low',
                'automation_rate': '85%'
            }
        
        elif 'permission' in res_lower or 'grant' in res_lower:
            return {
                'solution': 'Role-Based Access Control Automation',
                'type': 'Automated Workflow',
                'complexity': 'High',
                'automation_rate': '75%'
            }
        
        else:
            return {
                'solution': 'Automated Monitoring with Alert-based Auto-remediation',
                'type': 'Custom Automation',
                'complexity': 'High',
                'automation_rate': '50%'
            }
    
    def _create_solution_summary(self, proposals_df, output_dir):
        """Create executive summary of solution proposals"""
        with open(f'{output_dir}/SOLUTION_SUMMARY.txt', 'w', encoding='utf-8') as f:
            f.write("=" * 100 + "\n")
            f.write("SOLUTION PROPOSAL EXECUTIVE SUMMARY\n")
            f.write("=" * 100 + "\n\n")
            
            f.write(f"Total Solution Proposals: {len(proposals_df):,}\n")
            f.write(f"Total Hours Lost: {proposals_df['Total_Hours_Lost'].sum():,.0f}\n")
            f.write(f"Total Potential Savings: {proposals_df['Potential_Savings_Hours'].sum():,.0f} hours\n")
            f.write(f"Total Estimated Value: ${proposals_df['Potential_Savings_Hours'].sum() * 50:,.0f}\n\n")
            
            f.write("=" * 100 + "\n")
            f.write("TOP 10 RECOMMENDED SOLUTIONS (By Hours Saved)\n")
            f.write("=" * 100 + "\n\n")
            
            for idx, row in proposals_df.head(10).iterrows():
                f.write(f"\n{idx+1}. {row['Issue_Pattern'][:80]}\n")
                f.write(f"   Occurrences: {row['Total_Occurrences']:,} across {row['Applications_Affected']} applications\n")
                f.write(f"   Hours Lost: {row['Total_Hours_Lost']:,} | Potential Savings: {row['Potential_Savings_Hours']:,} hours\n")
                f.write(f"   Top Apps: {row['Top_5_Applications'][:80]}\n")
                f.write(f"   Current: {row['Current_Resolution'][:100]}\n")
                f.write(f"   SOLUTION: {row['Proposed_Solution']}\n")
                f.write(f"   Type: {row['Solution_Type']} | Complexity: {row['Implementation_Complexity']} | Automation: {row['Expected_Automation_Rate']}\n")
                f.write(f"   ROI: {row['Potential_Savings_USD']}\n")
    
    def generate_master_excel(self):
        print("Generating APPLICATION_CLUSTERING_MASTER.xlsx...")
        
        excel_file = 'output_app_clustering/APPLICATION_CLUSTERING_MASTER.xlsx'
        
        with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
            
            # Sheet 1: Overall Summary
            overall = pd.DataFrame({
                'Metric': [
                    'Total Incidents',
                    'Total Issue Clusters',
                    'Applications Analyzed',
                    'Cross-Application Issues (2+ apps)',
                    'High-Volume Issues (10+ incidents)',
                    'Multi-App High-Volume Issues',
                    'Total Hours Spent (All)',
                    'Total Hours on Recurring (10+)',
                    'Potential Savings (70% automation)'
                ],
                'Value': [
                    len(self.df),
                    len(self.cluster_stats),
                    self.df['application'].nunique(),
                    len(self.cluster_stats[self.cluster_stats['Num_Applications'] >= 2]),
                    len(self.cluster_stats[self.cluster_stats['Total_Incidents'] >= 10]),
                    len(self.cluster_stats[(self.cluster_stats['Total_Incidents'] >= 10) & 
                                          (self.cluster_stats['Num_Applications'] >= 2)]),
                    round(self.df['resolution_hours'].sum(), 0),
                    round((self.cluster_stats[self.cluster_stats['Total_Incidents'] >= 10]['Total_Incidents'] *
                          self.cluster_stats[self.cluster_stats['Total_Incidents'] >= 10]['Avg_Hours']).sum(), 0),
                    round((self.cluster_stats[self.cluster_stats['Total_Incidents'] >= 10]['Total_Incidents'] *
                          self.cluster_stats[self.cluster_stats['Total_Incidents'] >= 10]['Avg_Hours']).sum() * 0.7, 0)
                ]
            })
            overall.to_excel(writer, sheet_name='01_Overall_Summary', index=False)
            
            # Sheet 2: Top Issues
            top_issues = self.cluster_stats.head(50)[
                ['Total_Incidents', 'Num_Applications', 'Example_Description', 
                 'Avg_Hours', 'Common_Resolution']
            ]
            top_issues['Total_Hours'] = (top_issues['Total_Incidents'] * top_issues['Avg_Hours']).round(0)
            top_issues.to_excel(writer, sheet_name='02_Top_50_Issues')
            
            # Sheet 3: Cross-Application Issues
            cross_app = self.cluster_stats[self.cluster_stats['Num_Applications'] >= 2][
                ['Total_Incidents', 'Num_Applications', 'Example_Description', 'Avg_Hours']
            ].sort_values('Num_Applications', ascending=False)
            cross_app.to_excel(writer, sheet_name='03_Cross_App_Issues')
            
            # Sheet 4: By Application Summary
            app_summary = self.df.groupby('application').agg({
                'number': 'count',
                'issue_cluster_id': 'nunique',
                'resolution_hours': ['mean', 'sum']
            }).round(2)
            app_summary.columns = ['Total_Incidents', 'Unique_Issues', 'Avg_Hours', 'Total_Hours']
            app_summary = app_summary.sort_values('Total_Incidents', ascending=False)
            app_summary.to_excel(writer, sheet_name='04_By_Application')
        
        print(f"✓ Created master Excel: {excel_file}\n")
    
    def run_full_analysis(self):
        print("\n" + "=" * 100)
        print("STARTING APPLICATION CLUSTERING ANALYSIS".center(100))
        print("=" * 100 + "\n")
        
        self.prepare_data()
        self.create_issue_clusters()
        self.analyze_cross_application_issues()
        self.generate_application_reports()
        self.generate_solution_proposals()
        self.generate_master_excel()
        
        print("\n" + "=" * 100)
        print("APPLICATION CLUSTERING ANALYSIS COMPLETE!".center(100))
        print("=" * 100)
        print("\n📊 ALL OUTPUTS CREATED IN: output_app_clustering/\n")
        print("KEY FILES:")
        print("  ✓ APPLICATION_CLUSTERING_MASTER.xlsx ⭐")
        print("  ✓ solution_proposals/SOLUTION_PROPOSALS.csv ⭐⭐⭐")
        print("  ✓ solution_proposals/SOLUTION_SUMMARY.txt ⭐⭐")
        print("  ✓ cross_application/cross_application_issues.csv\n")
        print("DETAILED FILES:")
        print("  ✓ by_application/APP_*.csv (30 application reports)")
        print("=" * 100 + "\n")
        print("NEXT STEPS:")
        print("1. Review: solution_proposals/SOLUTION_SUMMARY.txt")
        print("2. Prioritize: solution_proposals/SOLUTION_PROPOSALS.csv (sorted by ROI)")
        print("3. Deep Dive: by_application/APP_[YourApp].csv\n")

if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        analyzer = ApplicationClusterAnalyzer(FILE_PATH)
        analyzer.run_full_analysis()
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()
