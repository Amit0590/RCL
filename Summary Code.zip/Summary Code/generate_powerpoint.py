"""
PowerPoint Report Generator
Creates a professional PowerPoint presentation from analysis results

Author: Automated Analysis Tool  
Date: 2025
"""

import pandas as pd
from datetime import datetime
import os

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False
    print("python-pptx not installed. Install with: pip install python-pptx")


class PowerPointGenerator:
    def __init__(self):
        """Initialize PowerPoint generator"""
        if not PPTX_AVAILABLE:
            raise ImportError("python-pptx package is required. Install with: pip install python-pptx")
        
        self.prs = Presentation()
        self.prs.slide_width = Inches(10)
        self.prs.slide_height = Inches(7.5)
        
    def add_title_slide(self, title, subtitle):
        """Add title slide"""
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[0])
        title_shape = slide.shapes.title
        subtitle_shape = slide.placeholders[1]
        
        title_shape.text = title
        subtitle_shape.text = subtitle
        
    def add_content_slide(self, title, content_items):
        """Add content slide with bullet points"""
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[1])
        title_shape = slide.shapes.title
        title_shape.text = title
        
        content_shape = slide.placeholders[1]
        text_frame = content_shape.text_frame
        
        for item in content_items:
            p = text_frame.add_paragraph()
            p.text = item
            p.level = 0
            
    def add_image_slide(self, title, image_path):
        """Add slide with image"""
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[5])
        
        # Add title
        title_shape = slide.shapes.title
        title_shape.text = title
        
        # Add image
        if os.path.exists(image_path):
            left = Inches(1)
            top = Inches(1.5)
            height = Inches(5)
            slide.shapes.add_picture(image_path, left, top, height=height)
        
    def add_table_slide(self, title, dataframe, max_rows=10):
        """Add slide with data table"""
        slide = self.prs.slides.add_slide(self.prs.slide_layouts[5])
        
        # Add title
        title_shape = slide.shapes.title
        title_shape.text = title
        
        # Limit rows
        df = dataframe.head(max_rows)
        
        # Add table
        rows, cols = df.shape
        left = Inches(0.5)
        top = Inches(1.5)
        width = Inches(9)
        height = Inches(0.5)
        
        table = slide.shapes.add_table(rows + 1, cols, left, top, width, height).table
        
        # Header row
        for col_idx, col_name in enumerate(df.columns):
            cell = table.cell(0, col_idx)
            cell.text = str(col_name)
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(68, 114, 196)
            
            # Set text color to white
            paragraph = cell.text_frame.paragraphs[0]
            paragraph.font.color.rgb = RGBColor(255, 255, 255)
            paragraph.font.bold = True
        
        # Data rows
        for row_idx, row in df.iterrows():
            for col_idx, value in enumerate(row):
                cell = table.cell(row_idx + 1, col_idx)
                cell.text = str(value)
                
    def generate_report(self, output_path='output/ServiceNow_Analysis_Report.pptx'):
        """Generate complete PowerPoint report"""
        print("\nGenerating PowerPoint report...")
        
        # Slide 1: Title
        self.add_title_slide(
            "ServiceNow Ticket Analysis",
            f"Comprehensive Analysis Report\n{datetime.now().strftime('%B %Y')}"
        )
        
        # Slide 2: Executive Summary
        try:
            with open('output/reports/summary_statistics.txt', 'r') as f:
                summary = f.read()
            
            summary_points = [line.strip() for line in summary.split('\n') if ':' in line][:8]
            self.add_content_slide("Executive Summary", summary_points)
        except FileNotFoundError:
            print("Warning: summary_statistics.txt not found")
        
        # Slide 3: Top Categories Chart
        if os.path.exists('output/charts/top_10_categories.png'):
            self.add_image_slide("Top 10 Categories by Volume", 
                               'output/charts/top_10_categories.png')
        
        # Slide 4: Category Analysis Table
        try:
            category_df = pd.read_csv('output/reports/category_analysis.csv')
            self.add_table_slide("Category Analysis - Top 10", category_df.head(10))
        except FileNotFoundError:
            print("Warning: category_analysis.csv not found")
        
        # Slide 5: Priority Distribution
        if os.path.exists('output/charts/priority_distribution.png'):
            self.add_image_slide("Priority Distribution", 
                               'output/charts/priority_distribution.png')
        
        # Slide 6: Trends Over Time
        if os.path.exists('output/charts/tickets_over_time.png'):
            self.add_image_slide("Ticket Volume Trends", 
                               'output/charts/tickets_over_time.png')
        
        # Slide 7: Resolution Time
        if os.path.exists('output/charts/resolution_time_by_category.png'):
            self.add_image_slide("Resolution Time by Category", 
                               'output/charts/resolution_time_by_category.png')
        
        # Slide 8: Automation Opportunities
        try:
            automation_df = pd.read_csv('output/text_analysis/automation_candidates.csv')
            self.add_table_slide("Automation Opportunities", automation_df.head(8))
        except FileNotFoundError:
            print("Warning: automation_candidates.csv not found")
        
        # Slide 9: Recommendations - Quick Wins
        try:
            rec_df = pd.read_csv('output/recommendations/actionable_recommendations.csv')
            quick_wins = rec_df[rec_df['timeline'].str.contains('0-30', na=False)]
            
            if len(quick_wins) > 0:
                rec_points = [
                    f"{row['category']}: {row['recommendation']}"
                    for _, row in quick_wins.head(5).iterrows()
                ]
                self.add_content_slide("Recommendations - Quick Wins (0-30 Days)", rec_points)
        except FileNotFoundError:
            print("Warning: recommendations file not found")
        
        # Slide 10: Recommendations - Strategic
        try:
            rec_df = pd.read_csv('output/recommendations/actionable_recommendations.csv')
            strategic = rec_df[rec_df['timeline'].str.contains('3-6', na=False)]
            
            if len(strategic) > 0:
                rec_points = [
                    f"{row['category']}: {row['recommendation']}"
                    for _, row in strategic.head(5).iterrows()
                ]
                self.add_content_slide("Recommendations - Strategic (3-6 Months)", rec_points)
        except FileNotFoundError:
            pass
        
        # Slide 11: Next Steps
        next_steps = [
            "Review and prioritize quick win recommendations",
            "Assign owners to each strategic initiative",
            "Set up monthly tracking for key metrics",
            "Schedule follow-up analysis in 90 days",
            "Implement automation for top recurring issues"
        ]
        self.add_content_slide("Next Steps", next_steps)
        
        # Save presentation
        self.prs.save(output_path)
        print(f"PowerPoint report saved to: {output_path}")
        
        return output_path


def main():
    """Main function to generate PowerPoint report"""
    try:
        generator = PowerPointGenerator()
        output_file = generator.generate_report()
        
        print("\n" + "=" * 60)
        print("PowerPoint Report Generated Successfully!")
        print("=" * 60)
        print(f"\nFile location: {output_file}")
        print("\nThe presentation includes:")
        print("  • Executive summary")
        print("  • Category analysis")
        print("  • Priority distribution")
        print("  • Trend charts")
        print("  • Automation opportunities")
        print("  • Actionable recommendations")
        print("  • Next steps")
        print("=" * 60 + "\n")
        
    except ImportError as e:
        print("\n" + "=" * 60)
        print("ERROR: Missing Required Package")
        print("=" * 60)
        print("\nTo use the PowerPoint generator, install python-pptx:")
        print("\n  pip install python-pptx")
        print("\nThen run this script again.")
        print("=" * 60 + "\n")
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
