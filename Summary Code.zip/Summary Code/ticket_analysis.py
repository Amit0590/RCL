"""
ServiceNow Ticket Analysis Script
Comprehensive analysis of 15K ServiceNow tickets

Author: Automated Analysis Tool
Date: 2025
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Set style for better-looking plots
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

class ServiceNowAnalyzer:
    def __init__(self, file_path):
        """
        Initialize the analyzer with the ticket data file
        
        Parameters:
        file_path (str): Path to the CSV file containing ticket data
        """
        print("Loading ticket data...")
        
        # Try different encodings
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        df_loaded = False
        
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Successfully loaded with {encoding} encoding")
                df_loaded = True
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
            except Exception as e:
                if 'codec' not in str(e).lower():
                    raise
        
        if not df_loaded:
            raise ValueError("Could not read CSV file. Try running: py fix_encoding.py")
        
        self.original_count = len(self.df)
        print(f"Loaded {self.original_count:,} tickets")
        
        # Create output directories
        import os
        os.makedirs('output', exist_ok=True)
        os.makedirs('output/charts', exist_ok=True)
        os.makedirs('output/reports', exist_ok=True)
        
    def clean_data(self):
        """Clean and prepare the data for analysis"""
        print("\nCleaning data...")
        
        # Convert date columns to datetime
        date_columns = ['opened_at', 'resolved_at', 'closed_at']
        for col in date_columns:
            if col in self.df.columns:
                self.df[col] = pd.to_datetime(self.df[col], errors='coerce')
        
        # Calculate resolution and closure times
        if 'opened_at' in self.df.columns and 'resolved_at' in self.df.columns:
            self.df['resolution_time_hours'] = (
                self.df['resolved_at'] - self.df['opened_at']
            ).dt.total_seconds() / 3600
            
        if 'resolved_at' in self.df.columns and 'closed_at' in self.df.columns:
            self.df['closure_time_hours'] = (
                self.df['closed_at'] - self.df['resolved_at']
            ).dt.total_seconds() / 3600
        
        # Extract time components
        if 'opened_at' in self.df.columns:
            self.df['opened_date'] = self.df['opened_at'].dt.date
            self.df['opened_hour'] = self.df['opened_at'].dt.hour
            self.df['opened_day_of_week'] = self.df['opened_at'].dt.day_name()
            self.df['opened_month'] = self.df['opened_at'].dt.month
            self.df['opened_year'] = self.df['opened_at'].dt.year
            self.df['opened_week'] = self.df['opened_at'].dt.isocalendar().week
        
        # Clean category and subcategory
        if 'category' in self.df.columns:
            self.df['category'] = self.df['category'].fillna('Unknown')
            self.df['category'] = self.df['category'].str.strip()
        
        # Handle missing values in critical fields
        self.df['priority'] = self.df['priority'].fillna('Unknown')
        self.df['state'] = self.df['state'].fillna('Unknown')
        self.df['assignment_group'] = self.df['assignment_group'].fillna('Unassigned')
        
        print(f"Data cleaning complete. {len(self.df):,} tickets ready for analysis")
        
    def generate_summary_stats(self):
        """Generate overall summary statistics"""
        print("\nGenerating summary statistics...")
        
        summary = {
            'Total Tickets': len(self.df),
            'Date Range': f"{self.df['opened_at'].min().date()} to {self.df['opened_at'].max().date()}",
            'Unique Categories': self.df['category'].nunique(),
            'Unique Assignment Groups': self.df['assignment_group'].nunique(),
            'Avg Resolution Time (hours)': self.df['resolution_time_hours'].mean(),
            'Median Resolution Time (hours)': self.df['resolution_time_hours'].median(),
            'Tickets Resolved': self.df['resolved_at'].notna().sum(),
            'Resolution Rate (%)': (self.df['resolved_at'].notna().sum() / len(self.df)) * 100
        }
        
        # Save summary to file
        with open('output/reports/summary_statistics.txt', 'w') as f:
            f.write("SERVICENOW TICKET ANALYSIS - SUMMARY STATISTICS\n")
            f.write("=" * 60 + "\n\n")
            for key, value in summary.items():
                if isinstance(value, float):
                    f.write(f"{key}: {value:.2f}\n")
                else:
                    f.write(f"{key}: {value}\n")
        
        print("Summary statistics saved to output/reports/summary_statistics.txt")
        return summary
    
    def analyze_by_category(self):
        """Analyze tickets by category"""
        print("\nAnalyzing by category...")
        
        category_analysis = self.df.groupby('category').agg({
            'number': 'count',
            'resolution_time_hours': ['mean', 'median', 'std'],
            'priority': lambda x: x.mode()[0] if len(x.mode()) > 0 else 'Unknown'
        }).round(2)
        
        category_analysis.columns = ['Ticket_Count', 'Avg_Resolution_Hrs', 
                                     'Median_Resolution_Hrs', 'Std_Resolution_Hrs', 
                                     'Most_Common_Priority']
        
        category_analysis['Percentage'] = (
            category_analysis['Ticket_Count'] / len(self.df) * 100
        ).round(2)
        
        category_analysis = category_analysis.sort_values('Ticket_Count', ascending=False)
        category_analysis.to_csv('output/reports/category_analysis.csv')
        
        print("Category analysis saved to output/reports/category_analysis.csv")
        return category_analysis
    
    def analyze_by_priority(self):
        """Analyze tickets by priority"""
        print("\nAnalyzing by priority...")
        
        priority_analysis = self.df.groupby('priority').agg({
            'number': 'count',
            'resolution_time_hours': ['mean', 'median']
        }).round(2)
        
        priority_analysis.columns = ['Ticket_Count', 'Avg_Resolution_Hrs', 'Median_Resolution_Hrs']
        priority_analysis['Percentage'] = (
            priority_analysis['Ticket_Count'] / len(self.df) * 100
        ).round(2)
        
        priority_analysis = priority_analysis.sort_values('Ticket_Count', ascending=False)
        priority_analysis.to_csv('output/reports/priority_analysis.csv')
        
        print("Priority analysis saved to output/reports/priority_analysis.csv")
        return priority_analysis
    
    def analyze_by_assignment_group(self):
        """Analyze tickets by assignment group"""
        print("\nAnalyzing by assignment group...")
        
        group_analysis = self.df.groupby('assignment_group').agg({
            'number': 'count',
            'resolution_time_hours': ['mean', 'median']
        }).round(2)
        
        group_analysis.columns = ['Ticket_Count', 'Avg_Resolution_Hrs', 'Median_Resolution_Hrs']
        group_analysis['Percentage'] = (
            group_analysis['Ticket_Count'] / len(self.df) * 100
        ).round(2)
        
        group_analysis = group_analysis.sort_values('Ticket_Count', ascending=False)
        
        # Get top 20 groups
        top_20_groups = group_analysis.head(20)
        top_20_groups.to_csv('output/reports/top_20_assignment_groups.csv')
        
        print("Assignment group analysis saved to output/reports/top_20_assignment_groups.csv")
        return group_analysis
    
    def analyze_trends(self):
        """Analyze trends over time"""
        print("\nAnalyzing trends over time...")
        
        # Daily trend
        daily_trend = self.df.groupby('opened_date').size().reset_index()
        daily_trend.columns = ['Date', 'Ticket_Count']
        daily_trend.to_csv('output/reports/daily_trend.csv', index=False)
        
        # Weekly trend
        weekly_trend = self.df.groupby(['opened_year', 'opened_week']).size().reset_index()
        weekly_trend.columns = ['Year', 'Week', 'Ticket_Count']
        weekly_trend.to_csv('output/reports/weekly_trend.csv', index=False)
        
        # Day of week analysis
        dow_analysis = self.df.groupby('opened_day_of_week').agg({
            'number': 'count',
            'resolution_time_hours': 'mean'
        }).round(2)
        dow_analysis.columns = ['Ticket_Count', 'Avg_Resolution_Hrs']
        
        # Reorder days
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        dow_analysis = dow_analysis.reindex(day_order)
        dow_analysis.to_csv('output/reports/day_of_week_analysis.csv')
        
        print("Trend analysis saved to output/reports/")
        return daily_trend, dow_analysis
    
    def create_visualizations(self):
        """Create comprehensive visualizations"""
        print("\nCreating visualizations...")
        
        # 1. Top 10 Categories by Volume
        plt.figure(figsize=(12, 6))
        top_categories = self.df['category'].value_counts().head(10)
        top_categories.plot(kind='barh', color='steelblue')
        plt.title('Top 10 Categories by Ticket Volume', fontsize=16, fontweight='bold')
        plt.xlabel('Number of Tickets', fontsize=12)
        plt.ylabel('Category', fontsize=12)
        plt.tight_layout()
        plt.savefig('output/charts/top_10_categories.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. Priority Distribution
        plt.figure(figsize=(10, 6))
        priority_counts = self.df['priority'].value_counts()
        plt.pie(priority_counts.values, labels=priority_counts.index, autopct='%1.1f%%', startangle=90)
        plt.title('Ticket Distribution by Priority', fontsize=16, fontweight='bold')
        plt.axis('equal')
        plt.tight_layout()
        plt.savefig('output/charts/priority_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. Resolution Time by Category (Top 10)
        plt.figure(figsize=(12, 6))
        top_10_cats = self.df['category'].value_counts().head(10).index
        df_top_cats = self.df[self.df['category'].isin(top_10_cats)]
        
        category_res_time = df_top_cats.groupby('category')['resolution_time_hours'].median().sort_values()
        category_res_time.plot(kind='barh', color='coral')
        plt.title('Median Resolution Time by Category (Top 10)', fontsize=16, fontweight='bold')
        plt.xlabel('Resolution Time (Hours)', fontsize=12)
        plt.ylabel('Category', fontsize=12)
        plt.tight_layout()
        plt.savefig('output/charts/resolution_time_by_category.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 4. Tickets Over Time
        plt.figure(figsize=(14, 6))
        daily_counts = self.df.groupby('opened_date').size()
        plt.plot(daily_counts.index, daily_counts.values, linewidth=2, color='darkblue')
        plt.title('Ticket Volume Over Time', fontsize=16, fontweight='bold')
        plt.xlabel('Date', fontsize=12)
        plt.ylabel('Number of Tickets', fontsize=12)
        plt.xticks(rotation=45)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig('output/charts/tickets_over_time.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 5. Day of Week Analysis
        plt.figure(figsize=(10, 6))
        day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        dow_counts = self.df['opened_day_of_week'].value_counts().reindex(day_order)
        dow_counts.plot(kind='bar', color='teal')
        plt.title('Ticket Volume by Day of Week', fontsize=16, fontweight='bold')
        plt.xlabel('Day of Week', fontsize=12)
        plt.ylabel('Number of Tickets', fontsize=12)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('output/charts/tickets_by_day_of_week.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 6. Hour of Day Heatmap
        plt.figure(figsize=(12, 6))
        hourly_counts = self.df.groupby(['opened_day_of_week', 'opened_hour']).size().unstack(fill_value=0)
        hourly_counts = hourly_counts.reindex(day_order)
        sns.heatmap(hourly_counts, cmap='YlOrRd', annot=False, fmt='d', cbar_kws={'label': 'Ticket Count'})
        plt.title('Ticket Volume Heatmap (Day of Week vs Hour of Day)', fontsize=16, fontweight='bold')
        plt.xlabel('Hour of Day', fontsize=12)
        plt.ylabel('Day of Week', fontsize=12)
        plt.tight_layout()
        plt.savefig('output/charts/hourly_heatmap.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 7. Top 15 Assignment Groups
        plt.figure(figsize=(12, 6))
        top_groups = self.df['assignment_group'].value_counts().head(15)
        top_groups.plot(kind='barh', color='mediumpurple')
        plt.title('Top 15 Assignment Groups by Ticket Volume', fontsize=16, fontweight='bold')
        plt.xlabel('Number of Tickets', fontsize=12)
        plt.ylabel('Assignment Group', fontsize=12)
        plt.tight_layout()
        plt.savefig('output/charts/top_15_assignment_groups.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 8. Resolution Time Distribution
        plt.figure(figsize=(10, 6))
        # Filter outliers for better visualization
        res_times = self.df['resolution_time_hours'].dropna()
        res_times_filtered = res_times[res_times <= res_times.quantile(0.95)]
        
        plt.hist(res_times_filtered, bins=50, color='skyblue', edgecolor='black', alpha=0.7)
        plt.title('Resolution Time Distribution (95th Percentile)', fontsize=16, fontweight='bold')
        plt.xlabel('Resolution Time (Hours)', fontsize=12)
        plt.ylabel('Frequency', fontsize=12)
        plt.axvline(res_times.median(), color='red', linestyle='--', linewidth=2, label=f'Median: {res_times.median():.1f} hrs')
        plt.axvline(res_times.mean(), color='green', linestyle='--', linewidth=2, label=f'Mean: {res_times.mean():.1f} hrs')
        plt.legend()
        plt.tight_layout()
        plt.savefig('output/charts/resolution_time_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("All visualizations saved to output/charts/")
    
    def identify_recurring_issues(self, top_n=20):
        """Identify recurring issues from short descriptions"""
        print("\nIdentifying recurring issues...")
        
        # Count most common short descriptions
        recurring = self.df['short_description'].value_counts().head(top_n)
        
        recurring_df = pd.DataFrame({
            'Short_Description': recurring.index,
            'Occurrences': recurring.values,
            'Percentage': (recurring.values / len(self.df) * 100).round(2)
        })
        
        recurring_df.to_csv('output/reports/recurring_issues.csv', index=False)
        print(f"Top {top_n} recurring issues saved to output/reports/recurring_issues.csv")
        
        return recurring_df
    
    def generate_executive_summary(self):
        """Generate executive summary report"""
        print("\nGenerating executive summary...")
        
        summary_stats = self.generate_summary_stats()
        category_analysis = self.analyze_by_category()
        priority_analysis = self.analyze_by_priority()
        
        with open('output/reports/executive_summary.txt', 'w') as f:
            f.write("=" * 80 + "\n")
            f.write("SERVICENOW TICKET ANALYSIS - EXECUTIVE SUMMARY\n")
            f.write("=" * 80 + "\n\n")
            
            f.write("OVERVIEW\n")
            f.write("-" * 80 + "\n")
            f.write(f"Total Tickets Analyzed: {len(self.df):,}\n")
            f.write(f"Date Range: {self.df['opened_at'].min().date()} to {self.df['opened_at'].max().date()}\n")
            f.write(f"Resolution Rate: {(self.df['resolved_at'].notna().sum() / len(self.df)) * 100:.2f}%\n")
            f.write(f"Average Resolution Time: {self.df['resolution_time_hours'].mean():.2f} hours\n")
            f.write(f"Median Resolution Time: {self.df['resolution_time_hours'].median():.2f} hours\n\n")
            
            f.write("TOP 5 CATEGORIES BY VOLUME\n")
            f.write("-" * 80 + "\n")
            top_5_cats = category_analysis.head(5)
            for idx, (cat, row) in enumerate(top_5_cats.iterrows(), 1):
                f.write(f"{idx}. {cat}\n")
                f.write(f"   Tickets: {int(row['Ticket_Count']):,} ({row['Percentage']:.2f}%)\n")
                f.write(f"   Avg Resolution: {row['Avg_Resolution_Hrs']:.2f} hours\n\n")
            
            f.write("PRIORITY BREAKDOWN\n")
            f.write("-" * 80 + "\n")
            for priority, row in priority_analysis.iterrows():
                f.write(f"{priority}: {int(row['Ticket_Count']):,} tickets ({row['Percentage']:.2f}%)\n")
            
            f.write("\n" + "=" * 80 + "\n")
        
        print("Executive summary saved to output/reports/executive_summary.txt")
    
    def run_full_analysis(self):
        """Run complete analysis pipeline"""
        print("\n" + "=" * 60)
        print("STARTING FULL SERVICENOW TICKET ANALYSIS")
        print("=" * 60)
        
        # Step 1: Clean data
        self.clean_data()
        
        # Step 2: Generate all analyses
        self.generate_summary_stats()
        self.analyze_by_category()
        self.analyze_by_priority()
        self.analyze_by_assignment_group()
        self.analyze_trends()
        self.identify_recurring_issues()
        
        # Step 3: Create visualizations
        self.create_visualizations()
        
        # Step 4: Generate executive summary
        self.generate_executive_summary()
        
        print("\n" + "=" * 60)
        print("ANALYSIS COMPLETE!")
        print("=" * 60)
        print("\nAll outputs saved to the 'output' directory:")
        print("  - output/reports/     : CSV and text reports")
        print("  - output/charts/      : PNG visualizations")
        print("\nKey files to review:")
        print("  - output/reports/executive_summary.txt")
        print("  - output/reports/category_analysis.csv")
        print("  - output/charts/top_10_categories.png")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    # USAGE: Replace 'your_ticket_data.csv' with your actual file path
    FILE_PATH = 'servicenow_tickets.csv'  # Change this to your file path
    
    try:
        # Initialize analyzer
        analyzer = ServiceNowAnalyzer(FILE_PATH)
        
        # Run full analysis
        analyzer.run_full_analysis()
        
    except FileNotFoundError:
        print(f"\nERROR: File '{FILE_PATH}' not found!")
        print("Please update the FILE_PATH variable with the correct path to your CSV file.")
    except Exception as e:
        print(f"\nERROR: An error occurred during analysis:")
        print(f"{str(e)}")
        import traceback
        traceback.print_exc()
