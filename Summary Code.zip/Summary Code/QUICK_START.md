# QUICK REFERENCE GUIDE
# ServiceNow Ticket Analysis Suite

## 🚀 GETTING STARTED (5 MINUTES)

### Step 1: Install Python Packages
```bash
pip install -r requirements.txt
```

### Step 2: Prepare Your Data
- Save your ServiceNow export as `servicenow_tickets.csv`
- Place it in the same folder as the Python scripts

### Step 3: Run Analysis
```bash
python run_all_analyses.py
```

That's it! Results will be in the `output/` folder.

---

## 📁 WHAT YOU GET

### Critical Files to Review First:
1. `output/reports/executive_summary.txt` - Start here!
2. `output/recommendations/recommendations_report.txt` - Action items
3. `output/charts/` - All visualizations

### For Presentations:
- All PNG charts are 300 DPI (high quality)
- Ready to insert into PowerPoint/Google Slides
- Optional: Run `python generate_powerpoint.py` for auto-generated deck

### For Deep Analysis:
- All CSV files can be opened in Excel
- Import into Power BI/Tableau for custom dashboards
- Use for tracking metrics over time

---

## 🎯 INDIVIDUAL SCRIPTS

### Run Just One Analysis:

**Statistical Analysis:**
```bash
python ticket_analysis.py
```
Outputs: Summary stats, category analysis, trends, charts

**Text Analysis:**
```bash
python text_analysis.py
```
Outputs: Error patterns, automation candidates, keywords

**Recommendations:**
```bash
python recommendations_generator.py
```
Outputs: Prioritized action items by timeline

**PowerPoint Report:**
```bash
python generate_powerpoint.py
```
Outputs: Professional presentation (requires: pip install python-pptx)

---

## 🔧 COMMON CUSTOMIZATIONS

### Change Input File Location:
Edit these files and update the `FILE_PATH` variable:
- `ticket_analysis.py`
- `text_analysis.py`
- `recommendations_generator.py`
- `run_all_analyses.py`

Example:
```python
# Change this:
FILE_PATH = 'servicenow_tickets.csv'

# To this:
FILE_PATH = 'C:/Users/YourName/Downloads/my_tickets.csv'
```

### Adjust Automation Threshold:
Edit `text_analysis.py`, line ~270:
```python
# Current: flags issues occurring 10+ times
frequent_issues = desc_counts[desc_counts >= 10]

# Change to 5+ times:
frequent_issues = desc_counts[desc_counts >= 5]
```

### Customize SLA Targets:
Edit `recommendations_generator.py`, line ~70:
```python
sla_targets = {
    '1 - Critical': 4,    # Your SLA hours
    '2 - High': 8,
    '3 - Moderate': 24,
    '4 - Low': 72,
    '5 - Minimal': 120
}
```

---

## 📊 KEY METRICS EXPLAINED

### Resolution Time
- **Median** = Middle value (typical case)
- **Mean** = Average (skewed by outliers)
- **Use median** for realistic expectations

### Percentages in Reports
- Category % = Portion of total tickets
- Priority % = Distribution across priorities
- Resolution rate % = Tickets resolved / total tickets

### Trends
- **Daily trend** = Tickets per day
- **Weekly trend** = Tickets per week
- **Heatmap** = Tickets by day of week + hour

---

## ⚡ QUICK WINS CHECKLIST

After running analysis, do this:

- [ ] Read executive summary (5 min)
- [ ] Check top 3 recommendations (10 min)
- [ ] Review automation candidates (15 min)
- [ ] Identify overloaded teams (10 min)
- [ ] Note recurring issues (10 min)
- [ ] Prepare stakeholder presentation (30 min)

**Total: 1-2 hours for actionable insights**

---

## 🐛 TROUBLESHOOTING

### "File not found"
✅ Check file is in same folder
✅ Check filename matches exactly
✅ Update FILE_PATH if in different location

### "Module not found"
✅ Run: `pip install -r requirements.txt`

### "No module named 'pandas'"
✅ Run: `pip install pandas matplotlib seaborn`

### Charts not showing
✅ Check `output/charts/` folder was created
✅ Verify matplotlib installed: `pip list | grep matplotlib`

### Out of memory
✅ Close other programs
✅ Process smaller date range
✅ Use machine with more RAM

---

## 📧 OUTPUT FILES GUIDE

### Reports Folder (`output/reports/`)
| File | What It Shows | When to Use |
|------|---------------|-------------|
| executive_summary.txt | High-level overview | Share with leadership |
| category_analysis.csv | Breakdown by category | Identify problem areas |
| priority_analysis.csv | Breakdown by priority | Check SLA compliance |
| top_20_assignment_groups.csv | Team workload | Balance workload |
| recurring_issues.csv | Repeated problems | Find root causes |

### Charts Folder (`output/charts/`)
| File | What It Shows | When to Use |
|------|---------------|-------------|
| top_10_categories.png | Most common issues | Presentations |
| priority_distribution.png | Priority breakdown | Leadership updates |
| tickets_over_time.png | Volume trends | Capacity planning |
| hourly_heatmap.png | Peak times | Staffing decisions |
| resolution_time_distribution.png | Time patterns | Process improvement |

### Text Analysis (`output/text_analysis/`)
| File | What It Shows | When to Use |
|------|---------------|-------------|
| automation_candidates.csv | What to automate | Development team |
| error_patterns.csv | Common errors | Root cause analysis |
| quick_resolution_descriptions.csv | Fast fixes | Training material |
| category_keywords.txt | Common terms | Categorization review |

### Recommendations (`output/recommendations/`)
| File | What It Shows | When to Use |
|------|---------------|-------------|
| actionable_recommendations.csv | All recommendations | Planning |
| recommendations_report.txt | Detailed action plan | Implementation |

---

## 💡 PRO TIPS

1. **Run Weekly**: Track improvements over time
2. **Export to Excel**: Create pivot tables from CSVs
3. **Archive Results**: Save each month's output folder
4. **Compare Trends**: Look at month-over-month changes
5. **Share Widely**: Different stakeholders need different outputs

### Who Gets What:
- **Executives** → executive_summary.txt + top charts
- **Managers** → category_analysis.csv + recommendations
- **Tech Teams** → automation_candidates.csv + error_patterns.csv
- **All Stakeholders** → PowerPoint presentation

---

## 🔄 REGULAR ANALYSIS WORKFLOW

### Weekly (15 minutes)
1. Export last week's tickets
2. Run `python run_all_analyses.py`
3. Check for new patterns
4. Update tracking dashboard

### Monthly (1 hour)
1. Export full month's tickets
2. Run full analysis
3. Compare to previous month
4. Update recommendations
5. Present to stakeholders

### Quarterly (2 hours)
1. Analyze 3 months together
2. Assess trend changes
3. Measure impact of initiatives
4. Adjust strategies

---

## 📞 NEED HELP?

### Check These First:
1. Error messages (they usually tell you what's wrong)
2. README.md (comprehensive documentation)
3. Verify all files are in correct location
4. Ensure CSV has required columns

### Common Issues:
- Missing columns → Check CSV export settings
- Wrong date format → Scripts auto-detect most formats
- No output → Check console for error messages
- Slow performance → Normal for 15K+ tickets

---

## ✅ PRE-FLIGHT CHECKLIST

Before running analysis:

- [ ] Python 3.7+ installed
- [ ] All packages installed (`pip install -r requirements.txt`)
- [ ] CSV file ready and accessible
- [ ] FILE_PATH updated if needed
- [ ] Previous output folder backed up (if exists)
- [ ] Enough disk space (~100MB for outputs)

After running analysis:

- [ ] Check output folder created
- [ ] Verify reports generated
- [ ] Review charts visually
- [ ] Read executive summary
- [ ] Check for error messages

---

## 🎓 LEARNING PATH

### Beginner (Just need insights)
1. Run `python run_all_analyses.py`
2. Read `executive_summary.txt`
3. Look at charts
4. Done!

### Intermediate (Want to customize)
1. Run full analysis
2. Adjust thresholds in scripts
3. Add custom categories
4. Generate PowerPoint
5. Share with team

### Advanced (Deep customization)
1. Modify scripts for specific needs
2. Add new metrics
3. Create custom visualizations
4. Integrate with other tools
5. Automate regular runs

---

**Version**: 1.0
**Last Updated**: 2025

For detailed documentation, see README.md
