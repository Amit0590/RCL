"""
Master Analysis Script
Runs all ServiceNow ticket analyses in sequence

Author: Automated Analysis Tool
Date: 2025
"""

import sys
import os
from datetime import datetime

def print_header(text):
    """Print formatted header"""
    print("\n" + "=" * 80)
    print(text.center(80))
    print("=" * 80 + "\n")

def run_all_analyses(file_path):
    """
    Run all analysis scripts in sequence
    
    Parameters:
    file_path (str): Path to your ServiceNow CSV file
    """
    
    print_header("SERVICENOW TICKET COMPREHENSIVE ANALYSIS SUITE")
    print(f"Start Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Input File: {file_path}")
    print(f"Python Version: {sys.version.split()[0]}")
    
    # Check if file exists
    if not os.path.exists(file_path):
        print(f"\n❌ ERROR: File '{file_path}' not found!")
        print("Please update the FILE_PATH in this script to point to your CSV file.")
        return
    
    analyses_completed = []
    analyses_failed = []
    
    # Analysis 1: Main Statistical Analysis
    print_header("PHASE 1: STATISTICAL ANALYSIS")
    try:
        from ticket_analysis import ServiceNowAnalyzer
        analyzer = ServiceNowAnalyzer(file_path)
        analyzer.run_full_analysis()
        analyses_completed.append("Statistical Analysis")
        print("✅ Phase 1 completed successfully!")
    except Exception as e:
        analyses_failed.append(("Statistical Analysis", str(e)))
        print(f"❌ Phase 1 failed: {str(e)}")
    
    # Analysis 2: Text Analysis
    print_header("PHASE 2: ADVANCED TEXT ANALYSIS")
    try:
        from text_analysis import TextAnalyzer
        text_analyzer = TextAnalyzer(file_path)
        text_analyzer.run_full_text_analysis()
        analyses_completed.append("Text Analysis")
        print("✅ Phase 2 completed successfully!")
    except Exception as e:
        analyses_failed.append(("Text Analysis", str(e)))
        print(f"❌ Phase 2 failed: {str(e)}")
    
    # Analysis 3: Recommendations
    print_header("PHASE 3: GENERATING RECOMMENDATIONS")
    try:
        from recommendations_generator import RecommendationsGenerator
        rec_generator = RecommendationsGenerator(file_path)
        rec_generator.run_full_recommendations()
        analyses_completed.append("Recommendations")
        print("✅ Phase 3 completed successfully!")
    except Exception as e:
        analyses_failed.append(("Recommendations", str(e)))
        print(f"❌ Phase 3 failed: {str(e)}")
    
    # Final Summary
    print_header("ANALYSIS COMPLETE - SUMMARY")
    print(f"End Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    print(f"✅ Completed Analyses: {len(analyses_completed)}")
    for analysis in analyses_completed:
        print(f"   • {analysis}")
    
    if analyses_failed:
        print(f"\n❌ Failed Analyses: {len(analyses_failed)}")
        for analysis, error in analyses_failed:
            print(f"   • {analysis}: {error}")
    
    print("\n" + "-" * 80)
    print("OUTPUT DIRECTORY STRUCTURE:")
    print("-" * 80)
    print("output/")
    print("├── reports/")
    print("│   ├── executive_summary.txt")
    print("│   ├── summary_statistics.txt")
    print("│   ├── category_analysis.csv")
    print("│   ├── priority_analysis.csv")
    print("│   ├── top_20_assignment_groups.csv")
    print("│   ├── daily_trend.csv")
    print("│   ├── weekly_trend.csv")
    print("│   ├── day_of_week_analysis.csv")
    print("│   └── recurring_issues.csv")
    print("├── charts/")
    print("│   ├── top_10_categories.png")
    print("│   ├── priority_distribution.png")
    print("│   ├── resolution_time_by_category.png")
    print("│   ├── tickets_over_time.png")
    print("│   ├── tickets_by_day_of_week.png")
    print("│   ├── hourly_heatmap.png")
    print("│   ├── top_15_assignment_groups.png")
    print("│   └── resolution_time_distribution.png")
    print("├── text_analysis/")
    print("│   ├── error_patterns.csv")
    print("│   ├── top_systems.csv")
    print("│   ├── description_length_analysis.csv")
    print("│   ├── quick_resolution_categories.csv")
    print("│   ├── quick_resolution_descriptions.csv")
    print("│   ├── long_resolution_categories.csv")
    print("│   ├── long_resolution_descriptions.csv")
    print("│   ├── category_keywords.txt")
    print("│   └── automation_candidates.csv")
    print("└── recommendations/")
    print("    ├── actionable_recommendations.csv")
    print("    └── recommendations_report.txt")
    
    print("\n" + "-" * 80)
    print("NEXT STEPS:")
    print("-" * 80)
    print("1. Review executive_summary.txt for high-level insights")
    print("2. Check recommendations_report.txt for prioritized action items")
    print("3. Examine charts/ folder for visual presentations")
    print("4. Use CSV files for detailed analysis in Excel/PowerBI")
    print("5. Share automation_candidates.csv with development team")
    print("-" * 80)
    
    print("\n🎉 Analysis pipeline complete!")
    
    if len(analyses_failed) == 0:
        print("✅ All analyses completed successfully!")
    else:
        print(f"⚠️  {len(analyses_failed)} analysis(es) failed. Check error messages above.")


if __name__ == "__main__":
    # ========================================
    # CONFIGURATION
    # ========================================
    # Update this path to point to your CSV file
    FILE_PATH = 'servicenow_tickets.csv'
    
    # Run all analyses
    run_all_analyses(FILE_PATH)
