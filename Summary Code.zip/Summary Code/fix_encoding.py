"""
CSV Encoding Fixer
Fixes encoding issues in ServiceNow CSV exports

Author: Automated Analysis Tool
Date: 2025
"""

import pandas as pd
import chardet

def detect_encoding(file_path):
    """Detect the encoding of a file"""
    print(f"Detecting encoding for: {file_path}")
    
    with open(file_path, 'rb') as f:
        raw_data = f.read(100000)  # Read first 100KB
        result = chardet.detect(raw_data)
        
    print(f"Detected encoding: {result['encoding']} (confidence: {result['confidence']*100:.1f}%)")
    return result['encoding']

def fix_csv_encoding(input_file, output_file=None):
    """
    Fix CSV encoding issues
    
    Parameters:
    input_file (str): Path to the problematic CSV file
    output_file (str): Path for the fixed CSV file (default: adds '_fixed' to filename)
    """
    
    if output_file is None:
        # Create output filename
        if input_file.endswith('.csv'):
            output_file = input_file.replace('.csv', '_fixed.csv')
        else:
            output_file = input_file + '_fixed.csv'
    
    print("\n" + "="*60)
    print("CSV ENCODING FIXER")
    print("="*60)
    
    # Try different encodings
    encodings_to_try = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252', 'utf-16']
    
    # First, try to detect encoding
    try:
        detected_encoding = detect_encoding(input_file)
        if detected_encoding and detected_encoding not in encodings_to_try:
            encodings_to_try.insert(0, detected_encoding)
    except Exception as e:
        print(f"Auto-detection failed: {e}")
    
    df = None
    successful_encoding = None
    
    print("\nTrying different encodings...")
    for encoding in encodings_to_try:
        try:
            print(f"  Trying {encoding}...", end=" ")
            df = pd.read_csv(input_file, encoding=encoding, low_memory=False)
            successful_encoding = encoding
            print(f"✓ SUCCESS!")
            break
        except Exception as e:
            print(f"✗ Failed")
    
    if df is None:
        print("\n❌ ERROR: Could not read the file with any common encoding.")
        print("\nTry this:")
        print("1. Open the CSV in Excel")
        print("2. File → Save As")
        print("3. Choose 'CSV UTF-8 (Comma delimited) (*.csv)'")
        print("4. Save and try again")
        return None
    
    print(f"\n✓ Successfully read file with {successful_encoding} encoding")
    print(f"  Rows: {len(df):,}")
    print(f"  Columns: {len(df.columns)}")
    
    # Save as UTF-8
    print(f"\nSaving fixed file as UTF-8: {output_file}")
    df.to_csv(output_file, index=False, encoding='utf-8')
    
    print("\n" + "="*60)
    print("SUCCESS! Fixed file created:")
    print(f"  {output_file}")
    print("="*60)
    print("\nNow run the analysis with this file:")
    print("  1. Update FILE_PATH in the scripts to point to the fixed file")
    print("     OR")
    print("  2. Rename the fixed file to 'servicenow_tickets.csv'")
    print("="*60 + "\n")
    
    return output_file

if __name__ == "__main__":
    # Configure your input file here
    INPUT_FILE = 'servicenow_tickets.csv'
    
    try:
        # Install chardet if needed
        try:
            import chardet
        except ImportError:
            print("Installing chardet package for encoding detection...")
            import subprocess
            import sys
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'chardet'])
            import chardet
            print("✓ chardet installed successfully\n")
        
        fix_csv_encoding(INPUT_FILE)
        
    except FileNotFoundError:
        print(f"\n❌ ERROR: File '{INPUT_FILE}' not found!")
        print("Make sure the CSV file is in the same folder as this script.")
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
