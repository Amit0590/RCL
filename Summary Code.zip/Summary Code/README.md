# ServiceNow Ticket Analysis Suite

A comprehensive Python-based analysis toolkit for analyzing 15,000+ ServiceNow tickets. This suite provides statistical analysis, text mining, trend identification, and actionable recommendations.

## 📋 Features

### 1. **Statistical Analysis** (`ticket_analysis.py`)
- Summary statistics and KPIs
- Category and subcategory analysis
- Priority distribution
- Assignment group workload analysis
- Time-based trends (daily, weekly, monthly)
- Resolution time analysis
- Comprehensive visualizations

### 2. **Advanced Text Analysis** (`text_analysis.py`)
- Error pattern extraction
- System/application name identification
- Description length impact analysis
- Quick vs. long resolution pattern identification
- Category-specific keyword extraction
- Automation candidate identification

### 3. **Recommendations Generator** (`recommendations_generator.py`)
- Workload distribution analysis
- Automation opportunity identification
- SLA risk assessment
- Category performance evaluation
- Knowledge gap identification
- Temporal pattern analysis
- Root cause recommendations

## 🚀 Quick Start

### Prerequisites
- Python 3.7 or higher
- pip (Python package manager)

### Installation

1. **Download all files to a folder on your computer**

2. **Install required Python packages**
   ```bash
   pip install -r requirements.txt
   ```

3. **Prepare your data**
   - Export your ServiceNow tickets to CSV format
   - Save the CSV file in the same folder as the scripts
   - Rename it to `servicenow_tickets.csv` (or update the scripts with your filename)

### Usage

#### Option 1: Run All Analyses at Once (Recommended)
```bash
python run_all_analyses.py
```
This will run all three analysis phases sequentially and generate all reports and visualizations.

#### Option 2: Run Individual Analyses

**Statistical Analysis Only:**
```bash
python ticket_analysis.py
```

**Text Analysis Only:**
```bash
python text_analysis.py
```

**Recommendations Only:**
```bash
python recommendations_generator.py
```

### Customization

If your CSV file has a different name or location, edit the `FILE_PATH` variable at the bottom of each script:

```python
# Change this line in each script
FILE_PATH = 'servicenow_tickets.csv'

# To this (example)
FILE_PATH = 'C:/Users/YourName/Documents/my_tickets.csv'
```

## 📊 Output Structure

After running the analyses, you'll find all outputs in the `output/` directory:

```
output/
├── reports/                    # CSV and text reports
│   ├── executive_summary.txt
│   ├── summary_statistics.txt
│   ├── category_analysis.csv
│   ├── priority_analysis.csv
│   ├── top_20_assignment_groups.csv
│   ├── daily_trend.csv
│   ├── weekly_trend.csv
│   ├── day_of_week_analysis.csv
│   └── recurring_issues.csv
│
├── charts/                     # PNG visualizations
│   ├── top_10_categories.png
│   ├── priority_distribution.png
│   ├── resolution_time_by_category.png
│   ├── tickets_over_time.png
│   ├── tickets_by_day_of_week.png
│   ├── hourly_heatmap.png
│   ├── top_15_assignment_groups.png
│   └── resolution_time_distribution.png
│
├── text_analysis/              # Text mining results
│   ├── error_patterns.csv
│   ├── top_systems.csv
│   ├── description_length_analysis.csv
│   ├── quick_resolution_categories.csv
│   ├── quick_resolution_descriptions.csv
│   ├── long_resolution_categories.csv
│   ├── long_resolution_descriptions.csv
│   ├── category_keywords.txt
│   └── automation_candidates.csv
│
└── recommendations/            # Actionable recommendations
    ├── actionable_recommendations.csv
    └── recommendations_report.txt
```

## 📈 Key Insights You'll Get

### Summary Statistics
- Total ticket count and date range
- Resolution rates and average times
- Priority distribution
- Category breakdown

### Trends & Patterns
- Daily/weekly ticket volume trends
- Peak hours and days
- Seasonal patterns
- Day-of-week analysis with heatmaps

### Performance Metrics
- Resolution time by category
- Resolution time by priority
- Assignment group performance
- SLA compliance analysis

### Actionable Recommendations
Organized by timeline:
- **Immediate (0-7 days)**: Critical SLA risks
- **Quick Wins (0-30 days)**: Automation opportunities, workload redistribution
- **Process Improvements (1-3 months)**: Training needs, process optimization
- **Strategic Initiatives (3-6 months)**: Root cause elimination, system improvements

## 🎯 Best Practices

1. **Start with the Executive Summary**
   - Read `output/reports/executive_summary.txt` first
   - This gives you the big picture

2. **Review Recommendations**
   - Check `output/recommendations/recommendations_report.txt`
   - Prioritize by timeline and expected impact

3. **Use Visualizations for Presentations**
   - Charts in `output/charts/` are ready for PowerPoint
   - High resolution (300 DPI) for professional presentations

4. **Deep Dive with CSV Files**
   - Import CSV files into Excel or Power BI
   - Create custom pivot tables and dashboards
   - Filter and sort based on your specific needs

5. **Automation Candidates**
   - Review `output/text_analysis/automation_candidates.csv`
   - Share with development/automation team
   - Prioritize by frequency and resolution time

## 🔧 Troubleshooting

### "File not found" Error
- Make sure your CSV file is in the same folder as the scripts
- Check that the filename matches exactly (case-sensitive on some systems)
- Update the `FILE_PATH` variable if using a different location

### "Module not found" Error
```bash
pip install -r requirements.txt
```

### Memory Issues with Large Files
If you have more than 50,000 tickets:
- Process in batches
- Increase Python memory limit
- Use a machine with more RAM

### Date Format Issues
The scripts expect dates in format: `M/D/YYYY H:MM` or `YYYY-MM-DD HH:MM:SS`
If your dates are different, the script will try to parse them automatically.

## 📝 Required CSV Columns

Your CSV file should include these columns (case-sensitive):
- `number` - Ticket number
- `opened_at` - When ticket was opened
- `resolved_at` - When ticket was resolved
- `closed_at` - When ticket was closed
- `short_description` - Brief description
- `description` - Detailed description
- `category` - Ticket category
- `priority` - Priority level
- `state` - Current state
- `assignment_group` - Group assigned to

**Note:** The scripts are designed to handle missing values gracefully. If some columns are missing or have null values, the analysis will still run but some specific analyses may be skipped.

## 💡 Tips for Better Analysis

1. **Clean Your Data First**
   - Remove test tickets
   - Ensure consistent category naming
   - Validate date formats

2. **Customize SLA Targets**
   - Edit `recommendations_generator.py`
   - Update the `sla_targets` dictionary to match your organization's SLAs

3. **Adjust Thresholds**
   - Modify automation candidate thresholds in `text_analysis.py`
   - Change what counts as "quick resolution" or "long resolution"

4. **Add Custom Categories**
   - Scripts work with any category structure
   - No code changes needed for different category names

## 📧 Output Format

### CSV Files
- Ready to import into Excel, PowerBI, Tableau
- Use for detailed analysis and custom visualizations
- Can be used as input for other tools

### Text Reports
- Executive-friendly summaries
- Easy to copy into emails or documents
- Formatted for readability

### PNG Charts
- High-resolution (300 DPI)
- Ready for presentations
- Professional color schemes

## 🔄 Running Regular Analysis

To analyze tickets on a regular basis:

1. **Weekly Analysis**
   - Export new tickets from ServiceNow
   - Run `python run_all_analyses.py`
   - Compare trends week-over-week

2. **Monthly Reports**
   - Archive previous month's output folder
   - Run fresh analysis on new data
   - Track improvements over time

3. **Quarterly Reviews**
   - Combine 3 months of data
   - Look for long-term trends
   - Assess impact of implemented recommendations

## 🎓 Understanding the Metrics

### Resolution Time
- **Average**: Mean time to resolve (affected by outliers)
- **Median**: Middle value (better for typical case)
- **Use median** for realistic expectations

### Workload Distribution
- **High volume + High resolution time** = Overloaded team
- **High volume + Low resolution time** = Efficient team
- **Low volume + High resolution time** = Training need or complex issues

### Automation Candidates
Tickets are flagged as automation candidates if:
- They occur 10+ times
- Resolution time is below median (resolved quickly)
- Consistent category/pattern

## 📊 Sample Analysis Workflow

1. **Run the master script**
   ```bash
   python run_all_analyses.py
   ```

2. **Review executive summary** (5 minutes)
   - Get overall picture
   - Identify top issues

3. **Check recommendations** (10 minutes)
   - Prioritize quick wins
   - Plan process improvements

4. **Examine visualizations** (10 minutes)
   - Prepare stakeholder presentation
   - Identify trends

5. **Deep dive into specifics** (30+ minutes)
   - Analyze problem categories
   - Review automation candidates
   - Plan action items

**Total Time: 1-2 hours for comprehensive insights**

## 🚨 Important Notes

- **Data Privacy**: Ensure you have permission to analyze ticket data
- **Backups**: Keep original CSV file unchanged
- **Testing**: Test on a small sample (1000 tickets) first
- **Validation**: Verify results match expectations before presenting

## 📚 Additional Resources

For questions or issues:
1. Check the troubleshooting section above
2. Review error messages carefully (they usually indicate the problem)
3. Ensure all prerequisites are installed
4. Verify CSV file format and column names

---

**Version**: 1.0
**Last Updated**: 2025
**Tested With**: Python 3.8+, pandas 1.5+

Happy Analyzing! 📊
