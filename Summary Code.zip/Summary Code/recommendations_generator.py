"""
Recommendations Generator for ServiceNow Tickets
Generates actionable recommendations based on analysis results

Author: Automated Analysis Tool
Date: 2025
"""

import pandas as pd
import numpy as np
from datetime import datetime

class RecommendationsGenerator:
    def __init__(self, file_path):
        """
        Initialize recommendations generator
        
        Parameters:
        file_path (str): Path to the CSV file containing ticket data
        """
        print("Loading ticket data for recommendations...")
        
        # Try different encodings
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        df_loaded = False
        
        for encoding in encodings:
            try:
                self.df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✓ Successfully loaded with {encoding} encoding")
                df_loaded = True
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
            except Exception as e:
                if 'codec' not in str(e).lower():
                    raise
        
        if not df_loaded:
            raise ValueError("Could not read CSV file. Try running: py fix_encoding.py")
        
        # Convert dates
        self.df['opened_at'] = pd.to_datetime(self.df['opened_at'], errors='coerce')
        self.df['resolved_at'] = pd.to_datetime(self.df['resolved_at'], errors='coerce')
        self.df['closed_at'] = pd.to_datetime(self.df['closed_at'], errors='coerce')
        
        # Calculate resolution time
        self.df['resolution_hours'] = (
            self.df['resolved_at'] - self.df['opened_at']
        ).dt.total_seconds() / 3600
        
        print(f"Loaded {len(self.df):,} tickets")
        
        import os
        os.makedirs('output/recommendations', exist_ok=True)
        
        self.recommendations = []
    
    def analyze_workload_distribution(self):
        """Analyze workload across assignment groups"""
        print("\nAnalyzing workload distribution...")
        
        group_workload = self.df.groupby('assignment_group').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median']
        }).round(2)
        
        group_workload.columns = ['ticket_count', 'avg_resolution', 'median_resolution']
        
        # Identify overloaded groups (top 20% by volume with above-average resolution time)
        total_tickets = len(self.df)
        avg_resolution = self.df['resolution_hours'].mean()
        
        overloaded_groups = group_workload[
            (group_workload['ticket_count'] > total_tickets * 0.01) &  # >1% of total tickets
            (group_workload['avg_resolution'] > avg_resolution)
        ].sort_values('ticket_count', ascending=False)
        
        if len(overloaded_groups) > 0:
            self.recommendations.append({
                'priority': 'HIGH',
                'category': 'Workload Redistribution',
                'timeline': '0-30 days',
                'recommendation': f"Review workload for {len(overloaded_groups)} assignment groups handling high volumes with above-average resolution times",
                'details': f"Groups affected: {', '.join(overloaded_groups.head(5).index.tolist())}",
                'expected_impact': 'Reduce resolution times by 15-25% through better load balancing'
            })
        
        return overloaded_groups
    
    def identify_automation_opportunities(self):
        """Identify tickets suitable for automation"""
        print("\nIdentifying automation opportunities...")
        
        # Find frequently occurring issues
        desc_counts = self.df['short_description'].value_counts()
        frequent_issues = desc_counts[desc_counts >= 10]  # Occurs 10+ times
        
        median_resolution = self.df['resolution_hours'].median()
        
        automation_opportunities = []
        for desc, count in frequent_issues.head(20).items():
            desc_tickets = self.df[self.df['short_description'] == desc]
            avg_res = desc_tickets['resolution_hours'].mean()
            
            if avg_res <= median_resolution * 2:  # Resolved reasonably quickly
                automation_opportunities.append({
                    'issue': desc,
                    'occurrences': count,
                    'avg_resolution': avg_res,
                    'potential_hours_saved': count * avg_res * 0.7  # Assume 70% time savings
                })
        
        if len(automation_opportunities) > 0:
            total_hours_saved = sum([opp['potential_hours_saved'] for opp in automation_opportunities])
            
            self.recommendations.append({
                'priority': 'HIGH',
                'category': 'Automation',
                'timeline': '0-30 days (Quick Wins)',
                'recommendation': f"Automate {len(automation_opportunities)} recurring issues that appear {sum([opp['occurrences'] for opp in automation_opportunities])} times",
                'details': f"Top issue: '{automation_opportunities[0]['issue']}' ({automation_opportunities[0]['occurrences']} occurrences)",
                'expected_impact': f"Save approximately {total_hours_saved:.0f} hours annually"
            })
        
        return automation_opportunities
    
    def identify_sla_risks(self):
        """Identify categories at risk of SLA breaches"""
        print("\nIdentifying SLA risks...")
        
        # Calculate resolution time by priority
        priority_resolution = self.df.groupby('priority')['resolution_hours'].agg(['mean', 'median', 'std'])
        
        # Typical SLA targets (adjust as needed)
        sla_targets = {
            '1 - Critical': 4,
            '2 - High': 8,
            '3 - Moderate': 24,
            '4 - Low': 72,
            '5 - Minimal': 120
        }
        
        sla_breaches = []
        for priority, target in sla_targets.items():
            if priority in priority_resolution.index:
                avg_time = priority_resolution.loc[priority, 'mean']
                if avg_time > target:
                    ticket_count = len(self.df[self.df['priority'] == priority])
                    sla_breaches.append({
                        'priority': priority,
                        'avg_resolution': avg_time,
                        'target': target,
                        'breach_margin': avg_time - target,
                        'ticket_count': ticket_count
                    })
        
        if len(sla_breaches) > 0:
            self.recommendations.append({
                'priority': 'CRITICAL',
                'category': 'SLA Compliance',
                'timeline': 'Immediate (0-7 days)',
                'recommendation': f"{len(sla_breaches)} priority levels consistently breach SLA targets",
                'details': f"Most critical: {sla_breaches[0]['priority']} averaging {sla_breaches[0]['avg_resolution']:.1f}hrs vs {sla_breaches[0]['target']}hr target",
                'expected_impact': 'Improve SLA compliance from current levels to 95%+'
            })
        
        return sla_breaches
    
    def analyze_category_performance(self):
        """Analyze performance by category"""
        print("\nAnalyzing category performance...")
        
        category_stats = self.df.groupby('category').agg({
            'number': 'count',
            'resolution_hours': ['mean', 'median', 'std']
        }).round(2)
        
        category_stats.columns = ['ticket_count', 'avg_resolution', 'median_resolution', 'std_resolution']
        
        # Identify problematic categories (high volume + high resolution time)
        avg_resolution = self.df['resolution_hours'].mean()
        
        problematic = category_stats[
            (category_stats['ticket_count'] > len(self.df) * 0.02) &  # >2% of tickets
            (category_stats['avg_resolution'] > avg_resolution * 1.5)  # 50% slower than average
        ].sort_values('ticket_count', ascending=False)
        
        if len(problematic) > 0:
            self.recommendations.append({
                'priority': 'HIGH',
                'category': 'Process Improvement',
                'timeline': '1-3 months',
                'recommendation': f"Deep-dive analysis needed for {len(problematic)} underperforming categories",
                'details': f"Top category: '{problematic.index[0]}' with {int(problematic.iloc[0]['ticket_count'])} tickets, avg resolution {problematic.iloc[0]['avg_resolution']:.1f}hrs",
                'expected_impact': 'Reduce category resolution time by 30-40% through process optimization'
            })
        
        return problematic
    
    def identify_knowledge_gaps(self):
        """Identify areas needing better documentation"""
        print("\nIdentifying knowledge gaps...")
        
        # Find categories with high variation in resolution time (indicates inconsistent knowledge/skills)
        category_variation = self.df.groupby('category').agg({
            'resolution_hours': ['std', 'mean', 'count']
        }).round(2)
        
        category_variation.columns = ['std', 'mean', 'count']
        
        # Calculate coefficient of variation
        category_variation['cv'] = category_variation['std'] / category_variation['mean']
        
        # High variation + reasonable volume = knowledge gap
        knowledge_gaps = category_variation[
            (category_variation['count'] >= 10) &
            (category_variation['cv'] > 1.0)  # High variation
        ].sort_values('count', ascending=False)
        
        if len(knowledge_gaps) > 0:
            self.recommendations.append({
                'priority': 'MEDIUM',
                'category': 'Knowledge Management',
                'timeline': '1-3 months',
                'recommendation': f"Create detailed knowledge base articles for {len(knowledge_gaps)} categories with inconsistent resolution times",
                'details': f"High variation suggests inconsistent knowledge. Top category: '{knowledge_gaps.index[0]}'",
                'expected_impact': 'Standardize resolution process, reduce average time by 20%'
            })
        
        return knowledge_gaps
    
    def analyze_temporal_patterns(self):
        """Analyze time-based patterns"""
        print("\nAnalyzing temporal patterns...")
        
        # Extract time components
        self.df['hour'] = self.df['opened_at'].dt.hour
        self.df['day_of_week'] = self.df['opened_at'].dt.dayofweek
        
        # Find peak hours
        hourly_counts = self.df['hour'].value_counts().sort_index()
        peak_hours = hourly_counts.nlargest(3)
        
        # Find peak days
        daily_counts = self.df['day_of_week'].value_counts()
        
        day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        peak_days = [day_names[day] for day in daily_counts.nlargest(2).index]
        
        self.recommendations.append({
            'priority': 'MEDIUM',
            'category': 'Resource Planning',
            'timeline': '0-30 days',
            'recommendation': f"Optimize staffing for peak periods: {', '.join([str(h) for h in peak_hours.index])}:00 hours and {', '.join(peak_days)}",
            'details': f"Peak hour {peak_hours.index[0]}:00 has {peak_hours.values[0]} tickets",
            'expected_impact': 'Reduce wait times during peak periods by 25%'
        })
        
        return hourly_counts, daily_counts
    
    def identify_recurring_issues(self):
        """Identify root causes that need addressing"""
        print("\nIdentifying recurring issues for root cause analysis...")
        
        # Find issues that keep coming back
        recurring = self.df['short_description'].value_counts()
        top_recurring = recurring[recurring >= 15].head(10)  # Appears 15+ times
        
        if len(top_recurring) > 0:
            total_occurrences = top_recurring.sum()
            
            self.recommendations.append({
                'priority': 'HIGH',
                'category': 'Root Cause Analysis',
                'timeline': '3-6 months (Strategic)',
                'recommendation': f"Conduct root cause analysis for {len(top_recurring)} recurring issues ({total_occurrences} total tickets)",
                'details': f"Most frequent: '{top_recurring.index[0]}' ({top_recurring.values[0]} occurrences)",
                'expected_impact': 'Eliminate 40-60% of recurring incidents through permanent fixes'
            })
        
        return top_recurring
    
    def analyze_assignment_efficiency(self):
        """Analyze assignment and reassignment patterns"""
        print("\nAnalyzing assignment efficiency...")
        
        # Check if tickets are being reassigned (would need assignment history for full analysis)
        # For now, we'll look at assignment group performance
        
        group_performance = self.df.groupby('assignment_group').agg({
            'number': 'count',
            'resolution_hours': 'mean'
        }).round(2)
        
        group_performance.columns = ['ticket_count', 'avg_resolution']
        
        # Find groups with similar volumes but very different performance
        median_resolution = group_performance['avg_resolution'].median()
        
        slow_groups = group_performance[
            (group_performance['ticket_count'] >= 20) &
            (group_performance['avg_resolution'] > median_resolution * 1.5)
        ].sort_values('avg_resolution', ascending=False)
        
        if len(slow_groups) > 0:
            self.recommendations.append({
                'priority': 'MEDIUM',
                'category': 'Team Performance',
                'timeline': '1-3 months',
                'recommendation': f"Training and process review for {len(slow_groups)} assignment groups with below-average performance",
                'details': f"Groups taking 50%+ longer than median: {', '.join(slow_groups.head(3).index.tolist())}",
                'expected_impact': 'Bring underperforming teams to median performance level'
            })
        
        return slow_groups
    
    def generate_recommendations_report(self):
        """Generate final recommendations report"""
        print("\nGenerating recommendations report...")
        
        # Sort recommendations by priority
        priority_order = {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}
        sorted_recs = sorted(self.recommendations, 
                           key=lambda x: priority_order.get(x['priority'], 99))
        
        # Save to CSV
        rec_df = pd.DataFrame(sorted_recs)
        rec_df.to_csv('output/recommendations/actionable_recommendations.csv', index=False)
        
        # Create detailed text report
        with open('output/recommendations/recommendations_report.txt', 'w') as f:
            f.write("=" * 100 + "\n")
            f.write("SERVICENOW TICKET ANALYSIS - ACTIONABLE RECOMMENDATIONS\n")
            f.write("=" * 100 + "\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Recommendations: {len(sorted_recs)}\n\n")
            
            # Group by timeline
            timelines = {}
            for rec in sorted_recs:
                timeline = rec['timeline']
                if timeline not in timelines:
                    timelines[timeline] = []
                timelines[timeline].append(rec)
            
            for timeline in ['Immediate (0-7 days)', '0-30 days (Quick Wins)', '0-30 days', 
                           '1-3 months', '3-6 months (Strategic)']:
                if timeline in timelines:
                    f.write("\n" + "=" * 100 + "\n")
                    f.write(f"TIMELINE: {timeline}\n")
                    f.write("=" * 100 + "\n\n")
                    
                    for idx, rec in enumerate(timelines[timeline], 1):
                        f.write(f"{idx}. [{rec['priority']}] {rec['category']}\n")
                        f.write("-" * 100 + "\n")
                        f.write(f"Recommendation: {rec['recommendation']}\n")
                        f.write(f"Details: {rec['details']}\n")
                        f.write(f"Expected Impact: {rec['expected_impact']}\n\n")
            
            # Add implementation notes
            f.write("\n" + "=" * 100 + "\n")
            f.write("IMPLEMENTATION NOTES\n")
            f.write("=" * 100 + "\n\n")
            f.write("Quick Wins (0-30 days):\n")
            f.write("- Focus on automation and workload redistribution\n")
            f.write("- Can be implemented with minimal process changes\n")
            f.write("- Show immediate ROI to build momentum\n\n")
            
            f.write("Process Improvements (1-3 months):\n")
            f.write("- Require cross-functional collaboration\n")
            f.write("- May need tool/system enhancements\n")
            f.write("- Document lessons learned for future reference\n\n")
            
            f.write("Strategic Initiatives (3-6 months):\n")
            f.write("- Address root causes, not symptoms\n")
            f.write("- May require infrastructure changes\n")
            f.write("- Long-term impact on ticket volume reduction\n\n")
        
        print(f"Generated {len(sorted_recs)} recommendations")
        print("Recommendations saved to output/recommendations/")
        
        return rec_df
    
    def run_full_recommendations(self):
        """Run complete recommendations generation"""
        print("\n" + "=" * 60)
        print("GENERATING ACTIONABLE RECOMMENDATIONS")
        print("=" * 60)
        
        self.analyze_workload_distribution()
        self.identify_automation_opportunities()
        self.identify_sla_risks()
        self.analyze_category_performance()
        self.identify_knowledge_gaps()
        self.analyze_temporal_patterns()
        self.identify_recurring_issues()
        self.analyze_assignment_efficiency()
        
        rec_df = self.generate_recommendations_report()
        
        print("\n" + "=" * 60)
        print("RECOMMENDATIONS GENERATION COMPLETE!")
        print("=" * 60)
        print(f"\nGenerated {len(self.recommendations)} actionable recommendations")
        print("\nOutput files:")
        print("  - output/recommendations/actionable_recommendations.csv")
        print("  - output/recommendations/recommendations_report.txt")
        print("=" * 60 + "\n")
        
        return rec_df


if __name__ == "__main__":
    FILE_PATH = 'servicenow_tickets.csv'
    
    try:
        generator = RecommendationsGenerator(FILE_PATH)
        generator.run_full_recommendations()
        
    except FileNotFoundError:
        print(f"\nERROR: File '{FILE_PATH}' not found!")
        print("Please update the FILE_PATH variable with the correct path to your CSV file.")
    except Exception as e:
        print(f"\nERROR: An error occurred:")
        print(f"{str(e)}")
        import traceback
        traceback.print_exc()
